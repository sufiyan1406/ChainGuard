import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as useContractRevision, O as seedSamplePolicy, S as padLocationId, T as resetMock, b as isMockMode, c as LOCATIONS, h as formatUnixDate, i as useWallet, k as simulateFlood, m as formatEthUnit, n as Button, p as formatAddress, r as cn, v as getPolicies, x as locationLabel } from "./router-yayk0u-M.mjs";
import { n as useAllRiskScores, t as RiskScoreGauge } from "./useRiskScore-BCxX0gBf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/policies-B_ktOPzA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DemoLab() {
	useContractRevision();
	const { connected, connect } = useWallet();
	const [locationId, setLocationId] = (0, import_react.useState)(1n);
	const [score, setScore] = (0, import_react.useState)(88);
	const [note, setNote] = (0, import_react.useState)(null);
	if (!isMockMode()) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "border border-line bg-paper-2 px-5 py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "label",
			children: "Demo lab"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-ink-muted",
			children: "Live mode is on. Flood readings come from the oracle and risk engine — this panel does not push chain state."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "border border-ink bg-dark p-5 text-dark-fg md:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "label text-dark-muted",
				children: "Demo lab · mock only"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display mt-2 text-4xl",
				children: "Trigger a flood"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-sm text-dark-muted",
				children: "Push a sensor reading into the mock risk engine. At 80 the parameter settles every active policy at that location."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "label mt-6 block text-dark-muted",
				children: "Location"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "mt-2 h-11 w-full bg-dark-2 px-3 text-sm text-dark-fg outline-none",
				value: locationId.toString(),
				onChange: (e) => setLocationId(BigInt(e.target.value)),
				children: LOCATIONS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: l.id.toString(),
					children: [
						padLocationId(l.id),
						" ",
						l.name
					]
				}, l.id.toString()))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "label mt-5 block text-dark-muted",
				children: ["Risk score · ", score]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 0,
				max: 100,
				value: score,
				onChange: (e) => setScore(Number(e.target.value)),
				className: "mt-3 w-full accent-mint"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					size: "lg",
					className: "w-full",
					onClick: () => {
						simulateFlood(locationId, score);
						setNote(score >= 80 ? "Flood pushed. Active policies at this site should settle." : `Risk at site is now ${score}.`);
					},
					children: "Push reading"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "text-dark-fg hover:bg-dark-2",
						onClick: () => {
							if (!connected) connect();
							seedSamplePolicy();
							setNote("Sample Jakarta policy added.");
						},
						children: "Seed policy"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "text-dark-fg hover:bg-dark-2",
						onClick: () => {
							resetMock();
							setNote("Mock book cleared.");
						},
						children: "Reset book"
					})]
				})]
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-mint",
				children: note
			}) : null
		]
	});
}
function PolicyCard({ policy, riskScore }) {
	const statusTone = policy.status === "Claimed" ? "bg-mint text-mint-fg" : policy.status === "Expired" ? "bg-paper-2 text-ink-muted" : "bg-ink text-paper";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col border border-line bg-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-3 border-b border-line px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label",
					children: "Policy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-mono text-sm tabular-nums",
					children: ["#", policy.policyId.toString().padStart(4, "0")]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("px-2 py-1 text-[10px] font-medium tracking-[0.16em] uppercase", statusTone),
					children: policy.status
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-0 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-line px-5 py-5 md:border-r md:border-b-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "label",
							children: ["Location ", padLocationId(policy.locationId)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "display mt-2 text-4xl md:text-5xl",
							children: locationLabel(policy.locationId)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-6 grid grid-cols-2 gap-x-4 gap-y-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "label",
									children: "Coverage"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-mono tabular-nums",
									children: formatEthUnit(policy.coverageAmount)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "label",
									children: "Premium"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-mono tabular-nums",
									children: formatEthUnit(policy.premiumPaid)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "label",
									children: "Bound"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-mono text-xs",
									children: formatUnixDate(policy.purchasedAt)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "label",
									children: "Expires"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 font-mono text-xs",
									children: formatUnixDate(policy.expiresAt)
								})] })
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RiskScoreGauge, {
						score: riskScore ?? 0,
						compact: true,
						label: "Live risk"
					}), policy.claimed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-5 border-t border-line pt-4 text-sm",
						children: ["Payout settled · ", formatEthUnit(policy.payoutAmount)]
					}) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "flex items-center justify-between gap-3 border-t border-line px-5 py-3 font-mono text-[11px] text-ink-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Holder ", formatAddress(policy.holder)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Flood parameter" })]
			})
		]
	});
}
function usePolicies(holder) {
	const revision = useContractRevision();
	const [policies, setPolicies] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!holder) {
			setPolicies([]);
			setError(null);
			setLoading(false);
			return;
		}
		let cancelled = false;
		setLoading(true);
		getPolicies(holder).then((rows) => {
			if (!cancelled) {
				setPolicies(rows);
				setError(null);
			}
		}).catch((err) => {
			if (!cancelled) setError(err instanceof Error ? err.message : "Could not load policies.");
		}).finally(() => {
			if (!cancelled) setLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, [holder, revision]);
	return {
		policies,
		loading,
		error,
		refreshKey: revision
	};
}
function PoliciesPage() {
	const wallet = useWallet();
	const { policies, loading, error } = usePolicies(wallet.address);
	const { readings } = useAllRiskScores();
	const riskByLocation = new Map(readings.map((r) => [r.locationId.toString(), r.riskScore]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "grid grid-cols-1 border-b border-line lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-line px-5 py-8 md:px-8 md:py-10 lg:border-r lg:border-b-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label",
					children: "Book"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-2 text-[clamp(3.5rem,12vw,7rem)]",
					children: "Policies"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md text-sm text-ink-muted",
					children: "Every bound policy, with live risk from the engine. Payouts stamp the certificate when the flood parameter crosses 80."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative min-h-48 overflow-hidden bg-dark",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/editorial/dusk.jpg",
				alt: "Still water at dusk",
				className: "absolute inset-0 size-full object-cover opacity-80"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "halftone-fine absolute inset-0" })]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-1 lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-b border-line lg:col-span-8 lg:border-r lg:border-b-0",
			children: !wallet.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "Wallet closed",
				body: "Connect a wallet to read the policies bound to that address. Mock mode uses a demo wallet."
			}) : loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-px",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonRow, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonRow, {})]
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "Could not load",
				body: error
			}) : policies.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "No cover yet",
				body: `Nothing on the book for ${formatAddress(wallet.address ?? "")}. Bind a policy, or seed one from the demo lab.`,
				action: true
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-px bg-line",
				children: policies.map((policy) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolicyCard, {
					policy,
					riskScore: riskByLocation.get(policy.locationId.toString())
				}, policy.policyId.toString()))
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "lg:col-span-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoLab, {})
		})]
	})] });
}
function Empty({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 py-16 md:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-5xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-md text-sm text-ink-muted",
				children: body
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-6 inline-flex h-11 items-center bg-ink px-4 text-sm text-paper",
				children: "Bind cover"
			}) : null
		]
	});
}
function SkeletonRow() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-64 animate-pulse bg-paper-2",
		"aria-hidden": true
	});
}
//#endregion
export { PoliciesPage as component };
