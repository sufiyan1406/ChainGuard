import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as useWalletClient } from "../_libs/wagmi.mjs";
import { a as Check, o as ArrowRight, r as LoaderCircle } from "../_libs/lucide-react.mjs";
import { A as useContractRevision, C as parseCoverage, E as riskBand, S as padLocationId, _ as getLocation, b as isMockMode, c as LOCATIONS, f as buyPolicy, i as useWallet, l as MAX_COVERAGE_WEI, m as formatEthUnit, n as Button, r as cn, u as MIN_COVERAGE_WEI, w as quotePremium, x as locationLabel } from "./router-yayk0u-M.mjs";
import { n as useAllRiskScores, r as useRiskScore, t as RiskScoreGauge } from "./useRiskScore-BCxX0gBf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ym1fCore.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function usePremiumQuote(locationId, coverageAmount) {
	const revision = useContractRevision();
	const [premium, setPremium] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (locationId === null || coverageAmount === null) {
			setPremium(null);
			setError(null);
			setLoading(false);
			return;
		}
		let cancelled = false;
		setLoading(true);
		quotePremium(locationId, coverageAmount).then((value) => {
			if (!cancelled) {
				setPremium(value);
				setError(null);
			}
		}).catch((err) => {
			if (!cancelled) {
				setPremium(null);
				setError(err instanceof Error ? err.message : "Could not quote premium.");
			}
		}).finally(() => {
			if (!cancelled) setLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, [
		locationId,
		coverageAmount,
		revision
	]);
	return {
		premium,
		loading,
		error
	};
}
function validateBuy(input) {
	const errors = {};
	if (!input.connected) errors.wallet = "Connect a wallet to bind cover.";
	else if (!input.isCorrectChain) errors.network = "Switch to Arbitrum Sepolia.";
	if (input.locationId === null) errors.location = "Select a location.";
	else if (!getLocation(input.locationId)) errors.location = "That location is not in the underwriting table.";
	const coverage = parseCoverage(input.coverageInput);
	if (!input.coverageInput.trim()) errors.coverage = "Enter a coverage amount.";
	else if (coverage === null) errors.coverage = "Coverage must be a valid ETH amount.";
	else if (coverage < MIN_COVERAGE_WEI) errors.coverage = "Minimum coverage is 0.01 ETH.";
	else if (coverage > MAX_COVERAGE_WEI) errors.coverage = "Maximum coverage is 5 ETH.";
	return {
		ok: Object.keys(errors).length === 0,
		coverage: errors.coverage ? null : coverage,
		errors
	};
}
var PRESETS = [
	"0.05",
	"0.10",
	"0.25",
	"0.50",
	"1.00"
];
function BuyPolicyForm() {
	const wallet = useWallet();
	const { data: walletClient } = useWalletClient();
	const [locationId, setLocationId] = (0, import_react.useState)(1n);
	const [coverageInput, setCoverageInput] = (0, import_react.useState)("0.10");
	const [tx, setTx] = (0, import_react.useState)({ phase: "idle" });
	const parsed = (0, import_react.useMemo)(() => validateBuy({
		locationId,
		coverageInput,
		connected: wallet.connected,
		isCorrectChain: wallet.isCorrectChain
	}), [
		locationId,
		coverageInput,
		wallet.connected,
		wallet.isCorrectChain
	]);
	const { premium, loading: quoting, error: quoteError } = usePremiumQuote(parsed.coverage && locationId !== null ? locationId : null, parsed.coverage);
	const { reading } = useRiskScore(locationId);
	async function onSubmit(e) {
		e.preventDefault();
		if (!parsed.ok || locationId === null || parsed.coverage === null) {
			setTx({
				phase: "error",
				message: parsed.errors.wallet ?? parsed.errors.network ?? parsed.errors.location ?? parsed.errors.coverage ?? "Check the form."
			});
			return;
		}
		setTx({
			phase: "pending",
			message: "Submitting buyPolicy…"
		});
		try {
			const result = await buyPolicy(locationId, parsed.coverage, { walletClient: !isMockMode() && walletClient && wallet.address ? {
				account: wallet.address,
				writeContract: async (args) => walletClient.writeContract(args)
			} : void 0 });
			setTx({
				phase: "success",
				hash: result.txHash,
				policyId: result.policyId
			});
		} catch (err) {
			setTx({
				phase: "error",
				message: err instanceof Error ? err.message : "Purchase failed.",
				code: err && typeof err === "object" && "code" in err ? String(err.code) : void 0
			});
		}
	}
	if (tx.phase === "success") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-ink bg-mint p-6 text-mint-fg md:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "label text-mint-fg/70",
				children: "Policy bound"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "display mt-3 text-6xl md:text-7xl",
				children: "Covered"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 max-w-md text-sm",
				children: [
					"Policy #",
					tx.policyId.toString().padStart(4, "0"),
					" is on the book. Risk is watched continuously. If the flood parameter crosses the trigger, payout settles without a claim form."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 break-all font-mono text-[11px] text-mint-fg/70",
				children: tx.hash
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/policies",
					className: "inline-flex h-11 items-center bg-ink px-4 text-sm text-paper",
					children: ["View policies", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-2 size-4" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => {
						setTx({ phase: "idle" });
					},
					children: "Bind another"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "grid grid-cols-1 lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-line lg:col-span-7 lg:border-r lg:border-b-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-line px-5 py-5 md:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label",
						children: "01 — Location"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mt-2 text-4xl md:text-5xl",
						children: "Where to cover"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2",
					children: LOCATIONS.map((loc) => {
						const selected = locationId === loc.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setLocationId(loc.id),
							className: cn("flex min-h-24 flex-col items-start border-b border-line px-5 py-4 text-left transition-colors duration-150 sm:odd:border-r", selected ? "bg-ink text-paper" : "bg-paper hover:bg-paper-2"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: cn("label", selected && "text-paper/60"),
									children: [
										padLocationId(loc.id),
										" · ",
										loc.hazard
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "display mt-1 text-3xl",
									children: loc.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("mt-1 text-xs", selected ? "text-paper/70" : "text-ink-muted"),
									children: loc.region
								})
							]
						}, loc.id.toString());
					})
				}),
				parsed.errors.location ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-5 py-3 text-sm text-rose",
					children: parsed.errors.location
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-line px-5 py-5 md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label",
					children: "02 — Coverage"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mt-2 text-4xl md:text-5xl",
					children: "How much"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-5 md:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "coverage",
						className: "label",
						children: "Coverage amount (ETH)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "coverage",
						inputMode: "decimal",
						value: coverageInput,
						onChange: (e) => setCoverageInput(e.target.value),
						className: "mt-2 h-14 w-full border-b border-ink bg-transparent font-display text-5xl tabular-nums outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-1.5",
						children: PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCoverageInput(p),
							className: cn("h-9 px-3 font-mono text-xs", coverageInput === p ? "bg-ink text-paper" : "bg-paper-2 text-ink hover:bg-line"),
							children: p
						}, p))
					}),
					parsed.errors.coverage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-rose",
						children: parsed.errors.coverage
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 border-t border-line pt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "label",
								children: "03 — Premium due now"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "display mt-2 text-5xl tabular-nums",
								children: quoting ? "—" : premium !== null ? formatEthUnit(premium) : "—"
							}),
							quoteError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-rose",
								children: quoteError
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-ink-muted",
								children: "Quoted from the location table. Paid in ETH with the purchase transaction."
							})
						]
					}),
					reading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 border-t border-line pt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RiskScoreGauge, {
							score: reading.riskScore,
							compact: true,
							label: "Current risk at site"
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8",
						children: [
							parsed.errors.wallet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-3 text-sm text-rose",
								children: parsed.errors.wallet
							}) : null,
							parsed.errors.network ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-3 text-sm text-rose",
								children: parsed.errors.network
							}) : null,
							tx.phase === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-3 text-sm text-rose",
								children: tx.message
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "primary",
								size: "xl",
								className: "w-full",
								disabled: tx.phase === "pending" || tx.phase === "confirming",
								children: tx.phase === "pending" || tx.phase === "confirming" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), tx.phase === "pending" ? "Confirming" : "Binding"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Bind cover", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })] })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs text-ink-muted",
								children: [
									"Calls ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono",
										children: "buyPolicy(locationId, coverageAmount)"
									}),
									wallet.mock ? " through the mock contract layer." : " on the insurance pool."
								]
							})
						]
					})
				]
			})]
		})]
	});
}
function LiveRiskStrip() {
	const { readings, loading } = useAllRiskScores();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end justify-between border-b border-line px-5 py-4 md:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "label",
			children: "Live book"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "display mt-1 text-3xl md:text-4xl",
			children: "Risk by site"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-[11px] text-ink-muted",
			children: loading ? "Polling…" : "Refresh 4s"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6",
		children: readings.map((r) => {
			const band = riskBand(r.riskScore);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-r border-line px-4 py-4 last:border-r-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label",
						children: padLocationId(r.locationId)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 truncate text-sm",
						children: locationLabel(r.locationId)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("display mt-3 text-4xl tabular-nums", band === "trigger" ? "text-rose" : "text-ink"),
						children: r.riskScore.toString().padStart(2, "0")
					})
				]
			}, r.locationId.toString());
		})
	})] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "bind",
			className: "border-t border-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between border-b border-line px-5 py-5 md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label",
					children: "Bind cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mt-1 text-4xl md:text-5xl",
					children: "Buy a policy"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden max-w-xs text-right text-xs text-ink-muted md:block",
					children: "Location → coverage → premium → purchase. One transaction."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyPolicyForm, {})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveRiskStrip, {})
	] });
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid grid-cols-1 lg:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-[28rem] flex-col justify-between border-b border-line px-5 py-8 md:min-h-[32rem] md:px-8 md:py-10 lg:border-r lg:border-b-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label",
					children: "Parametric flood cover · Arbitrum"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "display text-[clamp(4.5rem,16vw,9.5rem)]",
						children: "Cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-md text-base text-ink-muted md:text-lg",
						children: "Micro-insurance that pays when the water parameter crosses the line. No adjuster. No waiting on a claim file. The contract is the policy."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#bind",
							className: "inline-flex h-12 items-center bg-ink px-5 text-sm text-paper transition-transform duration-150 active:scale-[0.96]",
							children: ["Bind cover", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-2 size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/policies",
							className: "inline-flex h-12 items-center px-5 text-sm text-ink shadow-[inset_0_0_0_1px_var(--color-ink)] transition-colors duration-150 hover:bg-ink hover:text-paper",
							children: "My policies"
						})]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-[22rem] overflow-hidden bg-dark lg:min-h-[32rem]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/editorial/delta.jpg",
						alt: "Aerial river delta over a city grid",
						className: "absolute inset-0 size-full object-cover opacity-80"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "halftone-fine absolute inset-0 mix-blend-multiply" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-dark/70 to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "display pointer-events-none absolute -bottom-6 right-2 text-[clamp(8rem,28vw,16rem)] leading-none text-paper/15 select-none",
						children: "G"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute bottom-5 left-5 font-mono text-[11px] tracking-widest text-paper uppercase",
						children: "Jakarta basin · site 01"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 border-t border-line lg:col-span-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative min-h-52 overflow-hidden border-b border-r border-line sm:min-h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/editorial/concrete.jpg",
							alt: "Rain-stained brutalist concrete",
							className: "absolute inset-0 size-full object-cover"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative min-h-52 overflow-hidden border-b border-line sm:min-h-64 lg:border-r",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/editorial/water.jpg",
							alt: "Rain on dark water",
							className: "absolute inset-0 size-full object-cover"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-52 flex-col justify-between border-b border-line bg-dark p-5 text-dark-fg sm:min-h-64 lg:border-r lg:border-b-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed",
							children: "Placing flood cover for households and small books on a public chain since this afternoon. The risk engine is Stylus. The pool is the underwriter."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "label text-dark-muted",
							children: "Since 2026"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-52 flex-col justify-between bg-mint p-5 text-mint-fg sm:min-h-64",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed",
							children: "We don’t wait on volume. We move capital when the parameter says so — and the firms that bind cover get paid in the same block."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "label text-mint-fg/70",
							children: "Payout on trigger"
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };
