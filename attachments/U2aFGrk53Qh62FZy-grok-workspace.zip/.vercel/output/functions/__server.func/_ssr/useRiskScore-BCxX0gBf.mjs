import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { A as useContractRevision, D as riskLabel, E as riskBand, g as getAllRiskScores, r as cn, y as getRiskScore } from "./router-yayk0u-M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useRiskScore-BCxX0gBf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RiskScoreGauge({ score, compact = false, label }) {
	const clamped = Math.max(0, Math.min(100, Math.round(score)));
	const band = riskBand(clamped);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-col", compact ? "gap-2" : "gap-4"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label mb-2",
					children: label
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("font-display leading-none tabular-nums text-ink", compact ? "text-5xl" : "text-7xl md:text-8xl"),
					children: clamped.toString().padStart(2, "0")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pb-1 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-xs font-medium tracking-[0.18em] uppercase", band === "trigger" ? "text-rose" : "text-ink-muted"),
						children: riskLabel(clamped)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-[11px] text-ink-subtle",
						children: ["Payout ≥ ", 80]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-2 w-full bg-paper-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("h-full transition-[width] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]", band === "trigger" ? "bg-rose" : "bg-ink"),
					style: { width: `${clamped}%` }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-0 h-2 w-px bg-rose",
					style: { left: `80%` },
					"aria-hidden": true
				})]
			}),
			!compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between font-mono text-[10px] tracking-wider text-ink-subtle uppercase",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Calm" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Elevated" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Severe" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn(band === "trigger" && "text-rose"),
						children: "Trigger"
					})
				]
			}) : null
		]
	});
}
var POLL_MS = 4e3;
function useRiskScore(locationId) {
	const revision = useContractRevision();
	const [reading, setReading] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (locationId === null) {
			setReading(null);
			return;
		}
		let cancelled = false;
		async function pull() {
			try {
				const next = await getRiskScore(locationId);
				if (!cancelled) {
					setReading(next);
					setError(null);
					setLoading(false);
				}
			} catch (err) {
				if (!cancelled) {
					setError(err instanceof Error ? err.message : "Could not load risk score.");
					setLoading(false);
				}
			}
		}
		setLoading(true);
		pull();
		const id = window.setInterval(() => void pull(), POLL_MS);
		return () => {
			cancelled = true;
			window.clearInterval(id);
		};
	}, [locationId, revision]);
	return {
		reading,
		loading,
		error
	};
}
function useAllRiskScores() {
	const revision = useContractRevision();
	const [readings, setReadings] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		async function pull() {
			try {
				const next = await getAllRiskScores();
				if (!cancelled) {
					setReadings(next);
					setLoading(false);
				}
			} catch {
				if (!cancelled) setLoading(false);
			}
		}
		pull();
		const id = window.setInterval(() => void pull(), POLL_MS);
		return () => {
			cancelled = true;
			window.clearInterval(id);
		};
	}, [revision]);
	return {
		readings,
		loading
	};
}
//#endregion
export { useAllRiskScores as n, useRiskScore as r, RiskScoreGauge as t };
