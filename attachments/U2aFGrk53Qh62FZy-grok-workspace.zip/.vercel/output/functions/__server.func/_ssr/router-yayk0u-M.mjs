import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react, r as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { It as decodeEventLog, c as createConfig, l as injected, xn as formatEther } from "../_libs/@wagmi/core+[...].mjs";
import { i as parseEther, n as http, r as createPublicClient, t as arbitrumSepolia } from "../_libs/viem.mjs";
import { _ as createFileRoute, b as useRouter, d as HeadContent, f as useRouterState, g as lazyRouteComponent, h as Outlet, m as createRouter, u as Scripts, v as createRootRoute, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { a as useConnection, i as useConnect, n as useSwitchChain, o as WagmiProvider, r as useDisconnect } from "../_libs/wagmi.mjs";
import { i as ChevronDown, n as Unplug, t as Wallet } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useContractRevision-xg2DRNIS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var ARBITRUM_SEPOLIA_CHAIN_ID = 421614;
var POLICY_DURATION_SECONDS = 7776e3;
var MIN_COVERAGE_WEI = 10n ** 16n;
var MAX_COVERAGE_WEI = 5n * 10n ** 18n;
var MOCK_WALLET = "0xA11CE00000000000000000000000000000000C0";
function asAddress(value) {
	if (!value) return null;
	if (!/^0x[0-9a-fA-F]{40}$/.test(value)) return null;
	return value;
}
var CHAIN_ID = Number(ARBITRUM_SEPOLIA_CHAIN_ID);
var RPC_URL = "https://sepolia-rollup.arbitrum.io/rpc";
var ADDRESSES = {
	riskEngine: asAddress(void 0),
	insurancePool: asAddress(void 0),
	policyNft: asAddress(void 0),
	mockOracle: asAddress(void 0)
};
function hasRealAddresses() {
	return Boolean(ADDRESSES.insurancePool && ADDRESSES.riskEngine);
}
/**
* Mock is the default until real Sepolia addresses are provided.
* Set VITE_USE_MOCK=false to force live mode (still requires addresses).
*/
function defaultMockMode() {
	return !hasRealAddresses();
}
/**
* Location lookup table.
*
* These IDs are the frontend's documented mapping while
* `docs/INTEGRATION_CONTRACT.md` is the source of truth.
* Do not invent additional IDs in UI code — add them here first.
*/
var LOCATIONS = [
	{
		id: 1n,
		name: "Jakarta",
		region: "Indonesia",
		hazard: "Flood",
		basePremiumBps: 420,
		description: "Coastal megacity on a sinking alluvial plain."
	},
	{
		id: 2n,
		name: "New Orleans",
		region: "United States",
		hazard: "Flood",
		basePremiumBps: 380,
		description: "Below-sea-level basin behind a levee system."
	},
	{
		id: 3n,
		name: "Venice",
		region: "Italy",
		hazard: "Flood",
		basePremiumBps: 310,
		description: "Lagoon city with recurrent acqua alta."
	},
	{
		id: 4n,
		name: "Dhaka",
		region: "Bangladesh",
		hazard: "Flood",
		basePremiumBps: 460,
		description: "Delta capital on the Buriganga floodplain."
	},
	{
		id: 5n,
		name: "Miami",
		region: "United States",
		hazard: "Flood",
		basePremiumBps: 350,
		description: "Low-lying Atlantic shelf, king-tide exposure."
	},
	{
		id: 6n,
		name: "Bangkok",
		region: "Thailand",
		hazard: "Flood",
		basePremiumBps: 340,
		description: "Chao Phraya basin with seasonal monsoon surge."
	}
];
function getLocation(id) {
	return LOCATIONS.find((l) => l.id === id);
}
function locationLabel(id) {
	const loc = getLocation(id);
	return loc ? `${loc.name}, ${loc.region}` : `Location #${id.toString()}`;
}
function padLocationId(id) {
	return id.toString().padStart(2, "0");
}
/**
* Frontend ABI copies matching docs/INTEGRATION_CONTRACT.md.
*
* Do not edit shared/contract-abis/ — that tree is owned by the backend.
* When generated ABIs land, swap imports in contracts.ts to those files.
*/
var insurancePoolAbi = [
	{
		type: "function",
		name: "buyPolicy",
		stateMutability: "payable",
		inputs: [{
			name: "locationId",
			type: "uint256"
		}, {
			name: "coverageAmount",
			type: "uint256"
		}],
		outputs: [{
			name: "policyId",
			type: "uint256"
		}]
	},
	{
		type: "function",
		name: "quotePremium",
		stateMutability: "view",
		inputs: [{
			name: "locationId",
			type: "uint256"
		}, {
			name: "coverageAmount",
			type: "uint256"
		}],
		outputs: [{
			name: "premium",
			type: "uint256"
		}]
	},
	{
		type: "function",
		name: "getPolicy",
		stateMutability: "view",
		inputs: [{
			name: "policyId",
			type: "uint256"
		}],
		outputs: [{
			name: "policy",
			type: "tuple",
			components: [
				{
					name: "policyId",
					type: "uint256"
				},
				{
					name: "holder",
					type: "address"
				},
				{
					name: "locationId",
					type: "uint256"
				},
				{
					name: "coverageAmount",
					type: "uint256"
				},
				{
					name: "premiumPaid",
					type: "uint256"
				},
				{
					name: "purchasedAt",
					type: "uint256"
				},
				{
					name: "expiresAt",
					type: "uint256"
				},
				{
					name: "status",
					type: "uint8"
				},
				{
					name: "claimed",
					type: "bool"
				},
				{
					name: "payoutAmount",
					type: "uint256"
				}
			]
		}]
	},
	{
		type: "function",
		name: "getPoliciesByHolder",
		stateMutability: "view",
		inputs: [{
			name: "holder",
			type: "address"
		}],
		outputs: [{
			name: "policyIds",
			type: "uint256[]"
		}]
	},
	{
		type: "event",
		name: "PolicyPurchased",
		inputs: [
			{
				name: "policyId",
				type: "uint256",
				indexed: true
			},
			{
				name: "holder",
				type: "address",
				indexed: true
			},
			{
				name: "locationId",
				type: "uint256",
				indexed: false
			},
			{
				name: "coverageAmount",
				type: "uint256",
				indexed: false
			},
			{
				name: "premiumPaid",
				type: "uint256",
				indexed: false
			}
		]
	},
	{
		type: "event",
		name: "PayoutTriggered",
		inputs: [
			{
				name: "policyId",
				type: "uint256",
				indexed: true
			},
			{
				name: "holder",
				type: "address",
				indexed: true
			},
			{
				name: "amount",
				type: "uint256",
				indexed: false
			},
			{
				name: "riskScore",
				type: "uint32",
				indexed: false
			}
		]
	},
	{
		type: "error",
		name: "PolicyNotFound",
		inputs: []
	},
	{
		type: "error",
		name: "AlreadyClaimed",
		inputs: []
	},
	{
		type: "error",
		name: "InsufficientPremium",
		inputs: []
	},
	{
		type: "error",
		name: "NotAuthorized",
		inputs: []
	},
	{
		type: "error",
		name: "InvalidLocation",
		inputs: []
	},
	{
		type: "error",
		name: "CoverageOutOfBounds",
		inputs: []
	}
];
var riskEngineAbi = [
	{
		type: "function",
		name: "getRiskScore",
		stateMutability: "view",
		inputs: [{
			name: "locationId",
			type: "uint256"
		}],
		outputs: [{
			name: "score",
			type: "uint32"
		}]
	},
	{
		type: "function",
		name: "getLastUpdated",
		stateMutability: "view",
		inputs: [{
			name: "locationId",
			type: "uint256"
		}],
		outputs: [{
			name: "timestamp",
			type: "uint256"
		}]
	},
	{
		type: "function",
		name: "getSensorValue",
		stateMutability: "view",
		inputs: [{
			name: "locationId",
			type: "uint256"
		}],
		outputs: [{
			name: "value",
			type: "uint256"
		}]
	}
];
var CONTRACT_ERROR_MESSAGES = {
	PolicyNotFound: "This policy does not exist.",
	AlreadyClaimed: "Payout already settled for this policy.",
	InsufficientPremium: "Premium sent is below the quoted amount.",
	NotAuthorized: "This wallet cannot perform that action.",
	InvalidLocation: "That location is not in the underwriting table.",
	CoverageOutOfBounds: "Coverage is outside the allowed range.",
	WalletNotConnected: "Connect a wallet to continue.",
	WrongNetwork: "Switch to Arbitrum Sepolia to continue.",
	UserRejected: "Transaction was rejected in the wallet."
};
function decodeContractError(error) {
	if (!error) return { message: "Something went wrong." };
	const raw = typeof error === "string" ? error : error instanceof Error ? `${error.name} ${error.message} ${"shortMessage" in error ? String(error.shortMessage) : ""}` : JSON.stringify(error);
	for (const code of Object.keys(CONTRACT_ERROR_MESSAGES)) if (raw.includes(code)) return {
		code,
		message: CONTRACT_ERROR_MESSAGES[code]
	};
	if (/user rejected|denied|rejected the request/i.test(raw)) return {
		code: "UserRejected",
		message: CONTRACT_ERROR_MESSAGES.UserRejected
	};
	if (/insufficient funds/i.test(raw)) return { message: "Wallet does not have enough ETH for premium and gas." };
	return { message: error && typeof error === "object" && "shortMessage" in error ? String(error.shortMessage) : error instanceof Error ? error.message : "Transaction failed." };
}
var ChainGuardError = class extends Error {
	code;
	constructor(message, code) {
		super(message);
		this.name = "ChainGuardError";
		this.code = code;
	}
};
function formatEth(wei, digits = 4) {
	const n = Number(formatEther(wei));
	if (!Number.isFinite(n)) return formatEther(wei);
	return n.toLocaleString(void 0, {
		minimumFractionDigits: 2,
		maximumFractionDigits: digits
	});
}
function formatEthUnit(wei, digits = 4) {
	return `${formatEth(wei, digits)} ETH`;
}
function parseCoverage(input) {
	const trimmed = input.trim();
	if (!trimmed) return null;
	try {
		return parseEther(trimmed);
	} catch {
		return null;
	}
}
function formatAddress(address) {
	if (address.length < 10) return address;
	return `${address.slice(0, 6)}…${address.slice(-4)}`;
}
function formatUnixDate(seconds) {
	const ms = Number(seconds) * 1e3;
	if (!Number.isFinite(ms) || ms <= 0) return "—";
	return new Date(ms).toLocaleDateString(void 0, {
		year: "numeric",
		month: "short",
		day: "numeric"
	});
}
function riskBand(score) {
	if (score >= 80) return "trigger";
	if (score >= 61) return "severe";
	if (score >= 31) return "elevated";
	return "calm";
}
function riskLabel(score) {
	switch (riskBand(score)) {
		case "trigger": return "Trigger";
		case "severe": return "Severe";
		case "elevated": return "Elevated";
		default: return "Calm";
	}
}
function nowUnix() {
	return BigInt(Math.floor(Date.now() / 1e3));
}
function clockLabel(date = /* @__PURE__ */ new Date()) {
	return date.toLocaleTimeString(void 0, {
		hour: "2-digit",
		minute: "2-digit"
	});
}
var STORAGE_KEY = "chainguard.mock.v1";
function defaultRisks() {
	const now = nowUnix();
	return [
		[
			1n,
			18,
			420n
		],
		[
			2n,
			24,
			510n
		],
		[
			3n,
			12,
			280n
		],
		[
			4n,
			29,
			640n
		],
		[
			5n,
			16,
			330n
		],
		[
			6n,
			21,
			390n
		]
	].map(([locationId, riskScore, sensorValue]) => ({
		locationId,
		riskScore,
		sensorValue,
		updatedAt: now
	}));
}
function serialize(state) {
	return {
		nextId: state.nextId,
		wallet: state.wallet,
		balance: state.balance.toString(),
		policies: state.policies.map((p) => ({
			...p,
			policyId: p.policyId.toString(),
			locationId: p.locationId.toString(),
			coverageAmount: p.coverageAmount.toString(),
			premiumPaid: p.premiumPaid.toString(),
			purchasedAt: p.purchasedAt.toString(),
			expiresAt: p.expiresAt.toString(),
			payoutAmount: p.payoutAmount.toString()
		})),
		risks: state.risks.map((r) => ({
			...r,
			locationId: r.locationId.toString(),
			updatedAt: r.updatedAt.toString(),
			sensorValue: r.sensorValue.toString()
		})),
		payouts: state.payouts.map((e) => ({
			...e,
			policyId: e.policyId.toString(),
			amount: e.amount.toString(),
			timestamp: e.timestamp.toString()
		}))
	};
}
function deserialize(raw) {
	return {
		nextId: raw.nextId,
		wallet: raw.wallet,
		balance: BigInt(raw.balance),
		policies: raw.policies.map((p) => ({
			...p,
			policyId: BigInt(p.policyId),
			locationId: BigInt(p.locationId),
			coverageAmount: BigInt(p.coverageAmount),
			premiumPaid: BigInt(p.premiumPaid),
			purchasedAt: BigInt(p.purchasedAt),
			expiresAt: BigInt(p.expiresAt),
			payoutAmount: BigInt(p.payoutAmount)
		})),
		risks: raw.risks.map((r) => ({
			...r,
			locationId: BigInt(r.locationId),
			updatedAt: BigInt(r.updatedAt),
			sensorValue: BigInt(r.sensorValue)
		})),
		payouts: raw.payouts.map((e) => ({
			...e,
			policyId: BigInt(e.policyId),
			amount: BigInt(e.amount),
			timestamp: BigInt(e.timestamp)
		}))
	};
}
function freshState() {
	return {
		nextId: 1,
		wallet: null,
		balance: 10n * 10n ** 18n,
		policies: [],
		risks: defaultRisks(),
		payouts: []
	};
}
function load() {
	if (typeof localStorage === "undefined") return freshState();
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return freshState();
		return deserialize(JSON.parse(raw));
	} catch {
		return freshState();
	}
}
function save(state) {
	if (typeof localStorage === "undefined") return;
	localStorage.setItem(STORAGE_KEY, JSON.stringify(serialize(state)));
}
var state = freshState();
var revision$1 = 0;
var listeners$1 = /* @__PURE__ */ new Set();
function emit() {
	revision$1 += 1;
	save(state);
	listeners$1.forEach((l) => l());
}
function hydrateMock() {
	if (typeof window === "undefined") return;
	state = load();
	revision$1 += 1;
	listeners$1.forEach((l) => l());
}
function subscribeMock(cb) {
	listeners$1.add(cb);
	return () => listeners$1.delete(cb);
}
function getMockRevision() {
	return revision$1;
}
function getMockState() {
	return state;
}
function quotePremiumMock(locationId, coverageAmount) {
	const loc = getLocation(locationId);
	if (!loc) throw new ChainGuardError("That location is not in the underwriting table.", "InvalidLocation");
	if (coverageAmount < MIN_COVERAGE_WEI || coverageAmount > MAX_COVERAGE_WEI) throw new ChainGuardError("Coverage is outside the allowed range.", "CoverageOutOfBounds");
	return coverageAmount * BigInt(loc.basePremiumBps) / 10000n;
}
function connectMockWallet() {
	state = {
		...state,
		wallet: MOCK_WALLET
	};
	emit();
	return MOCK_WALLET;
}
function disconnectMockWallet() {
	state = {
		...state,
		wallet: null
	};
	emit();
}
async function buyPolicyMock(locationId, coverageAmount) {
	if (!state.wallet) throw new ChainGuardError("Connect a wallet to continue.", "WalletNotConnected");
	if (!getLocation(locationId)) throw new ChainGuardError("That location is not in the underwriting table.", "InvalidLocation");
	if (coverageAmount < MIN_COVERAGE_WEI || coverageAmount > MAX_COVERAGE_WEI) throw new ChainGuardError("Coverage is outside the allowed range.", "CoverageOutOfBounds");
	const premium = quotePremiumMock(locationId, coverageAmount);
	if (state.balance < premium) throw new ChainGuardError("Wallet does not have enough ETH for premium and gas.", "InsufficientPremium");
	await delay(720);
	const purchasedAt = nowUnix();
	const policy = {
		policyId: BigInt(state.nextId),
		holder: state.wallet,
		locationId,
		coverageAmount,
		premiumPaid: premium,
		purchasedAt,
		expiresAt: purchasedAt + BigInt(POLICY_DURATION_SECONDS),
		status: "Active",
		claimed: false,
		payoutAmount: 0n
	};
	const txHash = `0x${crypto.randomUUID().replace(/-/g, "").padEnd(64, "0")}`;
	state = {
		...state,
		nextId: state.nextId + 1,
		balance: state.balance - premium,
		policies: [policy, ...state.policies]
	};
	emit();
	await delay(480);
	return {
		policyId: policy.policyId,
		txHash,
		premium
	};
}
function getPoliciesMock(holder) {
	const now = nowUnix();
	return state.policies.filter((p) => p.holder.toLowerCase() === holder.toLowerCase()).map((p) => expireIfNeeded(p, now));
}
function getPolicyMock(policyId) {
	const found = state.policies.find((p) => p.policyId === policyId);
	if (!found) throw new ChainGuardError("This policy does not exist.", "PolicyNotFound");
	return expireIfNeeded(found, nowUnix());
}
function getRiskMock(locationId) {
	const found = state.risks.find((r) => r.locationId === locationId);
	if (found) return found;
	return {
		locationId,
		riskScore: 0,
		updatedAt: nowUnix(),
		sensorValue: 0n
	};
}
function getAllRisksMock() {
	return state.risks;
}
function getPayoutsMock(holder) {
	if (!holder) return state.payouts;
	return state.payouts.filter((e) => e.holder.toLowerCase() === holder.toLowerCase());
}
function simulateFlood(locationId, riskScore) {
	const clamped = Math.max(0, Math.min(100, Math.round(riskScore)));
	const sensorValue = BigInt(200 + clamped * 12);
	state = {
		...state,
		risks: state.risks.map((r) => r.locationId === locationId ? {
			...r,
			riskScore: clamped,
			sensorValue,
			updatedAt: nowUnix()
		} : r)
	};
	emit();
	if (clamped >= 80) triggerPayoutsForLocation(locationId, clamped);
}
function resetMock() {
	const wallet = state.wallet;
	state = {
		...freshState(),
		wallet
	};
	emit();
}
function seedSamplePolicy() {
	if (!state.wallet) connectMockWallet();
	const holder = state.wallet ?? "0xA11CE00000000000000000000000000000000C0";
	const purchasedAt = nowUnix() - 3n * 24n * 60n * 60n;
	const policy = {
		policyId: BigInt(state.nextId),
		holder,
		locationId: 1n,
		coverageAmount: 10n ** 17n,
		premiumPaid: quotePremiumMock(1n, 10n ** 17n),
		purchasedAt,
		expiresAt: purchasedAt + BigInt(POLICY_DURATION_SECONDS),
		status: "Active",
		claimed: false,
		payoutAmount: 0n
	};
	state = {
		...state,
		nextId: state.nextId + 1,
		wallet: holder,
		policies: [policy, ...state.policies]
	};
	emit();
	return policy;
}
function triggerPayoutsForLocation(locationId, riskScore) {
	const now = nowUnix();
	for (const policy of state.policies) {
		const live = expireIfNeeded(policy, now);
		if (live.locationId !== locationId) continue;
		if (live.status !== "Active" || live.claimed) continue;
		settlePayout(live, riskScore);
	}
}
function settlePayout(policy, riskScore) {
	const event = {
		policyId: policy.policyId,
		holder: policy.holder,
		amount: policy.coverageAmount,
		riskScore,
		timestamp: nowUnix(),
		txHash: `0x${crypto.randomUUID().replace(/-/g, "").padEnd(64, "0")}`
	};
	state = {
		...state,
		balance: state.wallet?.toLowerCase() === policy.holder.toLowerCase() ? state.balance + policy.coverageAmount : state.balance,
		policies: state.policies.map((p) => p.policyId === policy.policyId ? {
			...p,
			status: "Claimed",
			claimed: true,
			payoutAmount: policy.coverageAmount
		} : p),
		payouts: [event, ...state.payouts]
	};
	emit();
}
function expireIfNeeded(policy, now) {
	if (policy.status === "Active" && now > policy.expiresAt) return {
		...policy,
		status: "Expired"
	};
	return policy;
}
function delay(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
/**
* Single blockchain abstraction layer.
*
* UI and hooks talk only to this module. Mock vs live is decided here.
*/
var MODE_KEY = "chainguard.mode";
var mockOverride = null;
var modeHydrated = false;
function readStoredMode() {
	if (typeof localStorage === "undefined") return null;
	const v = localStorage.getItem(MODE_KEY);
	if (v === "mock") return true;
	if (v === "live") return false;
	return null;
}
function isMockMode() {
	if (mockOverride !== null) return mockOverride;
	if (!modeHydrated) return defaultMockMode();
	const stored = readStoredMode();
	if (stored !== null) return stored;
	return defaultMockMode();
}
function setMockMode(next) {
	mockOverride = next;
	if (typeof localStorage !== "undefined") localStorage.setItem(MODE_KEY, next ? "mock" : "live");
	notify();
}
function hydrateContractLayer() {
	if (typeof window === "undefined") return;
	modeHydrated = true;
	mockOverride = readStoredMode();
	notify();
}
function canUseLiveMode() {
	return hasRealAddresses();
}
var revision = 0;
var listeners = /* @__PURE__ */ new Set();
function notify() {
	revision += 1;
	listeners.forEach((l) => l());
}
function subscribeContractState(cb) {
	const unsubMock = subscribeMock(() => {
		revision += 1;
		cb();
	});
	listeners.add(cb);
	return () => {
		unsubMock();
		listeners.delete(cb);
	};
}
function getContractRevision() {
	return revision + getMockRevision();
}
var publicClient = null;
function getClient() {
	if (!publicClient) publicClient = createPublicClient({ transport: http(RPC_URL) });
	return publicClient;
}
async function quotePremium(locationId, coverageAmount) {
	if (isMockMode()) return quotePremiumMock(locationId, coverageAmount);
	if (!ADDRESSES.insurancePool) throw new ChainGuardError("Insurance pool address is not configured.");
	try {
		return await getClient().readContract({
			address: ADDRESSES.insurancePool,
			abi: insurancePoolAbi,
			functionName: "quotePremium",
			args: [locationId, coverageAmount]
		});
	} catch (error) {
		const decoded = decodeContractError(error);
		throw new ChainGuardError(decoded.message, decoded.code);
	}
}
async function buyPolicy(locationId, coverageAmount, helpers) {
	if (isMockMode()) return buyPolicyMock(locationId, coverageAmount);
	if (!ADDRESSES.insurancePool) throw new ChainGuardError("Insurance pool address is not configured.");
	if (!helpers?.walletClient) throw new ChainGuardError("Connect a wallet to continue.", "WalletNotConnected");
	try {
		const premium = await quotePremium(locationId, coverageAmount);
		const hash = await helpers.walletClient.writeContract({
			address: ADDRESSES.insurancePool,
			abi: insurancePoolAbi,
			functionName: "buyPolicy",
			args: [locationId, coverageAmount],
			value: premium,
			account: helpers.walletClient.account,
			chain: { id: CHAIN_ID }
		});
		const receipt = await getClient().waitForTransactionReceipt({ hash });
		let policyId = 0n;
		for (const log of receipt.logs) try {
			const decoded = decodeEventLog({
				abi: insurancePoolAbi,
				data: log.data,
				topics: log.topics
			});
			if (decoded.eventName === "PolicyPurchased") policyId = decoded.args.policyId;
		} catch {}
		return {
			policyId,
			txHash: hash,
			premium
		};
	} catch (error) {
		const decoded = decodeContractError(error);
		throw new ChainGuardError(decoded.message, decoded.code);
	}
}
async function getPolicies(holder) {
	if (isMockMode()) return getPoliciesMock(holder);
	if (!ADDRESSES.insurancePool) return [];
	try {
		const ids = await getClient().readContract({
			address: ADDRESSES.insurancePool,
			abi: insurancePoolAbi,
			functionName: "getPoliciesByHolder",
			args: [holder]
		});
		return (await Promise.all(ids.map((id) => getPolicy(id)))).sort((a, b) => Number(b.purchasedAt - a.purchasedAt));
	} catch (error) {
		const decoded = decodeContractError(error);
		throw new ChainGuardError(decoded.message, decoded.code);
	}
}
async function getPolicy(policyId) {
	if (isMockMode()) return getPolicyMock(policyId);
	if (!ADDRESSES.insurancePool) throw new ChainGuardError("This policy does not exist.", "PolicyNotFound");
	try {
		const raw = await getClient().readContract({
			address: ADDRESSES.insurancePool,
			abi: insurancePoolAbi,
			functionName: "getPolicy",
			args: [policyId]
		});
		return {
			policyId: raw.policyId,
			holder: raw.holder,
			locationId: raw.locationId,
			coverageAmount: raw.coverageAmount,
			premiumPaid: raw.premiumPaid,
			purchasedAt: raw.purchasedAt,
			expiresAt: raw.expiresAt,
			status: statusFromCode(raw.status),
			claimed: raw.claimed,
			payoutAmount: raw.payoutAmount
		};
	} catch (error) {
		const decoded = decodeContractError(error);
		throw new ChainGuardError(decoded.message, decoded.code);
	}
}
async function getRiskScore(locationId) {
	if (isMockMode()) return getRiskMock(locationId);
	if (!ADDRESSES.riskEngine) return {
		locationId,
		riskScore: 0,
		updatedAt: 0n,
		sensorValue: 0n
	};
	try {
		const client = getClient();
		const [score, updatedAt, sensorValue] = await Promise.all([
			client.readContract({
				address: ADDRESSES.riskEngine,
				abi: riskEngineAbi,
				functionName: "getRiskScore",
				args: [locationId]
			}),
			client.readContract({
				address: ADDRESSES.riskEngine,
				abi: riskEngineAbi,
				functionName: "getLastUpdated",
				args: [locationId]
			}),
			client.readContract({
				address: ADDRESSES.riskEngine,
				abi: riskEngineAbi,
				functionName: "getSensorValue",
				args: [locationId]
			}).catch(() => 0n)
		]);
		return {
			locationId,
			riskScore: Number(score),
			updatedAt,
			sensorValue
		};
	} catch (error) {
		const decoded = decodeContractError(error);
		throw new ChainGuardError(decoded.message, decoded.code);
	}
}
async function getAllRiskScores() {
	if (isMockMode()) return getAllRisksMock();
	return Promise.all(LOCATIONS.map((l) => getRiskScore(l.id)));
}
function watchPayouts(holder, onEvent) {
	if (isMockMode()) {
		let seen = new Set(getPayoutsMock(holder ?? void 0).map((e) => e.policyId.toString()));
		return subscribeMock(() => {
			const latest = getPayoutsMock(holder ?? void 0);
			for (const event of latest) {
				const key = event.policyId.toString();
				if (!seen.has(key)) {
					seen = new Set(seen).add(key);
					onEvent(event);
				}
			}
		});
	}
	if (!ADDRESSES.insurancePool) return () => {};
	return getClient().watchContractEvent({
		address: ADDRESSES.insurancePool,
		abi: insurancePoolAbi,
		eventName: "PayoutTriggered",
		onLogs: (logs) => {
			for (const log of logs) {
				const args = log.args;
				if (!args.holder || !args.policyId || args.amount === void 0) continue;
				if (holder && args.holder.toLowerCase() !== holder.toLowerCase()) continue;
				onEvent({
					policyId: args.policyId,
					holder: args.holder,
					amount: args.amount,
					riskScore: Number(args.riskScore ?? 0),
					timestamp: BigInt(Math.floor(Date.now() / 1e3)),
					txHash: log.transactionHash
				});
			}
		}
	});
}
function connectDemoWallet() {
	return connectMockWallet();
}
function disconnectDemoWallet() {
	disconnectMockWallet();
}
function getDemoWallet() {
	const mock = getMockState();
	return {
		address: mock.wallet,
		chainId: ARBITRUM_SEPOLIA_CHAIN_ID,
		connected: Boolean(mock.wallet),
		connecting: false,
		isCorrectChain: true,
		hasProvider: true
	};
}
function getDemoBalance() {
	return getMockState().balance;
}
function statusFromCode(code) {
	if (code === 1) return "Claimed";
	if (code === 2) return "Expired";
	return "Active";
}
function useContractRevision() {
	return (0, import_react.useSyncExternalStore)(subscribeContractState, getContractRevision, getContractRevision);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-yayk0u-M.js
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-4 bg-paper px-6 text-center text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "label",
				children: "Fault"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display text-5xl",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-ink-muted",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var wagmiConfig = createConfig({
	chains: [arbitrumSepolia],
	connectors: [injected({ shimDisconnect: true })],
	transports: { [arbitrumSepolia.id]: http(RPC_URL) },
	ssr: true
});
function makeQueryClient() {
	return new QueryClient({ defaultOptions: { queries: {
		staleTime: 4e3,
		refetchOnWindowFocus: false
	} } });
}
function AppProviders({ children }) {
	const [queryClient] = (0, import_react.useState)(makeQueryClient);
	(0, import_react.useEffect)(() => {
		hydrateMock();
		hydrateContractLayer();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WagmiProvider, {
		config: wagmiConfig,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
			client: queryClient,
			children
		})
	});
}
function useWallet() {
	useContractRevision();
	const mock = isMockMode();
	const account = useConnection();
	const { connectAsync, connectors, isPending } = useConnect();
	const { disconnectAsync } = useDisconnect();
	const { switchChainAsync, isPending: isSwitching } = useSwitchChain();
	const injected = connectors.find((c) => c.type === "injected") ?? connectors[0];
	const wallet = (0, import_react.useMemo)(() => {
		if (mock) return getDemoWallet();
		const address = account.address ?? null;
		const chainId = account.chainId ?? 0;
		return {
			address,
			chainId,
			connected: Boolean(address) && account.status === "connected",
			connecting: isPending || account.status === "connecting" || account.status === "reconnecting",
			isCorrectChain: chainId === ARBITRUM_SEPOLIA_CHAIN_ID,
			hasProvider: typeof window !== "undefined" && Boolean(window.ethereum)
		};
	}, [
		mock,
		account.address,
		account.chainId,
		account.status,
		isPending
	]);
	const connect = (0, import_react.useCallback)(async () => {
		if (mock) {
			connectDemoWallet();
			return;
		}
		if (!injected) throw new Error("No injected wallet found. Install MetaMask.");
		await connectAsync({ connector: injected });
	}, [
		mock,
		injected,
		connectAsync
	]);
	const disconnect = (0, import_react.useCallback)(async () => {
		if (mock) {
			disconnectDemoWallet();
			return;
		}
		await disconnectAsync();
	}, [mock, disconnectAsync]);
	const switchNetwork = (0, import_react.useCallback)(async () => {
		if (mock) return;
		await switchChainAsync({ chainId: ARBITRUM_SEPOLIA_CHAIN_ID });
	}, [mock, switchChainAsync]);
	const balance = mock ? getDemoBalance() : null;
	return {
		...wallet,
		mock,
		balance,
		connect,
		disconnect,
		switchNetwork,
		isSwitching
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium tracking-wide transition-[background-color,color,opacity,transform] duration-150 ease-out focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-mint text-mint-fg hover:bg-mint/90",
			ink: "bg-ink text-paper hover:bg-ink/90",
			dark: "bg-dark text-dark-fg hover:bg-dark-2",
			outline: "bg-transparent text-ink shadow-[inset_0_0_0_1px_var(--color-ink)] hover:bg-ink hover:text-paper",
			ghost: "bg-transparent text-ink hover:bg-paper-2",
			mintOutline: "bg-transparent text-mint-fg shadow-[inset_0_0_0_1px_var(--color-ink)] hover:bg-ink hover:text-paper"
		},
		size: {
			sm: "h-10 px-3.5 text-xs",
			md: "h-11 px-4 text-sm",
			lg: "h-12 px-5 text-sm",
			xl: "h-14 px-6 text-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, type = "button", ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
});
Button.displayName = "Button";
function WalletConnect({ compact = false }) {
	const wallet = useWallet();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function onConnect() {
		setError(null);
		try {
			await wallet.connect();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not connect wallet.");
		}
	}
	if (!wallet.connected) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-end gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ink",
				size: compact ? "sm" : "md",
				onClick: () => void onConnect(),
				disabled: wallet.connecting,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-3.5" }), wallet.connecting ? "Connecting" : wallet.mock ? "Connect demo" : "Connect MetaMask"]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-48 text-right text-xs text-rose",
				children: error
			}) : null,
			!wallet.mock && !wallet.hasProvider ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-52 text-right text-xs text-ink-muted",
				children: "MetaMask not detected. Stay in mock mode for the demo."
			}) : null
		]
	});
	if (!wallet.isCorrectChain) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "outline",
		size: compact ? "sm" : "md",
		onClick: () => void wallet.switchNetwork(),
		disabled: wallet.isSwitching,
		children: "Switch to Sepolia"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpen((v) => !v),
			className: cn("flex h-11 items-center gap-2 bg-ink px-3 text-paper transition-colors duration-150 hover:bg-ink/90", compact && "h-10"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "size-1.5 rounded-full bg-mint",
					"aria-hidden": true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs tracking-tight",
					children: wallet.address ? formatAddress(wallet.address) : "Connected"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5 opacity-70" })
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute right-0 z-40 mt-1 w-64 border border-ink bg-paper p-3 shadow-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label",
					children: "Wallet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 break-all font-mono text-xs text-ink",
					children: wallet.address
				}),
				wallet.balance !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 font-mono text-sm tabular-nums",
					children: [formatEth(wallet.balance), " ETH"]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-ink-muted",
					children: wallet.mock ? "Mock wallet · Arbitrum Sepolia" : "Arbitrum Sepolia"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					className: "mt-3 w-full",
					onClick: () => {
						setOpen(false);
						wallet.disconnect();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unplug, { className: "size-3.5" }), "Disconnect"]
				})
			]
		}) : null]
	});
}
var NAV = [
	{
		to: "/",
		label: "Cover"
	},
	{
		to: "/policies",
		label: "Policies"
	},
	{
		to: "/protocol",
		label: "Protocol"
	}
];
function SiteHeader() {
	useContractRevision();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [time, setTime] = (0, import_react.useState)("--:--");
	const mock = isMockMode();
	(0, import_react.useEffect)(() => {
		setTime(clockLabel());
		const id = window.setInterval(() => setTime(clockLabel()), 3e4);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 border-b border-line bg-paper/95 backdrop-blur-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 px-4 py-3 md:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-4 md:gap-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "display text-xl leading-none text-ink md:text-2xl",
						children: "ChainGuard"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center gap-3 font-mono text-[11px] tracking-wide text-ink-muted sm:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: time
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								className: "text-line-strong/30",
								children: "/"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sepolia 421614" })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-5 md:flex",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: cn("text-sm tracking-wide transition-colors duration-150", pathname === item.to ? "text-ink" : "text-ink-muted hover:text-ink"),
						children: item.label
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeSwitch, { mock }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletConnect, { compact: true })]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex gap-1 overflow-x-auto border-t border-line px-4 py-2 md:hidden",
			children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: item.to,
				className: cn("h-9 shrink-0 px-3 text-sm leading-9", pathname === item.to ? "bg-ink text-paper" : "text-ink-muted"),
				children: item.label
			}, item.to))
		})]
	});
}
function ModeSwitch({ mock }) {
	const liveReady = canUseLiveMode();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hidden h-10 items-stretch border border-ink text-[10px] font-medium tracking-widest uppercase sm:flex",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: cn("px-2.5", mock ? "bg-ink text-paper" : "bg-paper text-ink"),
			onClick: () => setMockMode(true),
			children: "Mock"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: cn("px-2.5", !mock ? "bg-ink text-paper" : "bg-paper text-ink", !liveReady && "opacity-50"),
			onClick: () => {
				if (!liveReady) return;
				setMockMode(false);
			},
			title: liveReady ? "Use deployed Sepolia contracts" : "Live mode waits on contract addresses",
			children: "Live"
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-line px-5 py-8 md:border-b-0 md:border-r",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "display text-3xl",
						children: "ChainGuard"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm text-sm text-ink-muted",
						children: "Parametric flood micro-insurance on Arbitrum Sepolia. Cover binds on-chain. Payouts fire on the parameter — not a claims adjuster."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-line px-5 py-8 md:border-b-0 md:border-r",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label",
						children: "Network"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-1 font-mono text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Arbitrum Sepolia" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Chain ID 421614" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Stylus risk engine" })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-dark px-5 py-8 text-dark-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "label text-dark-muted",
						children: "Notice"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-dark-muted",
						children: "Demo product for a hackathon. Not an offer of insurance. Mock mode uses local state; live mode talks to deployed contracts only."
					})]
				})
			]
		})
	});
}
function usePayoutEvents(holder, onEvent) {
	(0, import_react.useEffect)(() => {
		return watchPayouts(holder, onEvent);
	}, [holder, onEvent]);
}
function PayoutToast() {
	const { address } = useWallet();
	usePayoutEvents(address, (0, import_react.useCallback)((event) => {
		toast.custom(() => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-[min(100%,22rem)] border border-ink bg-mint p-4 text-mint-fg shadow-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label text-mint-fg/70",
					children: "Payout triggered"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "display mt-2 text-4xl",
					children: formatEthUnit(event.amount, 3)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 font-mono text-xs",
					children: [
						"Policy #",
						event.policyId.toString().padStart(4, "0"),
						" · risk ",
						event.riskScore
					]
				})
			]
		}), { duration: 8e3 });
	}, []));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		position: "bottom-right",
		visibleToasts: 3,
		offset: 16,
		toastOptions: { unstyled: true }
	});
}
var styles_default = "/assets/styles-B20-EKtY.css";
var APP_NAME = "ChainGuard";
var Route$3 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Parametric flood micro-insurance on Arbitrum Sepolia. Bind cover, watch live risk, settle on the parameter."
			},
			{
				name: "theme-color",
				content: "#141210"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Anton&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&display=swap"
			}
		]
	}),
	component: RootLayout
});
function RootLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "min-h-screen bg-paper text-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppProviders, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-screen flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayoutToast, {})] }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$2 = () => import("./routes-ym1fCore.mjs");
var Route$2 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./policies-B_ktOPzA.mjs");
var Route$1 = createFileRoute("/policies")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./protocol-CAj3mbc7.mjs");
var Route = createFileRoute("/protocol")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$2.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$3
	}),
	PoliciesRoute: Route$1.update({
		id: "/policies",
		path: "/policies",
		getParentRoute: () => Route$3
	}),
	ProtocolRoute: Route.update({
		id: "/protocol",
		path: "/protocol",
		getParentRoute: () => Route$3
	})
};
var routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { useContractRevision as A, parseCoverage as C, riskLabel as D, riskBand as E, seedSamplePolicy as O, padLocationId as S, resetMock as T, getLocation as _, ADDRESSES as a, isMockMode as b, LOCATIONS as c, RPC_URL as d, buyPolicy as f, getAllRiskScores as g, formatUnixDate as h, useWallet as i, simulateFlood as k, MAX_COVERAGE_WEI as l, formatEthUnit as m, Button as n, CHAIN_ID as o, formatAddress as p, cn as r, CONTRACT_ERROR_MESSAGES as s, router_exports as t, MIN_COVERAGE_WEI as u, getPolicies as v, quotePremium as w, locationLabel as x, getRiskScore as y };
