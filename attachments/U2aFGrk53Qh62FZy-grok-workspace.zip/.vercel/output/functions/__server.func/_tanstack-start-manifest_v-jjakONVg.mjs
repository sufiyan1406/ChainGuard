//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-jjakONVg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/policies",
			"/protocol"
		],
		preloads: [
			"/assets/index-DHX0GsbJ.js",
			"/assets/secp256k1-EgKiAGGs.js",
			"/assets/useContractRevision-1KcA53bs.js",
			"/assets/call-D3ChP5Mb.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DHX0GsbJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-phz14niK.js", "/assets/useRiskScore-Chx92olD.js"]
	},
	"/policies": {
		filePath: "/workspace/src/routes/policies.tsx",
		children: void 0,
		preloads: ["/assets/policies-BwyV9NCO.js", "/assets/useRiskScore-Chx92olD.js"]
	},
	"/protocol": {
		filePath: "/workspace/src/routes/protocol.tsx",
		children: void 0,
		preloads: ["/assets/protocol-CUwoO9zo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
