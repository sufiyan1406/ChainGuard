import { n as __exportAll } from "../_runtime.mjs";
import { $ as batchGatewayAbi, $n as AbiErrorNotFoundError, $t as serializeStateOverride, A as getTransactionReceipt, An as toFunctionSelector, B as poll, Bn as stringToBytes, Bt as estimateGas, C as defineCall, Cn as stringify, D as toAmount, Dn as encodeFunctionData, E as resolveTokenWithDecimals, En as solidityError, F as createClient, Fn as isAddress, Ft as parseEventLogs, G as createBatchScheduler, Gn as toHex, Gt as formatBlockParameter, H as simulateContract, Hn as bytesToHex, Ht as fillTransaction, I as formatTransactionReceipt, In as getAddress, It as decodeEventLog, J as encodeDeployData, Jn as hexToNumber, Jt as getGasPrice, K as getCallError, Kn as hexToBigInt, Kt as estimateFeesPerGas, L as sendRawTransaction, Ln as toEventSelector, Lt as formatLog, M as hashTypedData, Mn as slice, N as withTimeout, Nn as concat, O as waitForTransactionReceipt, On as parseAccount, P as bindActionDecorators, Pn as concatHex, Pt as decodeFunctionResult, Q as addressResolverAbi, Qn as AbiErrorInputsNotFoundError, Qt as assertRequest, R as AccountNotFoundError, Rn as keccak256, Rt as isAddressEqual, S as sendRawTransactionSync, Sn as fromEther, T as resolveToken, Tn as decodeAbiParameters, U as readContract, Un as numberToHex, Ut as getChainId, V as observe, Vn as toBytes, Vt as prepareTransactionRequest, W as call, Wn as stringToHex, Wt as getTransactionCount, X as erc6492SignatureValidatorByteCode, Xn as pad, Xt as formatBlock, Y as deploylessCallViaBytecodeBytecode, Yn as trim, Yt as getBlock, Z as multicall3Bytecode, Zn as AbiDecodingZeroDataError, Zt as BlockNotFoundError, _n as getAbortError, an as recoverAuthorizationAddress, ar as DecodeLogTopicsMismatch, at as universalResolverResolveAbi, bn as TransactionNotFoundError, cn as InvalidInputRpcError, cr as size, dn as RpcRequestError, dr as getAction, en as formatTransactionRequest, er as AbiEventNotFoundError, et as erc1271Abi, fn as TimeoutError, gn as RawContractError, hn as ContractFunctionRevertedError, in as UnknownNodeError, ir as DecodeLogDataMismatch, it as textResolverAbi, j as getTransaction, jn as encodeAbiParameters, k as watchBlockNumber, kn as getAbiItem, ln as HttpRequestError, lr as isHex, mn as ContractFunctionExecutionError, nn as getNodeError, nr as AbiFunctionOutputsNotFoundError, nt as erc6492SignatureValidatorAbi, on as recoverAddress, or as InvalidArrayError, ot as universalResolverReverseAbi, pn as CallExecutionError, q as getChainContractAddress, qn as hexToBool, qt as estimateMaxPriorityFeePerGas, rn as ExecutionRevertedError, rr as AbiFunctionSignatureNotFoundError, rt as multicall3Abi, sn as getContractError, sr as BaseError, st as toRpc, tn as extract, tr as AbiFunctionNotFoundError, tt as erc20Abi, un as ResponseBodyTooLargeError, ur as formatAbiItem, vn as getUrl, w as findDeclaredToken, wn as decodeErrorResult, x as createTransport, yn as isAbortError, z as getBlockNumber, zn as hexToBytes, zt as estimateContractGas } from "./@wagmi/core+[...].mjs";
import { t as secp256k1 } from "./noble__curves+noble__hashes.mjs";
import { a as from$1, c as encode, d as validate, i as encodeData, l as from$2, n as wrap, o as from, r as decodeResult, s as getSelector, t as validate$1, u as unwrap } from "./ox.mjs";
//#region node_modules/viem/_esm/errors/log.js
var FilterTypeNotSupportedError = class extends BaseError {
	constructor(type) {
		super(`Filter type "${type}" is not supported.`, { name: "FilterTypeNotSupportedError" });
	}
};
//#endregion
//#region node_modules/viem/_esm/utils/abi/encodeEventTopics.js
var docsPath$2 = "/docs/contract/encodeEventTopics";
function encodeEventTopics(parameters) {
	const { abi, eventName, args } = parameters;
	let abiItem = abi[0];
	if (eventName) {
		const item = getAbiItem({
			abi,
			name: eventName
		});
		if (!item) throw new AbiEventNotFoundError(eventName, { docsPath: docsPath$2 });
		abiItem = item;
	}
	if (abiItem.type !== "event") throw new AbiEventNotFoundError(void 0, { docsPath: docsPath$2 });
	let topics = [];
	if (args && "inputs" in abiItem) {
		const indexedInputs = abiItem.inputs?.filter((param) => "indexed" in param && param.indexed);
		const args_ = Array.isArray(args) ? args : Object.values(args).length > 0 ? indexedInputs?.map((x) => args[x.name]) ?? [] : [];
		if (args_.length > 0) topics = indexedInputs?.map((param, i) => {
			if (Array.isArray(args_[i])) return args_[i].map((_, j) => encodeArg({
				param,
				value: args_[i][j]
			}));
			return typeof args_[i] !== "undefined" && args_[i] !== null ? encodeArg({
				param,
				value: args_[i]
			}) : null;
		}) ?? [];
	}
	if (abiItem.anonymous) return topics;
	const definition = formatAbiItem(abiItem);
	return [toEventSelector(definition), ...topics];
}
function encodeArg({ param, value }) {
	if (param.type === "string" || param.type === "bytes") return keccak256(toBytes(value));
	if (param.type === "tuple" || param.type.match(/^(.*)\[(\d+)?\]$/)) throw new FilterTypeNotSupportedError(param.type);
	return encodeAbiParameters([param], [value]);
}
//#endregion
//#region node_modules/viem/_esm/utils/filters/createFilterRequestScope.js
/**
* Scopes `request` to the filter ID. If the client is a fallback, it will
* listen for responses and scope the child transport `request` function
* to the successful filter ID.
*/
function createFilterRequestScope(client, { method }) {
	const requestMap = {};
	if (client.transport.type === "fallback") client.transport.onResponse?.(({ method: method_, response: id, status, transport }) => {
		if (status === "success" && method === method_) requestMap[id] = transport.request;
	});
	return ((id) => requestMap[id] || client.request);
}
//#endregion
//#region node_modules/viem/_esm/actions/public/createContractEventFilter.js
/**
* Creates a Filter to retrieve event logs that can be used with [`getFilterChanges`](https://viem.sh/docs/actions/public/getFilterChanges) or [`getFilterLogs`](https://viem.sh/docs/actions/public/getFilterLogs).
*
* - Docs: https://viem.sh/docs/contract/createContractEventFilter
*
* @param client - Client to use
* @param parameters - {@link CreateContractEventFilterParameters}
* @returns [`Filter`](https://viem.sh/docs/glossary/types#filter). {@link CreateContractEventFilterReturnType}
*
* @example
* import { createPublicClient, http, parseAbi } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createContractEventFilter } from 'viem/contract'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const filter = await createContractEventFilter(client, {
*   abi: parseAbi(['event Transfer(address indexed, address indexed, uint256)']),
* })
*/
async function createContractEventFilter(client, parameters) {
	const { address, abi, args, eventName, fromBlock, strict, toBlock } = parameters;
	const getRequest = createFilterRequestScope(client, { method: "eth_newFilter" });
	const topics = eventName ? encodeEventTopics({
		abi,
		args,
		eventName
	}) : void 0;
	const id = await client.request({
		method: "eth_newFilter",
		params: [{
			address,
			fromBlock: typeof fromBlock === "bigint" ? numberToHex(fromBlock) : fromBlock,
			toBlock: typeof toBlock === "bigint" ? numberToHex(toBlock) : toBlock,
			topics
		}]
	});
	return {
		abi,
		args,
		eventName,
		id,
		request: getRequest(id),
		strict: Boolean(strict),
		type: "event"
	};
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getLogs.js
/**
* Returns a list of event logs matching the provided parameters.
*
* - Docs: https://viem.sh/docs/actions/public/getLogs
* - Examples: https://stackblitz.com/github/wevm/viem/tree/main/examples/logs_event-logs
* - JSON-RPC Methods: [`eth_getLogs`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getlogs)
*
* @param client - Client to use
* @param parameters - {@link GetLogsParameters}
* @returns A list of event logs. {@link GetLogsReturnType}
*
* @example
* import { createPublicClient, http, parseAbiItem } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getLogs } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const logs = await getLogs(client)
*/
async function getLogs(client, { address, blockHash, fromBlock, toBlock, event, events: events_, args, strict: strict_ } = {}) {
	const strict = strict_ ?? false;
	const events = events_ ?? (event ? [event] : void 0);
	let topics = [];
	if (events) {
		topics = [events.flatMap((event) => encodeEventTopics({
			abi: [event],
			eventName: event.name,
			args: events_ ? void 0 : args
		}))];
		if (event) topics = topics[0];
	}
	let logs;
	if (blockHash) logs = await client.request({
		method: "eth_getLogs",
		params: [{
			address,
			topics,
			blockHash
		}]
	});
	else logs = await client.request({
		method: "eth_getLogs",
		params: [{
			address,
			topics,
			fromBlock: typeof fromBlock === "bigint" ? numberToHex(fromBlock) : fromBlock,
			toBlock: typeof toBlock === "bigint" ? numberToHex(toBlock) : toBlock
		}]
	});
	const formattedLogs = logs.map((log) => formatLog(log));
	if (!events) return formattedLogs;
	return parseEventLogs({
		abi: events,
		args,
		logs: formattedLogs,
		strict
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getContractEvents.js
/**
* Returns a list of event logs emitted by a contract.
*
* - Docs: https://viem.sh/docs/contract/getContractEvents#getcontractevents
* - JSON-RPC Methods: [`eth_getLogs`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getlogs)
*
* @param client - Client to use
* @param parameters - {@link GetContractEventsParameters}
* @returns A list of event logs. {@link GetContractEventsReturnType}
*
* @example
* import { createClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getContractEvents } from 'viem/public'
* import { wagmiAbi } from './abi'
*
* const client = createClient({
*   chain: mainnet,
*   transport: http(),
* })
* const logs = await getContractEvents(client, {
*  address: '0xFBA3912Ca04dd458c843e2EE08967fC04f3579c2',
*  abi: wagmiAbi,
*  eventName: 'Transfer'
* })
*/
async function getContractEvents(client, parameters) {
	const { abi, address, args, blockHash, eventName, fromBlock, toBlock, strict } = parameters;
	const event = eventName ? getAbiItem({
		abi,
		name: eventName
	}) : void 0;
	const events = !event ? abi.filter((x) => x.type === "event") : void 0;
	return getAction(client, getLogs, "getLogs")({
		address,
		args,
		blockHash,
		event,
		events,
		fromBlock,
		toBlock,
		strict
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getFilterChanges.js
/**
* Returns a list of logs or hashes based on a [Filter](/docs/glossary/terms#filter) since the last time it was called.
*
* - Docs: https://viem.sh/docs/actions/public/getFilterChanges
* - JSON-RPC Methods: [`eth_getFilterChanges`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getfilterchanges)
*
* A Filter can be created from the following actions:
*
* - [`createBlockFilter`](https://viem.sh/docs/actions/public/createBlockFilter)
* - [`createContractEventFilter`](https://viem.sh/docs/contract/createContractEventFilter)
* - [`createEventFilter`](https://viem.sh/docs/actions/public/createEventFilter)
* - [`createPendingTransactionFilter`](https://viem.sh/docs/actions/public/createPendingTransactionFilter)
*
* Depending on the type of filter, the return value will be different:
*
* - If the filter was created with `createContractEventFilter` or `createEventFilter`, it returns a list of logs.
* - If the filter was created with `createPendingTransactionFilter`, it returns a list of transaction hashes.
* - If the filter was created with `createBlockFilter`, it returns a list of block hashes.
*
* @param client - Client to use
* @param parameters - {@link GetFilterChangesParameters}
* @returns Logs or hashes. {@link GetFilterChangesReturnType}
*
* @example
* // Blocks
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createBlockFilter, getFilterChanges } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const filter = await createBlockFilter(client)
* const hashes = await getFilterChanges(client, { filter })
*
* @example
* // Contract Events
* import { createPublicClient, http, parseAbi } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createContractEventFilter, getFilterChanges } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const filter = await createContractEventFilter(client, {
*   address: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
*   abi: parseAbi(['event Transfer(address indexed, address indexed, uint256)']),
*   eventName: 'Transfer',
* })
* const logs = await getFilterChanges(client, { filter })
*
* @example
* // Raw Events
* import { createPublicClient, http, parseAbiItem } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createEventFilter, getFilterChanges } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const filter = await createEventFilter(client, {
*   address: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
*   event: parseAbiItem('event Transfer(address indexed, address indexed, uint256)'),
* })
* const logs = await getFilterChanges(client, { filter })
*
* @example
* // Transactions
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createPendingTransactionFilter, getFilterChanges } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const filter = await createPendingTransactionFilter(client)
* const hashes = await getFilterChanges(client, { filter })
*/
async function getFilterChanges(_client, { filter }) {
	const strict = "strict" in filter && filter.strict;
	const logs = await filter.request({
		method: "eth_getFilterChanges",
		params: [filter.id]
	});
	if (typeof logs[0] === "string") return logs;
	const formattedLogs = logs.map((log) => formatLog(log));
	if (!("abi" in filter) || !filter.abi) return formattedLogs;
	return parseEventLogs({
		abi: filter.abi,
		logs: formattedLogs,
		strict
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/public/uninstallFilter.js
/**
* Destroys a [`Filter`](https://viem.sh/docs/glossary/types#filter).
*
* - Docs: https://viem.sh/docs/actions/public/uninstallFilter
* - JSON-RPC Methods: [`eth_uninstallFilter`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_uninstallFilter)
*
* Destroys a Filter that was created from one of the following Actions:
* - [`createBlockFilter`](https://viem.sh/docs/actions/public/createBlockFilter)
* - [`createEventFilter`](https://viem.sh/docs/actions/public/createEventFilter)
* - [`createPendingTransactionFilter`](https://viem.sh/docs/actions/public/createPendingTransactionFilter)
*
* @param client - Client to use
* @param parameters - {@link UninstallFilterParameters}
* @returns A boolean indicating if the Filter was successfully uninstalled. {@link UninstallFilterReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createPendingTransactionFilter, uninstallFilter } from 'viem/public'
*
* const filter = await createPendingTransactionFilter(client)
* const uninstalled = await uninstallFilter(client, { filter })
* // true
*/
async function uninstallFilter(_client, { filter }) {
	return filter.request({
		method: "eth_uninstallFilter",
		params: [filter.id]
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/public/watchContractEvent.js
/**
* Watches and returns emitted contract event logs.
*
* - Docs: https://viem.sh/docs/contract/watchContractEvent
*
* This Action will batch up all the event logs found within the [`pollingInterval`](https://viem.sh/docs/contract/watchContractEvent#pollinginterval-optional), and invoke them via [`onLogs`](https://viem.sh/docs/contract/watchContractEvent#onLogs).
*
* `watchContractEvent` will attempt to create an [Event Filter](https://viem.sh/docs/contract/createContractEventFilter) and listen to changes to the Filter per polling interval, however, if the RPC Provider does not support Filters (e.g. `eth_newFilter`), then `watchContractEvent` will fall back to using [`getLogs`](https://viem.sh/docs/actions/public/getLogs) instead.
*
* @param client - Client to use
* @param parameters - {@link WatchContractEventParameters}
* @returns A function that can be invoked to stop watching for new event logs. {@link WatchContractEventReturnType}
*
* @example
* import { createPublicClient, http, parseAbi } from 'viem'
* import { mainnet } from 'viem/chains'
* import { watchContractEvent } from 'viem/contract'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const unwatch = watchContractEvent(client, {
*   address: '0xFBA3912Ca04dd458c843e2EE08967fC04f3579c2',
*   abi: parseAbi(['event Transfer(address indexed from, address indexed to, uint256 value)']),
*   eventName: 'Transfer',
*   args: { from: '0xc961145a54C96E3aE9bAA048c4F4D6b04C13916b' },
*   onLogs: (logs) => console.log(logs),
* })
*/
function watchContractEvent(client, parameters) {
	const { abi, address, args, batch = true, eventName, fromBlock, onError, onLogs, poll: poll_, pollingInterval = client.pollingInterval, strict: strict_ } = parameters;
	const enablePolling = (() => {
		if (typeof poll_ !== "undefined") return poll_;
		if (typeof fromBlock === "bigint") return true;
		if (client.transport.type === "webSocket" || client.transport.type === "ipc") return false;
		if (client.transport.type === "fallback" && (client.transport.transports[0].config.type === "webSocket" || client.transport.transports[0].config.type === "ipc")) return false;
		return true;
	})();
	const pollContractEvent = () => {
		const strict = strict_ ?? false;
		const observerId = stringify([
			"watchContractEvent",
			address,
			args,
			batch,
			client.uid,
			eventName,
			pollingInterval,
			strict,
			fromBlock
		]);
		return observe(observerId, {
			onLogs,
			onError
		}, (emit) => {
			let previousBlockNumber;
			if (fromBlock !== void 0) previousBlockNumber = fromBlock - 1n;
			let filter;
			let initialized = false;
			const unwatch = poll(async () => {
				if (!initialized) {
					try {
						filter = await getAction(client, createContractEventFilter, "createContractEventFilter")({
							abi,
							address,
							args,
							eventName,
							strict,
							fromBlock
						});
					} catch {}
					initialized = true;
					return;
				}
				try {
					let logs;
					if (filter) logs = await getAction(client, getFilterChanges, "getFilterChanges")({ filter });
					else {
						const blockNumber = await getAction(client, getBlockNumber, "getBlockNumber")({});
						if (previousBlockNumber && previousBlockNumber < blockNumber) logs = await getAction(client, getContractEvents, "getContractEvents")({
							abi,
							address,
							args,
							eventName,
							fromBlock: previousBlockNumber + 1n,
							toBlock: blockNumber,
							strict
						});
						else logs = [];
						previousBlockNumber = blockNumber;
					}
					if (logs.length === 0) return;
					if (batch) emit.onLogs(logs);
					else for (const log of logs) emit.onLogs([log]);
				} catch (err) {
					if (filter && err instanceof InvalidInputRpcError) initialized = false;
					emit.onError?.(err);
				}
			}, {
				emitOnBegin: true,
				interval: pollingInterval
			});
			return async () => {
				if (filter) await getAction(client, uninstallFilter, "uninstallFilter")({ filter });
				unwatch();
			};
		});
	};
	const subscribeContractEvent = () => {
		const strict = strict_ ?? false;
		const observerId = stringify([
			"watchContractEvent",
			address,
			args,
			batch,
			client.uid,
			eventName,
			pollingInterval,
			strict
		]);
		let active = true;
		let unsubscribe = () => active = false;
		return observe(observerId, {
			onLogs,
			onError
		}, (emit) => {
			(async () => {
				try {
					const transport = (() => {
						if (client.transport.type === "fallback") {
							const transport = client.transport.transports.find((transport) => transport.config.type === "webSocket" || transport.config.type === "ipc");
							if (!transport) return client.transport;
							return transport.value;
						}
						return client.transport;
					})();
					const topics = eventName ? encodeEventTopics({
						abi,
						eventName,
						args
					}) : [];
					const { unsubscribe: unsubscribe_ } = await transport.subscribe({
						params: ["logs", {
							address,
							topics
						}],
						onData(data) {
							if (!active) return;
							const log = data.result;
							try {
								const { eventName, args } = decodeEventLog({
									abi,
									data: log.data,
									topics: log.topics,
									strict: strict_
								});
								const formatted = formatLog(log, {
									args,
									eventName
								});
								emit.onLogs([formatted]);
							} catch (err) {
								let eventName;
								let isUnnamed;
								if (err instanceof DecodeLogDataMismatch || err instanceof DecodeLogTopicsMismatch) {
									if (strict_) return;
									eventName = err.abiItem.name;
									isUnnamed = err.abiItem.inputs?.some((x) => !("name" in x && x.name));
								}
								const formatted = formatLog(log, {
									args: isUnnamed ? [] : {},
									eventName
								});
								emit.onLogs([formatted]);
							}
						},
						onError(error) {
							emit.onError?.(error);
						}
					});
					unsubscribe = unsubscribe_;
					if (!active) unsubscribe();
				} catch (err) {
					onError?.(err);
				}
			})();
			return () => unsubscribe();
		});
	};
	return enablePolling ? pollContractEvent() : subscribeContractEvent();
}
//#endregion
//#region node_modules/viem/_esm/utils/ens/errors.js
function isNullUniversalResolverError(err) {
	if (!(err instanceof BaseError)) return false;
	const cause = err.walk((e) => e instanceof ContractFunctionRevertedError);
	if (!(cause instanceof ContractFunctionRevertedError)) return false;
	if (cause.data?.errorName === "HttpError") return true;
	if (cause.data?.errorName === "ResolverError") return true;
	if (cause.data?.errorName === "ResolverNotContract") return true;
	if (cause.data?.errorName === "ResolverNotFound") return true;
	if (cause.data?.errorName === "ReverseAddressMismatch") return true;
	if (cause.data?.errorName === "UnsupportedResolverProfile") return true;
	return false;
}
//#endregion
//#region node_modules/viem/_esm/utils/abi/decodeFunctionData.js
function decodeFunctionData(parameters) {
	const { abi, data } = parameters;
	const signature = slice(data, 0, 4);
	const description = abi.find((x) => x.type === "function" && signature === toFunctionSelector(formatAbiItem(x)));
	if (!description) throw new AbiFunctionSignatureNotFoundError(signature, { docsPath: "/docs/contract/decodeFunctionData" });
	return {
		functionName: description.name,
		args: "inputs" in description && description.inputs && description.inputs.length > 0 ? decodeAbiParameters(description.inputs, slice(data, 4)) : void 0
	};
}
//#endregion
//#region node_modules/viem/_esm/utils/abi/encodeErrorResult.js
var docsPath$1 = "/docs/contract/encodeErrorResult";
function encodeErrorResult(parameters) {
	const { abi, errorName, args } = parameters;
	let abiItem = abi[0];
	if (errorName) {
		const item = getAbiItem({
			abi,
			args,
			name: errorName
		});
		if (!item) throw new AbiErrorNotFoundError(errorName, { docsPath: docsPath$1 });
		abiItem = item;
	}
	if (abiItem.type !== "error") throw new AbiErrorNotFoundError(void 0, { docsPath: docsPath$1 });
	const definition = formatAbiItem(abiItem);
	const signature = toFunctionSelector(definition);
	let data = "0x";
	if (args && args.length > 0) {
		if (!abiItem.inputs) throw new AbiErrorInputsNotFoundError(abiItem.name, { docsPath: docsPath$1 });
		data = encodeAbiParameters(abiItem.inputs, args);
	}
	return concatHex([signature, data]);
}
//#endregion
//#region node_modules/viem/_esm/utils/abi/encodeFunctionResult.js
var docsPath = "/docs/contract/encodeFunctionResult";
function encodeFunctionResult(parameters) {
	const { abi, functionName, result } = parameters;
	let abiItem = abi[0];
	if (functionName) {
		const item = getAbiItem({
			abi,
			name: functionName
		});
		if (!item) throw new AbiFunctionNotFoundError(functionName, { docsPath });
		abiItem = item;
	}
	if (abiItem.type !== "function") throw new AbiFunctionNotFoundError(void 0, { docsPath });
	if (!abiItem.outputs) throw new AbiFunctionOutputsNotFoundError(abiItem.name, { docsPath });
	const values = (() => {
		if (abiItem.outputs.length === 0) return [];
		if (abiItem.outputs.length === 1) return [result];
		if (Array.isArray(result)) return result;
		throw new InvalidArrayError(result);
	})();
	return encodeAbiParameters(abiItem.outputs, values);
}
async function localBatchGatewayRequest(parameters) {
	const { data, ccipRequest } = parameters;
	const { args: [queries] } = decodeFunctionData({
		abi: batchGatewayAbi,
		data
	});
	const failures = [];
	const responses = [];
	await Promise.all(queries.map(async (query, i) => {
		try {
			responses[i] = query.urls.includes("x-batch-gateway:true") ? await localBatchGatewayRequest({
				data: query.data,
				ccipRequest
			}) : await ccipRequest(query);
			failures[i] = false;
		} catch (err) {
			failures[i] = true;
			responses[i] = encodeError(err);
		}
	}));
	return encodeFunctionResult({
		abi: batchGatewayAbi,
		functionName: "query",
		result: [failures, responses]
	});
}
function encodeError(error) {
	if (error.name === "HttpRequestError" && error.status) return encodeErrorResult({
		abi: batchGatewayAbi,
		errorName: "HttpError",
		args: [error.status, error.shortMessage]
	});
	return encodeErrorResult({
		abi: [solidityError],
		errorName: "Error",
		args: ["shortMessage" in error ? error.shortMessage : error.message]
	});
}
//#endregion
//#region node_modules/viem/_esm/utils/ens/encodedLabelToLabelhash.js
function encodedLabelToLabelhash(label) {
	if (label.length !== 66) return null;
	if (label.indexOf("[") !== 0) return null;
	if (label.indexOf("]") !== 65) return null;
	const hash = `0x${label.slice(1, 65)}`;
	if (!isHex(hash)) return null;
	return hash;
}
//#endregion
//#region node_modules/viem/_esm/utils/ens/namehash.js
/**
* @description Hashes ENS name
*
* - Since ENS names prohibit certain forbidden characters (e.g. underscore) and have other validation rules, you likely want to [normalize ENS names](https://docs.ens.domains/contract-api-reference/name-processing#normalising-names) with [UTS-46 normalization](https://unicode.org/reports/tr46) before passing them to `namehash`. You can use the built-in [`normalize`](https://viem.sh/docs/ens/utilities/normalize) function for this.
*
* @example
* namehash('wevm.eth')
* '0x08c85f2f4059e930c45a6aeff9dcd3bd95dc3c5c1cddef6a0626b31152248560'
*
* @link https://eips.ethereum.org/EIPS/eip-137
*/
function namehash(name) {
	let result = (/* @__PURE__ */ new Uint8Array(32)).fill(0);
	if (!name) return bytesToHex(result);
	const labels = name.split(".");
	for (let i = labels.length - 1; i >= 0; i -= 1) {
		const hashFromEncodedLabel = encodedLabelToLabelhash(labels[i]);
		const hashed = hashFromEncodedLabel ? toBytes(hashFromEncodedLabel) : keccak256(stringToBytes(labels[i]), "bytes");
		result = keccak256(concat([result, hashed]), "bytes");
	}
	return bytesToHex(result);
}
//#endregion
//#region node_modules/viem/_esm/utils/ens/encodeLabelhash.js
function encodeLabelhash(hash) {
	return `[${hash.slice(2)}]`;
}
//#endregion
//#region node_modules/viem/_esm/utils/ens/labelhash.js
/**
* @description Hashes ENS label
*
* - Since ENS labels prohibit certain forbidden characters (e.g. underscore) and have other validation rules, you likely want to [normalize ENS labels](https://docs.ens.domains/contract-api-reference/name-processing#normalising-names) with [UTS-46 normalization](https://unicode.org/reports/tr46) before passing them to `labelhash`. You can use the built-in [`normalize`](https://viem.sh/docs/ens/utilities/normalize) function for this.
*
* @example
* labelhash('eth')
* '0x4f5b812789fc606be1b3b16908db13fc7a9adf7ca72641f84d75b47069d3d7f0'
*/
function labelhash(label) {
	const result = (/* @__PURE__ */ new Uint8Array(32)).fill(0);
	if (!label) return bytesToHex(result);
	return encodedLabelToLabelhash(label) || keccak256(stringToBytes(label));
}
//#endregion
//#region node_modules/viem/_esm/utils/ens/packetToBytes.js
function packetToBytes(packet) {
	const value = packet.replace(/^\.|\.$/gm, "");
	if (value.length === 0) return /* @__PURE__ */ new Uint8Array(1);
	const bytes = new Uint8Array(stringToBytes(value).byteLength + 2);
	let offset = 0;
	const list = value.split(".");
	for (let i = 0; i < list.length; i++) {
		let encoded = stringToBytes(list[i]);
		if (encoded.byteLength > 255) encoded = stringToBytes(encodeLabelhash(labelhash(list[i])));
		bytes[offset] = encoded.length;
		bytes.set(encoded, offset + 1);
		offset += encoded.length + 1;
	}
	if (bytes.byteLength !== offset + 1) return bytes.slice(0, offset + 1);
	return bytes;
}
//#endregion
//#region node_modules/viem/_esm/actions/ens/getEnsAddress.js
/**
* Gets address for ENS name.
*
* - Docs: https://viem.sh/docs/ens/actions/getEnsAddress
* - Examples: https://stackblitz.com/github/wevm/viem/tree/main/examples/ens
*
* Calls `resolve(bytes, bytes)` on ENS Universal Resolver Contract.
*
* Since ENS names prohibit certain forbidden characters (e.g. underscore) and have other validation rules, you likely want to [normalize ENS names](https://docs.ens.domains/contract-api-reference/name-processing#normalising-names) with [UTS-46 normalization](https://unicode.org/reports/tr46) before passing them to `getEnsAddress`. You can use the built-in [`normalize`](https://viem.sh/docs/ens/utilities/normalize) function for this.
*
* @param client - Client to use
* @param parameters - {@link GetEnsAddressParameters}
* @returns Address for ENS name or `null` if not found. {@link GetEnsAddressReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getEnsAddress, normalize } from 'viem/ens'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const ensAddress = await getEnsAddress(client, {
*   name: normalize('wevm.eth'),
* })
* // '0xd2135CfB216b74109775236E36d4b433F1DF507B'
*/
async function getEnsAddress(client, parameters) {
	const { blockNumber, blockTag, coinType, name, gatewayUrls, strict } = parameters;
	const { chain } = client;
	const universalResolverAddress = (() => {
		if (parameters.universalResolverAddress) return parameters.universalResolverAddress;
		if (!chain) throw new Error("client chain not configured. universalResolverAddress is required.");
		return getChainContractAddress({
			blockNumber,
			chain,
			contract: "ensUniversalResolver"
		});
	})();
	const tlds = chain?.ensTlds;
	if (tlds && !tlds.some((tld) => name.endsWith(tld))) return null;
	const args = (() => {
		if (coinType != null) return [namehash(name), BigInt(coinType)];
		return [namehash(name)];
	})();
	try {
		const functionData = encodeFunctionData({
			abi: addressResolverAbi,
			functionName: "addr",
			args
		});
		const readContractParameters = {
			address: universalResolverAddress,
			abi: universalResolverResolveAbi,
			functionName: "resolveWithGateways",
			args: [
				toHex(packetToBytes(name)),
				functionData,
				gatewayUrls ?? ["x-batch-gateway:true"]
			],
			blockNumber,
			blockTag
		};
		const res = await getAction(client, readContract, "readContract")(readContractParameters);
		if (res[0] === "0x") return null;
		const address = decodeAddress({
			coinType,
			data: res[0],
			args
		});
		if (address === "0x") return null;
		if (trim(address) === "0x00") return null;
		return address;
	} catch (err) {
		if (strict) throw err;
		if (isNullUniversalResolverError(err)) return null;
		throw err;
	}
}
function decodeAddress({ coinType, data, args }) {
	try {
		return decodeFunctionResult({
			abi: addressResolverAbi,
			args,
			functionName: "addr",
			data
		});
	} catch (err) {
		if (coinType == null) throw err;
		const address = trim(data);
		if (size(address) === 20) return getAddress(address);
		throw err;
	}
}
//#endregion
//#region node_modules/viem/_esm/errors/ens.js
var EnsAvatarInvalidMetadataError = class extends BaseError {
	constructor({ data }) {
		super("Unable to extract image from metadata. The metadata may be malformed or invalid.", {
			metaMessages: [
				"- Metadata must be a JSON object with at least an `image`, `image_url` or `image_data` property.",
				"",
				`Provided data: ${JSON.stringify(data)}`
			],
			name: "EnsAvatarInvalidMetadataError"
		});
	}
};
var EnsAvatarInvalidNftUriError = class extends BaseError {
	constructor({ reason }) {
		super(`ENS NFT avatar URI is invalid. ${reason}`, { name: "EnsAvatarInvalidNftUriError" });
	}
};
var EnsAvatarUriResolutionError = class extends BaseError {
	constructor({ uri }) {
		super(`Unable to resolve ENS avatar URI "${uri}". The URI may be malformed, invalid, or does not respond with a valid image.`, { name: "EnsAvatarUriResolutionError" });
	}
};
var EnsAvatarUnsupportedNamespaceError = class extends BaseError {
	constructor({ namespace }) {
		super(`ENS NFT avatar namespace "${namespace}" is not supported. Must be "erc721" or "erc1155".`, { name: "EnsAvatarUnsupportedNamespaceError" });
	}
};
//#endregion
//#region node_modules/viem/_esm/utils/ens/avatar/utils.js
var networkRegex = /(?<protocol>https?:\/\/[^/]*|ipfs:\/|ipns:\/|ar:\/)?(?<root>\/)?(?<subpath>ipfs\/|ipns\/)?(?<target>[\w\-.]+)(?<subtarget>\/.*)?/;
var ipfsHashRegex = /^(Qm[1-9A-HJ-NP-Za-km-z]{44,}|b[A-Za-z2-7]{58,}|B[A-Z2-7]{58,}|z[1-9A-HJ-NP-Za-km-z]{48,}|F[0-9A-F]{50,})(\/(?<target>[\w\-.]+))?(?<subtarget>\/.*)?$/;
var base64Regex = /^data:([a-zA-Z\-/+]*);base64,([^"].*)/;
var dataURIRegex = /^data:([a-zA-Z\-/+]*)?(;[a-zA-Z0-9].*?)?(,)/;
/** @internal */
async function isImageUri(uri) {
	try {
		const res = await fetch(uri, { method: "HEAD" });
		if (res.status === 200) return res.headers.get("content-type")?.startsWith("image/");
		return false;
	} catch (error) {
		if (typeof error === "object" && typeof error.response !== "undefined") return false;
		if (!Object.hasOwn(globalThis, "Image")) return false;
		return new Promise((resolve) => {
			const img = new Image();
			img.onload = () => {
				resolve(true);
			};
			img.onerror = () => {
				resolve(false);
			};
			img.src = uri;
		});
	}
}
/** @internal */
function getGateway(custom, defaultGateway) {
	if (!custom) return defaultGateway;
	if (custom.endsWith("/")) return custom.slice(0, -1);
	return custom;
}
function resolveAvatarUri({ uri, gatewayUrls }) {
	const isEncoded = base64Regex.test(uri);
	if (isEncoded) return {
		uri,
		isOnChain: true,
		isEncoded
	};
	const ipfsGateway = getGateway(gatewayUrls?.ipfs, "https://ipfs.io");
	const arweaveGateway = getGateway(gatewayUrls?.arweave, "https://arweave.net");
	const { protocol, subpath, target, subtarget = "" } = uri.match(networkRegex)?.groups || {};
	const isIPNS = protocol === "ipns:/" || subpath === "ipns/";
	const isIPFS = protocol === "ipfs:/" || subpath === "ipfs/" || ipfsHashRegex.test(uri);
	if (uri.startsWith("http") && !isIPNS && !isIPFS) {
		let replacedUri = uri;
		if (gatewayUrls?.arweave) replacedUri = uri.replace(/https:\/\/arweave.net/g, gatewayUrls?.arweave);
		return {
			uri: replacedUri,
			isOnChain: false,
			isEncoded: false
		};
	}
	if ((isIPNS || isIPFS) && target) return {
		uri: `${ipfsGateway}/${isIPNS ? "ipns" : "ipfs"}/${target}${subtarget}`,
		isOnChain: false,
		isEncoded: false
	};
	if (protocol === "ar:/" && target) return {
		uri: `${arweaveGateway}/${target}${subtarget || ""}`,
		isOnChain: false,
		isEncoded: false
	};
	let parsedUri = uri.replace(dataURIRegex, "");
	if (parsedUri.startsWith("<svg")) parsedUri = `data:image/svg+xml;base64,${btoa(parsedUri)}`;
	if (parsedUri.startsWith("data:") || parsedUri.startsWith("{")) return {
		uri: parsedUri,
		isOnChain: true,
		isEncoded: false
	};
	throw new EnsAvatarUriResolutionError({ uri });
}
function getJsonImage(data) {
	if (typeof data !== "object" || !("image" in data) && !("image_url" in data) && !("image_data" in data)) throw new EnsAvatarInvalidMetadataError({ data });
	return data.image || data.image_url || data.image_data;
}
async function getMetadataAvatarUri({ gatewayUrls, uri }) {
	try {
		return await parseAvatarUri({
			gatewayUrls,
			uri: getJsonImage(await fetch(uri).then((res) => res.json()))
		});
	} catch {
		throw new EnsAvatarUriResolutionError({ uri });
	}
}
async function parseAvatarUri({ gatewayUrls, uri }) {
	const { uri: resolvedURI, isOnChain } = resolveAvatarUri({
		uri,
		gatewayUrls
	});
	if (isOnChain) return resolvedURI;
	if (await isImageUri(resolvedURI)) return resolvedURI;
	throw new EnsAvatarUriResolutionError({ uri });
}
function parseNftUri(uri_) {
	let uri = uri_;
	if (uri.startsWith("did:nft:")) uri = uri.replace("did:nft:", "").replace(/_/g, "/");
	const [reference, asset_namespace, tokenID] = uri.split("/");
	const [eip_namespace, chainID] = reference.split(":");
	const [erc_namespace, contractAddress] = asset_namespace.split(":");
	if (!eip_namespace || eip_namespace.toLowerCase() !== "eip155") throw new EnsAvatarInvalidNftUriError({ reason: "Only EIP-155 supported" });
	if (!chainID) throw new EnsAvatarInvalidNftUriError({ reason: "Chain ID not found" });
	if (!contractAddress) throw new EnsAvatarInvalidNftUriError({ reason: "Contract address not found" });
	if (!tokenID) throw new EnsAvatarInvalidNftUriError({ reason: "Token ID not found" });
	if (!erc_namespace) throw new EnsAvatarInvalidNftUriError({ reason: "ERC namespace not found" });
	return {
		chainID: Number.parseInt(chainID, 10),
		namespace: erc_namespace.toLowerCase(),
		contractAddress,
		tokenID
	};
}
async function getNftTokenUri(client, { nft }) {
	if (nft.namespace === "erc721") return readContract(client, {
		address: nft.contractAddress,
		abi: [{
			name: "tokenURI",
			type: "function",
			stateMutability: "view",
			inputs: [{
				name: "tokenId",
				type: "uint256"
			}],
			outputs: [{
				name: "",
				type: "string"
			}]
		}],
		functionName: "tokenURI",
		args: [BigInt(nft.tokenID)]
	});
	if (nft.namespace === "erc1155") return readContract(client, {
		address: nft.contractAddress,
		abi: [{
			name: "uri",
			type: "function",
			stateMutability: "view",
			inputs: [{
				name: "_id",
				type: "uint256"
			}],
			outputs: [{
				name: "",
				type: "string"
			}]
		}],
		functionName: "uri",
		args: [BigInt(nft.tokenID)]
	});
	throw new EnsAvatarUnsupportedNamespaceError({ namespace: nft.namespace });
}
//#endregion
//#region node_modules/viem/_esm/utils/ens/avatar/parseAvatarRecord.js
async function parseAvatarRecord(client, { gatewayUrls, record }) {
	if (/eip155:/i.test(record)) return parseNftAvatarUri(client, {
		gatewayUrls,
		record
	});
	return parseAvatarUri({
		uri: record,
		gatewayUrls
	});
}
async function parseNftAvatarUri(client, { gatewayUrls, record }) {
	const nft = parseNftUri(record);
	const { uri: resolvedNftUri, isOnChain, isEncoded } = resolveAvatarUri({
		uri: await getNftTokenUri(client, { nft }),
		gatewayUrls
	});
	if (isOnChain && (resolvedNftUri.includes("data:application/json;base64,") || resolvedNftUri.startsWith("{"))) {
		const encodedJson = isEncoded ? atob(resolvedNftUri.replace("data:application/json;base64,", "")) : resolvedNftUri;
		return parseAvatarUri({
			uri: getJsonImage(JSON.parse(encodedJson)),
			gatewayUrls
		});
	}
	let uriTokenId = nft.tokenID;
	if (nft.namespace === "erc1155") uriTokenId = uriTokenId.replace("0x", "").padStart(64, "0");
	return getMetadataAvatarUri({
		gatewayUrls,
		uri: resolvedNftUri.replace(/(?:0x)?{id}/, uriTokenId)
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/ens/getEnsText.js
/**
* Gets a text record for specified ENS name.
*
* - Docs: https://viem.sh/docs/ens/actions/getEnsResolver
* - Examples: https://stackblitz.com/github/wevm/viem/tree/main/examples/ens
*
* Calls `resolve(bytes, bytes)` on ENS Universal Resolver Contract.
*
* Since ENS names prohibit certain forbidden characters (e.g. underscore) and have other validation rules, you likely want to [normalize ENS names](https://docs.ens.domains/contract-api-reference/name-processing#normalising-names) with [UTS-46 normalization](https://unicode.org/reports/tr46) before passing them to `getEnsAddress`. You can use the built-in [`normalize`](https://viem.sh/docs/ens/utilities/normalize) function for this.
*
* @param client - Client to use
* @param parameters - {@link GetEnsTextParameters}
* @returns Address for ENS resolver. {@link GetEnsTextReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getEnsText, normalize } from 'viem/ens'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const twitterRecord = await getEnsText(client, {
*   name: normalize('wevm.eth'),
*   key: 'com.twitter',
* })
* // 'wevm_dev'
*/
async function getEnsText(client, parameters) {
	const { blockNumber, blockTag, key, name, gatewayUrls, strict } = parameters;
	const { chain } = client;
	const universalResolverAddress = (() => {
		if (parameters.universalResolverAddress) return parameters.universalResolverAddress;
		if (!chain) throw new Error("client chain not configured. universalResolverAddress is required.");
		return getChainContractAddress({
			blockNumber,
			chain,
			contract: "ensUniversalResolver"
		});
	})();
	const tlds = chain?.ensTlds;
	if (tlds && !tlds.some((tld) => name.endsWith(tld))) return null;
	try {
		const readContractParameters = {
			address: universalResolverAddress,
			abi: universalResolverResolveAbi,
			args: [
				toHex(packetToBytes(name)),
				encodeFunctionData({
					abi: textResolverAbi,
					functionName: "text",
					args: [namehash(name), key]
				}),
				gatewayUrls ?? ["x-batch-gateway:true"]
			],
			functionName: "resolveWithGateways",
			blockNumber,
			blockTag
		};
		const res = await getAction(client, readContract, "readContract")(readContractParameters);
		if (res[0] === "0x") return null;
		const record = decodeFunctionResult({
			abi: textResolverAbi,
			functionName: "text",
			data: res[0]
		});
		return record === "" ? null : record;
	} catch (err) {
		if (strict) throw err;
		if (isNullUniversalResolverError(err)) return null;
		throw err;
	}
}
//#endregion
//#region node_modules/viem/_esm/actions/ens/getEnsAvatar.js
/**
* Gets the avatar of an ENS name.
*
* - Docs: https://viem.sh/docs/ens/actions/getEnsAvatar
* - Examples: https://stackblitz.com/github/wevm/viem/tree/main/examples/ens
*
* Calls [`getEnsText`](https://viem.sh/docs/ens/actions/getEnsText) with `key` set to `'avatar'`.
*
* Since ENS names prohibit certain forbidden characters (e.g. underscore) and have other validation rules, you likely want to [normalize ENS names](https://docs.ens.domains/contract-api-reference/name-processing#normalising-names) with [UTS-46 normalization](https://unicode.org/reports/tr46) before passing them to `getEnsAddress`. You can use the built-in [`normalize`](https://viem.sh/docs/ens/utilities/normalize) function for this.
*
* @param client - Client to use
* @param parameters - {@link GetEnsAvatarParameters}
* @returns Avatar URI or `null` if not found. {@link GetEnsAvatarReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getEnsAvatar, normalize } from 'viem/ens'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const ensAvatar = await getEnsAvatar(client, {
*   name: normalize('wevm.eth'),
* })
* // 'https://ipfs.io/ipfs/Qma8mnp6xV3J2cRNf3mTth5C8nV11CAnceVinc3y8jSbio'
*/
async function getEnsAvatar(client, { blockNumber, blockTag, assetGatewayUrls, name, gatewayUrls, strict, universalResolverAddress }) {
	const record = await getAction(client, getEnsText, "getEnsText")({
		blockNumber,
		blockTag,
		key: "avatar",
		name,
		universalResolverAddress,
		gatewayUrls,
		strict
	});
	if (!record) return null;
	try {
		return await parseAvatarRecord(client, {
			record,
			gatewayUrls: assetGatewayUrls
		});
	} catch {
		return null;
	}
}
//#endregion
//#region node_modules/viem/_esm/actions/ens/getEnsName.js
/**
* Gets primary name for specified address.
*
* - Docs: https://viem.sh/docs/ens/actions/getEnsName
* - Examples: https://stackblitz.com/github/wevm/viem/tree/main/examples/ens
*
* Calls `reverse(bytes)` on ENS Universal Resolver Contract to "reverse resolve" the address to the primary ENS name.
*
* @param client - Client to use
* @param parameters - {@link GetEnsNameParameters}
* @returns Name or `null` if not found. {@link GetEnsNameReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getEnsName } from 'viem/ens'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const ensName = await getEnsName(client, {
*   address: '0xd2135CfB216b74109775236E36d4b433F1DF507B',
* })
* // 'wevm.eth'
*/
async function getEnsName(client, parameters) {
	const { address, blockNumber, blockTag, coinType = 60n, gatewayUrls, strict } = parameters;
	const { chain } = client;
	const universalResolverAddress = (() => {
		if (parameters.universalResolverAddress) return parameters.universalResolverAddress;
		if (!chain) throw new Error("client chain not configured. universalResolverAddress is required.");
		return getChainContractAddress({
			blockNumber,
			chain,
			contract: "ensUniversalResolver"
		});
	})();
	try {
		const readContractParameters = {
			address: universalResolverAddress,
			abi: universalResolverReverseAbi,
			args: [
				address,
				coinType,
				gatewayUrls ?? ["x-batch-gateway:true"]
			],
			functionName: "reverseWithGateways",
			blockNumber,
			blockTag
		};
		const [name] = await getAction(client, readContract, "readContract")(readContractParameters);
		return name || null;
	} catch (err) {
		if (strict) throw err;
		if (isNullUniversalResolverError(err)) return null;
		throw err;
	}
}
//#endregion
//#region node_modules/viem/_esm/actions/ens/getEnsResolver.js
/**
* Gets resolver for ENS name.
*
* - Docs: https://viem.sh/docs/ens/actions/getEnsResolver
* - Examples: https://stackblitz.com/github/wevm/viem/tree/main/examples/ens
*
* Calls `findResolver(bytes)` on ENS Universal Resolver Contract to retrieve the resolver of an ENS name.
*
* Since ENS names prohibit certain forbidden characters (e.g. underscore) and have other validation rules, you likely want to [normalize ENS names](https://docs.ens.domains/contract-api-reference/name-processing#normalising-names) with [UTS-46 normalization](https://unicode.org/reports/tr46) before passing them to `getEnsAddress`. You can use the built-in [`normalize`](https://viem.sh/docs/ens/utilities/normalize) function for this.
*
* @param client - Client to use
* @param parameters - {@link GetEnsResolverParameters}
* @returns Address for ENS resolver. {@link GetEnsResolverReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getEnsResolver, normalize } from 'viem/ens'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const resolverAddress = await getEnsResolver(client, {
*   name: normalize('wevm.eth'),
* })
* // '0x4976fb03C32e5B8cfe2b6cCB31c09Ba78EBaBa41'
*/
async function getEnsResolver(client, parameters) {
	const { blockNumber, blockTag, name } = parameters;
	const { chain } = client;
	const universalResolverAddress = (() => {
		if (parameters.universalResolverAddress) return parameters.universalResolverAddress;
		if (!chain) throw new Error("client chain not configured. universalResolverAddress is required.");
		return getChainContractAddress({
			blockNumber,
			chain,
			contract: "ensUniversalResolver"
		});
	})();
	const tlds = chain?.ensTlds;
	if (tlds && !tlds.some((tld) => name.endsWith(tld))) throw new Error(`${name} is not a valid ENS TLD (${tlds?.join(", ")}) for chain "${chain.name}" (id: ${chain.id}).`);
	const [resolverAddress] = await getAction(client, readContract, "readContract")({
		address: universalResolverAddress,
		abi: [{
			inputs: [{ type: "bytes" }],
			name: "findResolver",
			outputs: [
				{ type: "address" },
				{ type: "bytes32" },
				{ type: "uint256" }
			],
			stateMutability: "view",
			type: "function"
		}],
		functionName: "findResolver",
		args: [toHex(packetToBytes(name))],
		blockNumber,
		blockTag
	});
	return resolverAddress;
}
//#endregion
//#region node_modules/viem/_esm/actions/public/createAccessList.js
/**
* Creates an EIP-2930 access list.
*
* - Docs: https://viem.sh/docs/actions/public/createAccessList
* - JSON-RPC Methods: `eth_createAccessList`
*
* @param client - Client to use
* @param parameters - {@link CreateAccessListParameters}
* @returns The access list. {@link CreateAccessListReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createAccessList } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const data = await createAccessList(client, {
*   account: '0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266',
*   data: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2',
*   to: '0x70997970c51812dc3a010c7d01b50e0d17dc79c8',
* })
*/
async function createAccessList(client, args) {
	const { account: account_ = client.account, blockNumber, blockTag = "latest", blobs, data, gas, gasPrice, maxFeePerBlobGas, maxFeePerGas, maxPriorityFeePerGas, to, value, ...rest } = args;
	const account = account_ ? parseAccount(account_) : void 0;
	try {
		assertRequest(args);
		const block = (typeof blockNumber === "bigint" ? numberToHex(blockNumber) : void 0) || blockTag;
		const chainFormat = client.chain?.formatters?.transactionRequest?.format;
		const request = (chainFormat || formatTransactionRequest)({
			...extract(rest, { format: chainFormat }),
			account,
			blobs,
			data,
			gas,
			gasPrice,
			maxFeePerBlobGas,
			maxFeePerGas,
			maxPriorityFeePerGas,
			to,
			value
		}, "createAccessList");
		const response = await client.request({
			method: "eth_createAccessList",
			params: [request, block]
		});
		if (response.error) throw new BaseError(response.error, { details: response.error });
		return {
			accessList: response.accessList,
			gasUsed: BigInt(response.gasUsed)
		};
	} catch (err) {
		throw getCallError(err, {
			...args,
			account,
			chain: client.chain
		});
	}
}
//#endregion
//#region node_modules/viem/_esm/actions/public/createBlockFilter.js
/**
* Creates a [`Filter`](https://viem.sh/docs/glossary/types#filter) to listen for new block hashes that can be used with [`getFilterChanges`](https://viem.sh/docs/actions/public/getFilterChanges).
*
* - Docs: https://viem.sh/docs/actions/public/createBlockFilter
* - JSON-RPC Methods: [`eth_newBlockFilter`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_newBlockFilter)
*
* @param client - Client to use
* @returns [`Filter`](https://viem.sh/docs/glossary/types#filter). {@link CreateBlockFilterReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createBlockFilter } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const filter = await createBlockFilter(client)
* // { id: "0x345a6572337856574a76364e457a4366", type: 'block' }
*/
async function createBlockFilter(client) {
	const getRequest = createFilterRequestScope(client, { method: "eth_newBlockFilter" });
	const id = await client.request({ method: "eth_newBlockFilter" });
	return {
		id,
		request: getRequest(id),
		type: "block"
	};
}
//#endregion
//#region node_modules/viem/_esm/actions/public/createEventFilter.js
/**
* Creates a [`Filter`](https://viem.sh/docs/glossary/types#filter) to listen for new events that can be used with [`getFilterChanges`](https://viem.sh/docs/actions/public/getFilterChanges).
*
* - Docs: https://viem.sh/docs/actions/public/createEventFilter
* - JSON-RPC Methods: [`eth_newFilter`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_newfilter)
*
* @param client - Client to use
* @param parameters - {@link CreateEventFilterParameters}
* @returns [`Filter`](https://viem.sh/docs/glossary/types#filter). {@link CreateEventFilterReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createEventFilter } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const filter = await createEventFilter(client, {
*   address: '0xfba3912ca04dd458c843e2ee08967fc04f3579c2',
* })
*/
async function createEventFilter(client, { address, args, event, events: events_, fromBlock, strict, toBlock } = {}) {
	const events = events_ ?? (event ? [event] : void 0);
	const getRequest = createFilterRequestScope(client, { method: "eth_newFilter" });
	let topics = [];
	if (events) {
		topics = [events.flatMap((event) => encodeEventTopics({
			abi: [event],
			eventName: event.name,
			args
		}))];
		if (event) topics = topics[0];
	}
	const id = await client.request({
		method: "eth_newFilter",
		params: [{
			address,
			fromBlock: typeof fromBlock === "bigint" ? numberToHex(fromBlock) : fromBlock,
			toBlock: typeof toBlock === "bigint" ? numberToHex(toBlock) : toBlock,
			...topics.length ? { topics } : {}
		}]
	});
	return {
		abi: events,
		args,
		eventName: event ? event.name : void 0,
		fromBlock,
		id,
		request: getRequest(id),
		strict: Boolean(strict),
		toBlock,
		type: "event"
	};
}
//#endregion
//#region node_modules/viem/_esm/actions/public/createPendingTransactionFilter.js
/**
* Creates a Filter to listen for new pending transaction hashes that can be used with [`getFilterChanges`](https://viem.sh/docs/actions/public/getFilterChanges).
*
* - Docs: https://viem.sh/docs/actions/public/createPendingTransactionFilter
* - JSON-RPC Methods: [`eth_newPendingTransactionFilter`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_newpendingtransactionfilter)
*
* @param client - Client to use
* @returns [`Filter`](https://viem.sh/docs/glossary/types#filter). {@link CreateBlockFilterReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createPendingTransactionFilter } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const filter = await createPendingTransactionFilter(client)
* // { id: "0x345a6572337856574a76364e457a4366", type: 'transaction' }
*/
async function createPendingTransactionFilter(client) {
	const getRequest = createFilterRequestScope(client, { method: "eth_newPendingTransactionFilter" });
	const id = await client.request({ method: "eth_newPendingTransactionFilter" });
	return {
		id,
		request: getRequest(id),
		type: "transaction"
	};
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getBalance.js
/**
* Returns the balance of an address in wei.
*
* - Docs: https://viem.sh/docs/actions/public/getBalance
* - JSON-RPC Methods: [`eth_getBalance`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getbalance)
*
* You can convert the balance to ether units with [`formatEther`](https://viem.sh/docs/utilities/formatEther).
*
* ```ts
* const balance = await getBalance(client, {
*   address: '0xA0Cf798816D4b9b9866b5330EEa46a18382f251e',
*   blockTag: 'safe'
* })
* const balanceAsEther = formatEther(balance)
* // "6.942"
* ```
*
* @param client - Client to use
* @param parameters - {@link GetBalanceParameters}
* @returns The balance of the address in wei. {@link GetBalanceReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getBalance } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const balance = await getBalance(client, {
*   address: '0xA0Cf798816D4b9b9866b5330EEa46a18382f251e',
* })
* // 10000000000000000000000n (wei)
*/
async function getBalance$1(client, { address, blockHash, blockNumber, blockTag = client.experimental_blockTag ?? "latest", requireCanonical }) {
	const block = formatBlockParameter({
		blockHash,
		blockNumber,
		blockTag,
		requireCanonical
	});
	if (client.batch?.multicall && client.chain?.contracts?.multicall3) {
		const multicall3Address = client.chain.contracts.multicall3.address;
		const calldata = encodeFunctionData({
			abi: multicall3Abi,
			functionName: "getEthBalance",
			args: [address]
		});
		const { data } = await getAction(client, call, "call")({
			to: multicall3Address,
			data: calldata,
			blockHash,
			blockNumber,
			blockTag,
			requireCanonical
		});
		return decodeFunctionResult({
			abi: multicall3Abi,
			functionName: "getEthBalance",
			args: [address],
			data: data || "0x"
		});
	}
	const balance = await client.request({
		method: "eth_getBalance",
		params: [address, block]
	});
	return BigInt(balance);
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getBlobBaseFee.js
/**
* Returns the base fee per blob gas in wei.
*
* - Docs: https://viem.sh/docs/actions/public/getBlobBaseFee
* - JSON-RPC Methods: [`eth_blobBaseFee`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_blobBaseFee)
*
* @param client - Client to use
* @returns The blob base fee (in wei). {@link GetBlobBaseFeeReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getBlobBaseFee } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const blobBaseFee = await getBlobBaseFee(client)
*/
async function getBlobBaseFee(client) {
	const baseFee = await client.request({ method: "eth_blobBaseFee" });
	return BigInt(baseFee);
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getBlockReceipts.js
/**
* Returns the transaction receipts of a block at a block number, hash, or tag.
*
* - Docs: https://viem.sh/docs/actions/public/getBlockReceipts
* - JSON-RPC Methods: [`eth_getBlockReceipts`](https://ethereum.github.io/execution-apis/api/methods/eth_getBlockReceipts/)
*
* @param client - Client to use
* @param parameters - {@link GetBlockReceiptsParameters}
* @returns The transaction receipts. {@link GetBlockReceiptsReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getBlockReceipts } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const receipts = await getBlockReceipts(client, {
*   blockNumber: 69420n,
* })
*/
async function getBlockReceipts(client, { blockHash, blockNumber, blockTag = client.experimental_blockTag ?? "latest" } = {}) {
	const blockNumberHex = blockNumber !== void 0 ? numberToHex(blockNumber) : void 0;
	const receipts = await client.request({
		method: "eth_getBlockReceipts",
		params: [blockHash || blockNumberHex || blockTag]
	}, { dedupe: Boolean(blockHash || blockNumberHex) });
	if (!receipts) throw new BlockNotFoundError({
		blockHash,
		blockNumber
	});
	const format = client.chain?.formatters?.transactionReceipt?.format || formatTransactionReceipt;
	return receipts.map((receipt) => format(receipt, "getBlockReceipts"));
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getBlockTransactionCount.js
/**
* Returns the number of Transactions at a block number, hash, or tag.
*
* - Docs: https://viem.sh/docs/actions/public/getBlockTransactionCount
* - JSON-RPC Methods:
*   - Calls [`eth_getBlockTransactionCountByNumber`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getblocktransactioncountbynumber) for `blockNumber` & `blockTag`.
*   - Calls [`eth_getBlockTransactionCountByHash`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getblocktransactioncountbyhash) for `blockHash`.
*
* @param client - Client to use
* @param parameters - {@link GetBlockTransactionCountParameters}
* @returns The block transaction count. {@link GetBlockTransactionCountReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getBlockTransactionCount } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const count = await getBlockTransactionCount(client)
*/
async function getBlockTransactionCount(client, { blockHash, blockNumber, blockTag = "latest" } = {}) {
	const blockNumberHex = blockNumber !== void 0 ? numberToHex(blockNumber) : void 0;
	let count;
	if (blockHash) count = await client.request({
		method: "eth_getBlockTransactionCountByHash",
		params: [blockHash]
	}, { dedupe: true });
	else count = await client.request({
		method: "eth_getBlockTransactionCountByNumber",
		params: [blockNumberHex || blockTag]
	}, { dedupe: Boolean(blockNumberHex) });
	return hexToNumber(count);
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getCode.js
/**
* Retrieves the bytecode at an address.
*
* - Docs: https://viem.sh/docs/contract/getCode
* - JSON-RPC Methods: [`eth_getCode`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getcode)
*
* @param client - Client to use
* @param parameters - {@link GetCodeParameters}
* @returns The contract's bytecode. {@link GetCodeReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getCode } from 'viem/contract'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const code = await getCode(client, {
*   address: '0xFBA3912Ca04dd458c843e2EE08967fC04f3579c2',
* })
*/
async function getCode(client, { address, blockHash, blockNumber, blockTag = "latest", requireCanonical }) {
	const block = formatBlockParameter({
		blockHash,
		blockNumber,
		blockTag,
		requireCanonical
	});
	const hex = await client.request({
		method: "eth_getCode",
		params: [address, block]
	}, { dedupe: typeof blockNumber === "bigint" || blockHash !== void 0 });
	if (hex === "0x") return void 0;
	return hex;
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getDelegation.js
/**
* Returns the address that an account has delegated to via EIP-7702.
*
* - Docs: https://viem.sh/docs/actions/public/getDelegation
*
* @param client - Client to use
* @param parameters - {@link GetDelegationParameters}
* @returns The delegated address, or undefined if not delegated. {@link GetDelegationReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getDelegation } from 'viem/actions'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const delegation = await getDelegation(client, {
*   address: '0xA0Cf798816D4b9b9866b5330EEa46a18382f251e',
* })
*/
async function getDelegation(client, { address, blockNumber, blockTag = "latest" }) {
	const code = await getCode(client, {
		address,
		...blockNumber !== void 0 ? { blockNumber } : { blockTag }
	});
	if (!code) return void 0;
	if (size(code) !== 23) return void 0;
	if (!code.startsWith("0xef0100")) return void 0;
	return getAddress(slice(code, 3, 23));
}
//#endregion
//#region node_modules/viem/_esm/errors/eip712.js
var Eip712DomainNotFoundError = class extends BaseError {
	constructor({ address }) {
		super(`No EIP-712 domain found on contract "${address}".`, {
			metaMessages: [
				"Ensure that:",
				`- The contract is deployed at the address "${address}".`,
				"- `eip712Domain()` function exists on the contract.",
				"- `eip712Domain()` function matches signature to ERC-5267 specification."
			],
			name: "Eip712DomainNotFoundError"
		});
	}
};
//#endregion
//#region node_modules/viem/_esm/actions/public/getEip712Domain.js
/**
* Reads the EIP-712 domain from a contract, based on the ERC-5267 specification.
*
* @param client - A {@link Client} instance.
* @param parameters - The parameters of the action. {@link GetEip712DomainParameters}
* @returns The EIP-712 domain, fields, and extensions. {@link GetEip712DomainReturnType}
*
* @example
* ```ts
* import { createPublicClient, http, getEip712Domain } from 'viem'
* import { mainnet } from 'viem/chains'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
*
* const domain = await getEip712Domain(client, {
*   address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
* })
* // {
* //   domain: {
* //     name: 'ExampleContract',
* //     version: '1',
* //     chainId: 1,
* //     verifyingContract: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
* //   },
* //   fields: '0x0f',
* //   extensions: [],
* // }
* ```
*/
async function getEip712Domain(client, parameters) {
	const { address, factory, factoryData } = parameters;
	try {
		const [fields, name, version, chainId, verifyingContract, salt, extensions] = await getAction(client, readContract, "readContract")({
			abi,
			address,
			functionName: "eip712Domain",
			factory,
			factoryData
		});
		return {
			domain: {
				name,
				version,
				chainId: Number(chainId),
				verifyingContract,
				salt
			},
			extensions,
			fields
		};
	} catch (e) {
		const error = e;
		if (error.name === "ContractFunctionExecutionError" && error.cause.name === "ContractFunctionZeroDataError") throw new Eip712DomainNotFoundError({ address });
		throw error;
	}
}
var abi = [{
	inputs: [],
	name: "eip712Domain",
	outputs: [
		{
			name: "fields",
			type: "bytes1"
		},
		{
			name: "name",
			type: "string"
		},
		{
			name: "version",
			type: "string"
		},
		{
			name: "chainId",
			type: "uint256"
		},
		{
			name: "verifyingContract",
			type: "address"
		},
		{
			name: "salt",
			type: "bytes32"
		},
		{
			name: "extensions",
			type: "uint256[]"
		}
	],
	stateMutability: "view",
	type: "function"
}];
//#endregion
//#region node_modules/viem/_esm/utils/formatters/feeHistory.js
function formatFeeHistory(feeHistory) {
	return {
		baseFeePerGas: feeHistory.baseFeePerGas.map((value) => BigInt(value)),
		gasUsedRatio: feeHistory.gasUsedRatio,
		oldestBlock: BigInt(feeHistory.oldestBlock),
		reward: feeHistory.reward?.map((reward) => reward.map((value) => BigInt(value)))
	};
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getFeeHistory.js
/**
* Returns a collection of historical gas information.
*
* - Docs: https://viem.sh/docs/actions/public/getFeeHistory
* - JSON-RPC Methods: [`eth_feeHistory`](https://docs.alchemy.com/reference/eth-feehistory)
*
* @param client - Client to use
* @param parameters - {@link GetFeeHistoryParameters}
* @returns The gas estimate (in wei). {@link GetFeeHistoryReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getFeeHistory } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const feeHistory = await getFeeHistory(client, {
*   blockCount: 4,
*   rewardPercentiles: [25, 75],
* })
*/
async function getFeeHistory(client, { blockCount, blockNumber, blockTag = "latest", rewardPercentiles }) {
	const blockNumberHex = typeof blockNumber === "bigint" ? numberToHex(blockNumber) : void 0;
	return formatFeeHistory(await client.request({
		method: "eth_feeHistory",
		params: [
			numberToHex(blockCount),
			blockNumberHex || blockTag,
			rewardPercentiles
		]
	}, { dedupe: Boolean(blockNumberHex) }));
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getFilterLogs.js
/**
* Returns a list of event logs since the filter was created.
*
* - Docs: https://viem.sh/docs/actions/public/getFilterLogs
* - JSON-RPC Methods: [`eth_getFilterLogs`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getfilterlogs)
*
* `getFilterLogs` is only compatible with **event filters**.
*
* @param client - Client to use
* @param parameters - {@link GetFilterLogsParameters}
* @returns A list of event logs. {@link GetFilterLogsReturnType}
*
* @example
* import { createPublicClient, http, parseAbiItem } from 'viem'
* import { mainnet } from 'viem/chains'
* import { createEventFilter, getFilterLogs } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const filter = await createEventFilter(client, {
*   address: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
*   event: parseAbiItem('event Transfer(address indexed, address indexed, uint256)'),
* })
* const logs = await getFilterLogs(client, { filter })
*/
async function getFilterLogs(_client, { filter }) {
	const strict = filter.strict ?? false;
	const formattedLogs = (await filter.request({
		method: "eth_getFilterLogs",
		params: [filter.id]
	})).map((log) => formatLog(log));
	if (!filter.abi) return formattedLogs;
	return parseEventLogs({
		abi: filter.abi,
		logs: formattedLogs,
		strict
	});
}
//#endregion
//#region node_modules/viem/_esm/utils/authorization/verifyAuthorization.js
/**
* Verify that an Authorization object was signed by the provided address.
*
* - Docs {@link https://viem.sh/docs/utilities/verifyAuthorization}
*
* @param parameters - {@link VerifyAuthorizationParameters}
* @returns Whether or not the signature is valid. {@link VerifyAuthorizationReturnType}
*/
async function verifyAuthorization({ address, authorization, signature }) {
	return isAddressEqual(getAddress(address), await recoverAuthorizationAddress({
		authorization,
		signature
	}));
}
//#endregion
//#region node_modules/viem/_esm/errors/ccip.js
var OffchainLookupError = class extends BaseError {
	constructor({ callbackSelector, cause, data, extraData, sender, urls }) {
		super(cause.shortMessage || "An error occurred while fetching for an offchain result.", {
			cause,
			metaMessages: [
				...cause.metaMessages || [],
				cause.metaMessages?.length ? "" : [],
				"Offchain Gateway Call:",
				urls && ["  Gateway URL(s):", ...urls.map((url) => `    ${getUrl(url)}`)],
				`  Sender: ${sender}`,
				`  Data: ${data}`,
				`  Callback selector: ${callbackSelector}`,
				`  Extra data: ${extraData}`
			].flat(),
			name: "OffchainLookupError"
		});
	}
};
var OffchainLookupResponseMalformedError = class extends BaseError {
	constructor({ result, url }) {
		super("Offchain gateway response is malformed. Response data must be a hex value.", {
			metaMessages: [`Gateway URL: ${getUrl(url)}`, `Response: ${stringify(result)}`],
			name: "OffchainLookupResponseMalformedError"
		});
	}
};
var OffchainLookupSenderMismatchError = class extends BaseError {
	constructor({ sender, to }) {
		super("Reverted sender address does not match target contract address (`to`).", {
			metaMessages: [`Contract address: ${to}`, `OffchainLookup sender address: ${sender}`],
			name: "OffchainLookupSenderMismatchError"
		});
	}
};
//#endregion
//#region node_modules/viem/_esm/utils/ccip.js
var ccip_exports = /* @__PURE__ */ __exportAll({
	ccipRequest: () => ccipRequest,
	offchainLookup: () => offchainLookup,
	offchainLookupAbiItem: () => offchainLookupAbiItem,
	offchainLookupSignature: () => offchainLookupSignature
});
var offchainLookupSignature = "0x556f1830";
var offchainLookupAbiItem = {
	name: "OffchainLookup",
	type: "error",
	inputs: [
		{
			name: "sender",
			type: "address"
		},
		{
			name: "urls",
			type: "string[]"
		},
		{
			name: "callData",
			type: "bytes"
		},
		{
			name: "callbackFunction",
			type: "bytes4"
		},
		{
			name: "extraData",
			type: "bytes"
		}
	]
};
async function offchainLookup(client, { blockNumber, blockTag, data, requestOptions, to }) {
	const { args } = decodeErrorResult({
		data,
		abi: [offchainLookupAbiItem]
	});
	const [sender, urls, callData, callbackSelector, extraData] = args;
	const { ccipRead } = client;
	const ccipRequest_ = ccipRead && typeof ccipRead?.request === "function" ? ccipRead.request : ccipRequest;
	try {
		if (!isAddressEqual(to, sender)) throw new OffchainLookupSenderMismatchError({
			sender,
			to
		});
		const result = urls.includes("x-batch-gateway:true") ? await localBatchGatewayRequest({
			data: callData,
			ccipRequest: (parameters) => ccipRequest_({
				...parameters,
				requestOptions
			})
		}) : await ccipRequest_({
			data: callData,
			requestOptions,
			sender,
			urls
		});
		const { data: data_ } = await call(client, {
			blockNumber,
			blockTag,
			data: concat([callbackSelector, encodeAbiParameters([{ type: "bytes" }, { type: "bytes" }], [result, extraData])]),
			requestOptions,
			to
		});
		return data_;
	} catch (err) {
		if (requestOptions?.signal?.aborted) throw getAbortError(requestOptions.signal);
		if (isAbortError(err)) throw err;
		throw new OffchainLookupError({
			callbackSelector,
			cause: err,
			data,
			extraData,
			sender,
			urls
		});
	}
}
async function ccipRequest({ data, requestOptions, sender, urls }) {
	let error = /* @__PURE__ */ new Error("An unknown error occurred.");
	for (let i = 0; i < urls.length; i++) {
		if (requestOptions?.signal?.aborted) throw getAbortError(requestOptions.signal);
		const url = urls[i];
		const method = url.includes("{data}") ? "GET" : "POST";
		const body = method === "POST" ? {
			data,
			sender
		} : void 0;
		const headers = method === "POST" ? { "Content-Type": "application/json" } : {};
		try {
			const response = await fetch(url.replace("{sender}", sender.toLowerCase()).replace("{data}", data), {
				body: JSON.stringify(body),
				headers,
				method,
				...requestOptions?.signal ? { signal: requestOptions.signal } : {}
			});
			let result;
			if (response.headers.get("Content-Type")?.startsWith("application/json")) result = (await response.json()).data;
			else result = await response.text();
			if (!response.ok) {
				error = new HttpRequestError({
					body,
					details: result?.error ? stringify(result.error) : response.statusText,
					headers: response.headers,
					status: response.status,
					url
				});
				continue;
			}
			if (!isHex(result)) {
				error = new OffchainLookupResponseMalformedError({
					result,
					url
				});
				continue;
			}
			return result;
		} catch (err) {
			if (requestOptions?.signal?.aborted) throw getAbortError(requestOptions.signal);
			if (isAbortError(err)) throw err;
			error = new HttpRequestError({
				body,
				details: err.message,
				url
			});
		}
	}
	throw error;
}
//#endregion
//#region node_modules/viem/_esm/utils/chain/defineChain.js
function defineChain(chain) {
	const chainInstance = {
		formatters: void 0,
		fees: void 0,
		serializers: void 0,
		...chain
	};
	function extend(base) {
		return (fnOrExtended) => {
			const properties = typeof fnOrExtended === "function" ? fnOrExtended(base) : fnOrExtended;
			const combined = {
				...base,
				...properties
			};
			return Object.assign(combined, { extend: extend(combined) });
		};
	}
	return Object.assign(chainInstance, { extend: extend(chainInstance) });
}
//#endregion
//#region node_modules/viem/_esm/utils/rpc/id.js
function createIdStore() {
	return {
		current: 0,
		take() {
			return this.current++;
		},
		reset() {
			this.current = 0;
		}
	};
}
var idCache = /*#__PURE__*/ createIdStore();
//#endregion
//#region node_modules/viem/_esm/utils/rpc/http.js
var defaultMaxResponseBodySize = 10485760;
function getHttpRpcClient(url_, options = {}) {
	const { url, headers: headers_url } = parseUrl(url_);
	return { async request(params) {
		const { body, fetchFn = options.fetchFn ?? fetch, maxResponseBodySize = options.maxResponseBodySize ?? defaultMaxResponseBodySize, onRequest = options.onRequest, onResponse = options.onResponse, timeout = options.timeout ?? 1e4 } = params;
		const fetchOptions = {
			...options.fetchOptions ?? {},
			...params.fetchOptions ?? {}
		};
		const { headers, method, signal: signal_ } = fetchOptions;
		try {
			const response = await withTimeout(async ({ signal }) => {
				const init = {
					...fetchOptions,
					body: Array.isArray(body) ? stringify(body.map((body) => ({
						jsonrpc: "2.0",
						id: body.id ?? idCache.take(),
						...body
					}))) : stringify({
						jsonrpc: "2.0",
						id: body.id ?? idCache.take(),
						...body
					}),
					headers: {
						...headers_url,
						"Content-Type": "application/json",
						...headers
					},
					method: method || "POST",
					signal: signal_ || (timeout > 0 ? signal : null)
				};
				const request = new Request(url, init);
				const args = await onRequest?.(request, init) ?? {
					...init,
					url
				};
				return await fetchFn(args.url ?? url, args);
			}, {
				errorInstance: new TimeoutError({
					body,
					url
				}),
				timeout,
				signal: true
			});
			if (onResponse) await onResponse(response);
			let data;
			const responseBody = await readResponseBody(response, { maxResponseBodySize });
			if (response.headers.get("Content-Type")?.startsWith("application/json")) data = JSON.parse(responseBody);
			else {
				data = responseBody;
				try {
					data = JSON.parse(data || "{}");
				} catch (err) {
					if (response.ok) throw err;
					data = { error: data };
				}
			}
			if (!response.ok) {
				if (typeof data.error?.code === "number" && typeof data.error?.message === "string") return data;
				throw new HttpRequestError({
					body,
					details: stringify(data.error) || response.statusText,
					headers: response.headers,
					status: response.status,
					url
				});
			}
			return data;
		} catch (err) {
			if (signal_?.aborted) throw getAbortError(signal_);
			if (isAbortError(err)) throw err;
			if (err instanceof HttpRequestError) throw err;
			if (err instanceof ResponseBodyTooLargeError) throw err;
			if (err instanceof TimeoutError) throw err;
			throw new HttpRequestError({
				body,
				cause: err,
				url
			});
		}
	} };
}
async function readResponseBody(response, { maxResponseBodySize }) {
	if (maxResponseBodySize === false) return response.text();
	const contentLength = response.headers.get("Content-Length");
	if (contentLength) {
		const size = Number(contentLength);
		if (size > maxResponseBodySize) throw new ResponseBodyTooLargeError({
			maxSize: maxResponseBodySize,
			size
		});
	}
	if (!response.body) {
		const body = await response.text();
		const size = new TextEncoder().encode(body).length;
		if (size > maxResponseBodySize) throw new ResponseBodyTooLargeError({
			maxSize: maxResponseBodySize,
			size
		});
		return body;
	}
	const reader = response.body.getReader();
	const decoder = new TextDecoder();
	let body = "";
	let size = 0;
	try {
		while (true) {
			const { done, value } = await reader.read();
			if (done) break;
			size += value.byteLength;
			if (size > maxResponseBodySize) {
				await reader.cancel();
				throw new ResponseBodyTooLargeError({
					maxSize: maxResponseBodySize,
					size
				});
			}
			body += decoder.decode(value, { stream: true });
		}
		body += decoder.decode();
		return body;
	} finally {
		reader.releaseLock();
	}
}
/** @internal */
function parseUrl(url_) {
	try {
		const url = new URL(url_);
		const result = (() => {
			if (url.username) {
				const credentials = `${decodeURIComponent(url.username)}:${decodeURIComponent(url.password)}`;
				url.username = "";
				url.password = "";
				return {
					url: url.toString(),
					headers: { Authorization: `Basic ${btoa(credentials)}` }
				};
			}
		})();
		return {
			url: url.toString(),
			...result
		};
	} catch {
		return { url: url_ };
	}
}
//#endregion
//#region node_modules/viem/_esm/constants/strings.js
var presignMessagePrefix = "Ethereum Signed Message:\n";
//#endregion
//#region node_modules/viem/_esm/utils/signature/toPrefixedMessage.js
function toPrefixedMessage(message_) {
	const message = (() => {
		if (typeof message_ === "string") return stringToHex(message_);
		if (typeof message_.raw === "string") return message_.raw;
		return bytesToHex(message_.raw);
	})();
	const prefix = stringToHex(`${presignMessagePrefix}${size(message)}`);
	return concat([prefix, message]);
}
//#endregion
//#region node_modules/viem/_esm/utils/signature/hashMessage.js
function hashMessage(message, to_) {
	return keccak256(toPrefixedMessage(message), to_);
}
//#endregion
//#region node_modules/viem/_esm/utils/unit/parseEther.js
/**
* Converts a string representation of ether to numerical wei.
*
* - Docs: https://viem.sh/docs/utilities/parseEther
*
* @example
* import { parseEther } from 'viem'
*
* parseEther('420')
* // 420000000000000000000n
*/
function parseEther(ether, unit = "wei") {
	return fromEther(ether, unit);
}
//#endregion
//#region node_modules/viem/_esm/utils/formatters/proof.js
function formatStorageProof(storageProof) {
	return storageProof.map((proof) => ({
		...proof,
		value: BigInt(proof.value)
	}));
}
function formatProof(proof) {
	return {
		...proof,
		balance: proof.balance ? BigInt(proof.balance) : void 0,
		nonce: proof.nonce ? hexToNumber(proof.nonce) : void 0,
		storageProof: proof.storageProof ? formatStorageProof(proof.storageProof) : void 0
	};
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getProof.js
/**
* Returns the account and storage values of the specified account including the Merkle-proof.
*
* - Docs: https://viem.sh/docs/actions/public/getProof
* - JSON-RPC Methods:
*   - Calls [`eth_getProof`](https://eips.ethereum.org/EIPS/eip-1186)
*
* @param client - Client to use
* @param parameters - {@link GetProofParameters}
* @returns Proof data. {@link GetProofReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getProof } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const block = await getProof(client, {
*  address: '0x...',
*  storageKeys: ['0x...'],
* })
*/
async function getProof(client, { address, blockHash, blockNumber, blockTag = "latest", requireCanonical, storageKeys }) {
	const block = formatBlockParameter({
		blockHash,
		blockNumber,
		blockTag,
		requireCanonical
	});
	return formatProof(await client.request({
		method: "eth_getProof",
		params: [
			address,
			storageKeys,
			block
		]
	}));
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getRawTransaction.js
/**
* Returns the raw, serialized [Transaction](https://viem.sh/docs/glossary/terms#transaction) given a hash.
*
* - Docs: https://viem.sh/docs/actions/public/getRawTransaction
* - JSON-RPC Methods: `eth_getRawTransactionByHash`
*
* @param client - Client to use
* @param parameters - {@link GetRawTransactionParameters}
* @returns The raw, serialized transaction. {@link GetRawTransactionReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getRawTransaction } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const rawTransaction = await getRawTransaction(client, {
*   hash: '0x4ca7ee652d57678f26e887c149ab0735f41de37bcad58c9f6d3ed5824f15b74d',
* })
*/
async function getRawTransaction(client, { hash }) {
	const rawTransaction = await client.request({
		method: "eth_getRawTransactionByHash",
		params: [hash]
	}, { dedupe: true });
	if (!rawTransaction) throw new TransactionNotFoundError({ hash });
	return rawTransaction;
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getStorageAt.js
/**
* Returns the value from a storage slot at a given address.
*
* - Docs: https://viem.sh/docs/contract/getStorageAt
* - JSON-RPC Methods: [`eth_getStorageAt`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getstorageat)
*
* @param client - Client to use
* @param parameters - {@link GetStorageAtParameters}
* @returns The value of the storage slot. {@link GetStorageAtReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getStorageAt } from 'viem/contract'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const code = await getStorageAt(client, {
*   address: '0xFBA3912Ca04dd458c843e2EE08967fC04f3579c2',
*   slot: toHex(0),
* })
*/
async function getStorageAt(client, { address, blockHash, blockNumber, blockTag = "latest", requireCanonical, slot }) {
	const block = formatBlockParameter({
		blockHash,
		blockNumber,
		blockTag,
		requireCanonical
	});
	return await client.request({
		method: "eth_getStorageAt",
		params: [
			address,
			slot,
			block
		]
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/public/getTransactionConfirmations.js
/**
* Returns the number of blocks passed (confirmations) since the transaction was processed on a block.
*
* - Docs: https://viem.sh/docs/actions/public/getTransactionConfirmations
* - Example: https://stackblitz.com/github/wevm/viem/tree/main/examples/transactions_fetching-transactions
* - JSON-RPC Methods: [`eth_getTransactionConfirmations`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getTransactionConfirmations)
*
* @param client - Client to use
* @param parameters - {@link GetTransactionConfirmationsParameters}
* @returns The number of blocks passed since the transaction was processed. If confirmations is 0, then the Transaction has not been confirmed & processed yet. {@link GetTransactionConfirmationsReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { getTransactionConfirmations } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const confirmations = await getTransactionConfirmations(client, {
*   hash: '0x4ca7ee652d57678f26e887c149ab0735f41de37bcad58c9f6d3ed5824f15b74d',
* })
*/
async function getTransactionConfirmations(client, { hash, transactionReceipt }) {
	const [blockNumber, transaction] = await Promise.all([getAction(client, getBlockNumber, "getBlockNumber")({}), hash ? getAction(client, getTransaction, "getTransaction")({ hash }) : void 0]);
	const transactionBlockNumber = transactionReceipt?.blockNumber || transaction?.blockNumber;
	if (!transactionBlockNumber) return 0n;
	return blockNumber - transactionBlockNumber + 1n;
}
//#endregion
//#region node_modules/viem/_esm/actions/public/multicall.js
/**
* Similar to [`readContract`](https://viem.sh/docs/contract/readContract), but batches up multiple functions on a contract in a single RPC call via the [`multicall3` contract](https://github.com/mds1/multicall).
*
* - Docs: https://viem.sh/docs/contract/multicall
*
* @param client - Client to use
* @param parameters - {@link MulticallParameters}
* @returns An array of results with accompanying status. {@link MulticallReturnType}
*
* @example
* import { createPublicClient, http, parseAbi } from 'viem'
* import { mainnet } from 'viem/chains'
* import { multicall } from 'viem/contract'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const abi = parseAbi([
*   'function balanceOf(address) view returns (uint256)',
*   'function totalSupply() view returns (uint256)',
* ])
* const results = await multicall(client, {
*   contracts: [
*     {
*       address: '0xFBA3912Ca04dd458c843e2EE08967fC04f3579c2',
*       abi,
*       functionName: 'balanceOf',
*       args: ['0xA0Cf798816D4b9b9866b5330EEa46a18382f251e'],
*     },
*     {
*       address: '0xFBA3912Ca04dd458c843e2EE08967fC04f3579c2',
*       abi,
*       functionName: 'totalSupply',
*     },
*   ],
* })
* // [{ result: 424122n, status: 'success' }, { result: 1000000n, status: 'success' }]
*/
async function multicall(client, parameters) {
	const { account, authorizationList, allowFailure = true, blockHash, blockNumber, blockOverrides, blockTag, requireCanonical, stateOverride } = parameters;
	const contracts = parameters.contracts;
	const batch = typeof client.batch?.multicall === "object" ? client.batch.multicall : {};
	const batchSize = parameters.batchSize ?? batch.batchSize ?? 1024;
	const deployless = parameters.deployless ?? batch.deployless ?? false;
	const multicallAddress = (() => {
		if (parameters.multicallAddress) return parameters.multicallAddress;
		if (deployless) return null;
		if (client.chain) return getChainContractAddress({
			blockNumber,
			chain: client.chain,
			contract: "multicall3"
		});
		throw new Error("client chain not configured. multicallAddress is required.");
	})();
	const chunkedCalls = [[]];
	let currentChunk = 0;
	let currentChunkSize = 0;
	for (let i = 0; i < contracts.length; i++) {
		const { abi, address, args, functionName } = contracts[i];
		try {
			const callData = encodeFunctionData({
				abi,
				args,
				functionName
			});
			currentChunkSize += (callData.length - 2) / 2;
			if (batchSize > 0 && currentChunkSize > batchSize && chunkedCalls[currentChunk].length > 0) {
				currentChunk++;
				currentChunkSize = (callData.length - 2) / 2;
				chunkedCalls[currentChunk] = [];
			}
			chunkedCalls[currentChunk] = [...chunkedCalls[currentChunk], {
				allowFailure: true,
				callData,
				target: address
			}];
		} catch (err) {
			const error = getContractError(err, {
				abi,
				address,
				args,
				docsPath: "/docs/contract/multicall",
				functionName,
				sender: account
			});
			if (!allowFailure) throw error;
			chunkedCalls[currentChunk] = [...chunkedCalls[currentChunk], {
				allowFailure: true,
				callData: "0x",
				target: address
			}];
		}
	}
	const batching = Boolean(client.batch?.multicall);
	const batches = batching ? chunkedCalls.flatMap((calls) => calls.map((call) => [call])) : chunkedCalls;
	const aggregate3Results = await Promise.allSettled(batches.map((calls) => {
		if (batching) return scheduleMulticall(client, {
			account,
			authorizationList,
			batchSize,
			blockHash,
			blockNumber,
			blockOverrides,
			blockTag,
			call: calls[0],
			multicallAddress,
			requireCanonical,
			stateOverride
		}).then((result) => [result]);
		return getAction(client, readContract, "readContract")({
			...multicallAddress === null ? { code: multicall3Bytecode } : { address: multicallAddress },
			abi: multicall3Abi,
			account,
			args: [calls],
			authorizationList,
			blockHash,
			blockNumber,
			blockOverrides,
			blockTag,
			functionName: "aggregate3",
			requireCanonical,
			stateOverride
		});
	}));
	const results = [];
	for (let i = 0; i < aggregate3Results.length; i++) {
		const result = aggregate3Results[i];
		if (result.status === "rejected") {
			if (!allowFailure) throw result.reason;
			for (let j = 0; j < batches[i].length; j++) results.push({
				status: "failure",
				error: result.reason,
				result: void 0
			});
			continue;
		}
		const aggregate3Result = result.value;
		for (let j = 0; j < aggregate3Result.length; j++) {
			const { returnData, success } = aggregate3Result[j];
			const { callData } = batches[i][j];
			const { abi, address, functionName, args } = contracts[results.length];
			try {
				if (callData === "0x") throw new AbiDecodingZeroDataError();
				if (!success) throw new RawContractError({ data: returnData });
				const result = decodeFunctionResult({
					abi,
					args,
					data: returnData,
					functionName
				});
				results.push(allowFailure ? {
					result,
					status: "success"
				} : result);
			} catch (err) {
				const error = getContractError(err, {
					abi,
					address,
					args,
					docsPath: "/docs/contract/multicall",
					functionName
				});
				if (!allowFailure) throw error;
				results.push({
					error,
					result: void 0,
					status: "failure"
				});
			}
		}
	}
	if (results.length !== contracts.length) throw new BaseError("multicall results mismatch");
	return results;
}
async function scheduleMulticall(client, parameters) {
	const { batchSize, call, multicallAddress, ...rest } = parameters;
	const { wait = 0 } = typeof client.batch?.multicall === "object" ? client.batch.multicall : {};
	const { schedule } = createBatchScheduler({
		id: stringify([
			"multicall",
			client.uid,
			batchSize,
			multicallAddress,
			rest
		]),
		wait,
		shouldSplitBatch(calls) {
			if (batchSize === 0) return false;
			return calls.reduce((size, { callData }) => size + (callData.length - 2) / 2, 0) > batchSize;
		},
		fn: (calls) => getAction(client, readContract, "readContract")({
			...multicallAddress === null ? { code: multicall3Bytecode } : { address: multicallAddress },
			...rest,
			abi: multicall3Abi,
			args: [calls],
			functionName: "aggregate3"
		})
	});
	const [result] = await schedule(call);
	return result;
}
//#endregion
//#region node_modules/viem/_esm/actions/public/simulateBlocks.js
/**
* Simulates a set of calls on block(s) with optional block and state overrides.
*
* @example
* ```ts
* import { createClient, http, parseEther } from 'viem'
* import { simulate } from 'viem/actions'
* import { mainnet } from 'viem/chains'
*
* const client = createClient({
*   chain: mainnet,
*   transport: http(),
* })
*
* const result = await simulate(client, {
*   blocks: [{
*     blockOverrides: {
*       number: 69420n,
*     },
*     calls: [{
*       {
*         account: '0x5a0b54d5dc17e482fe8b0bdca5320161b95fb929',
*         data: '0xdeadbeef',
*         to: '0x70997970c51812dc3a010c7d01b50e0d17dc79c8',
*       },
*       {
*         account: '0x5a0b54d5dc17e482fe8b0bdca5320161b95fb929',
*         to: '0x70997970c51812dc3a010c7d01b50e0d17dc79c8',
*         value: parseEther('1'),
*       },
*     }],
*     stateOverrides: [{
*       address: '0x5a0b54d5dc17e482fe8b0bdca5320161b95fb929',
*       balance: parseEther('10'),
*     }],
*   }]
* })
* ```
*
* @param client - Client to use.
* @param parameters - {@link SimulateBlocksParameters}
* @returns Simulated blocks. {@link SimulateBlocksReturnType}
*/
async function simulateBlocks(client, parameters) {
	const { blockNumber, blockTag = client.experimental_blockTag ?? "latest", blocks, returnFullTransactions, traceTransfers, validation } = parameters;
	try {
		const blockStateCalls = [];
		for (const block of blocks) {
			const blockOverrides = block.blockOverrides ? toRpc(block.blockOverrides) : void 0;
			const calls = block.calls.map((call_) => {
				const call = call_;
				const account = call.account ? parseAccount(call.account) : void 0;
				const data = call.abi ? encodeFunctionData(call) : call.data;
				const request = {
					...call,
					account,
					data: call.dataSuffix ? concat([data || "0x", call.dataSuffix]) : data,
					from: call.from ?? account?.address
				};
				assertRequest(request);
				return formatTransactionRequest(request);
			});
			const stateOverrides = block.stateOverrides ? serializeStateOverride(block.stateOverrides) : void 0;
			blockStateCalls.push({
				blockOverrides,
				calls,
				stateOverrides
			});
		}
		const block = (typeof blockNumber === "bigint" ? numberToHex(blockNumber) : void 0) || blockTag;
		return (await client.request({
			method: "eth_simulateV1",
			params: [{
				blockStateCalls,
				returnFullTransactions,
				traceTransfers,
				validation
			}, block]
		})).map((block, i) => ({
			...formatBlock(block),
			calls: block.calls.map((call, j) => {
				const { abi, args, functionName, to } = blocks[i].calls[j];
				const data = call.error?.data ?? call.returnData;
				const gasUsed = BigInt(call.gasUsed);
				const logs = call.logs?.map((log) => formatLog(log));
				const status = call.status === "0x1" ? "success" : "failure";
				const result = abi && status === "success" && data !== "0x" ? decodeFunctionResult({
					abi,
					data,
					functionName
				}) : null;
				const error = (() => {
					if (status === "success") return void 0;
					let error;
					if (data === "0x") error = new AbiDecodingZeroDataError();
					else if (data) error = new RawContractError({ data });
					if (!error) return void 0;
					return getContractError(error, {
						abi: abi ?? [],
						address: to ?? "0x",
						args,
						functionName: functionName ?? "<unknown>"
					});
				})();
				return {
					data,
					gasUsed,
					logs,
					status,
					...status === "success" ? { result } : { error }
				};
			})
		}));
	} catch (e) {
		const cause = e;
		const error = getNodeError(cause, {});
		if (error instanceof UnknownNodeError) throw cause;
		throw error;
	}
}
//#endregion
//#region node_modules/viem/_esm/constants/address.js
var ethAddress = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
var zeroAddress = "0x0000000000000000000000000000000000000000";
//#endregion
//#region node_modules/viem/_esm/actions/public/simulateCalls.js
var getBalanceCode = "0x6080604052348015600e575f80fd5b5061016d8061001c5f395ff3fe608060405234801561000f575f80fd5b5060043610610029575f3560e01c8063f8b2cb4f1461002d575b5f80fd5b610047600480360381019061004291906100db565b61005d565b604051610054919061011e565b60405180910390f35b5f8173ffffffffffffffffffffffffffffffffffffffff16319050919050565b5f80fd5b5f73ffffffffffffffffffffffffffffffffffffffff82169050919050565b5f6100aa82610081565b9050919050565b6100ba816100a0565b81146100c4575f80fd5b50565b5f813590506100d5816100b1565b92915050565b5f602082840312156100f0576100ef61007d565b5b5f6100fd848285016100c7565b91505092915050565b5f819050919050565b61011881610106565b82525050565b5f6020820190506101315f83018461010f565b9291505056fea26469706673582212203b9fe929fe995c7cf9887f0bdba8a36dd78e8b73f149b17d2d9ad7cd09d2dc6264736f6c634300081a0033";
var staticCallCode = "0x608060405234801561000f575f5ffd5b5060043610610029575f3560e01c8063fd00430c1461002d575b5f5ffd5b6100476004803603810190610042919061012b565b610049565b005b80825f375f5f825f865afa610060573d5f5f3e3d5ffd5b3d5f5f3e3d5ff35b5f5ffd5b5f5ffd5b5f73ffffffffffffffffffffffffffffffffffffffff82169050919050565b5f61009982610070565b9050919050565b6100a98161008f565b81146100b3575f5ffd5b50565b5f813590506100c4816100a0565b92915050565b5f5ffd5b5f5ffd5b5f5ffd5b5f5f83601f8401126100eb576100ea6100ca565b5b8235905067ffffffffffffffff811115610108576101076100ce565b5b602083019150836001820283011115610124576101236100d2565b5b9250929050565b5f5f5f6040848603121561014257610141610068565b5b5f61014f868287016100b6565b935050602084013567ffffffffffffffff8111156101705761016f61006c565b5b61017c868287016100d6565b9250925050925092509256fea2646970667358221220635ed99185cacf3f2acba6921f23687c969cec2bbaf5f9ad599f507e6e105e6964736f6c63430008230033";
var staticCallAddressBase = 3735928559n;
var transferEventSelector = getSelector(from("event Transfer(address indexed from, address indexed to, uint256 value)"));
var balanceOfFunction = from$1("function balanceOf(address) returns (uint256)");
var decimalsFunction = from$1("function decimals() returns (uint256)");
var tokenUriFunction = from$1("function tokenURI(uint256) returns (string)");
var symbolFunction = from$1("function symbol() returns (string)");
var staticCallFunction = from$1("function query(address target, bytes data)");
/**
* Simulates execution of a batch of calls.
*
* @param client - Client to use
* @param parameters - {@link SimulateCallsParameters}
* @returns Results. {@link SimulateCallsReturnType}
*
* @example
* ```ts
* import { createPublicClient, http, parseEther } from 'viem'
* import { mainnet } from 'viem/chains'
* import { simulateCalls } from 'viem/actions'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
*
* const result = await simulateCalls(client, {
*   account: '0x5a0b54d5dc17e482fe8b0bdca5320161b95fb929',
*   calls: [{
*     {
*       data: '0xdeadbeef',
*       to: '0x70997970c51812dc3a010c7d01b50e0d17dc79c8',
*     },
*     {
*       to: '0x70997970c51812dc3a010c7d01b50e0d17dc79c8',
*       value: parseEther('1'),
*     },
*   ]
* })
* ```
*/
async function simulateCalls(client, parameters) {
	const { blockNumber, blockTag, calls, stateOverrides, traceAssetChanges, traceTransfers, validation } = parameters;
	const account = parameters.account ? parseAccount(parameters.account) : void 0;
	if (traceAssetChanges && !account) throw new BaseError("`account` is required when `traceAssetChanges` is true");
	const getBalanceData = account ? encode(from$2("constructor(bytes, bytes)"), {
		bytecode: deploylessCallViaBytecodeBytecode,
		args: [getBalanceCode, encodeData(from$1("function getBalance(address)"), [account.address])]
	}) : void 0;
	const blockTag_ = blockTag ?? client.experimental_blockTag ?? "latest";
	let baseBlockNumber = blockNumber;
	if (traceAssetChanges && typeof baseBlockNumber !== "bigint" && blockTag_ !== "earliest" && blockTag_ !== "pending") {
		if (blockTag_ === "latest") baseBlockNumber = await getBlockNumber(client, { cacheTime: 0 });
		else {
			const block = await getBlock(client, { blockTag: blockTag_ });
			if (typeof block.number !== "bigint") throw new BaseError(`Block tag \`${blockTag_}\` did not resolve to a number.`);
			baseBlockNumber = block.number;
		}
	}
	const block_ = typeof baseBlockNumber === "bigint" ? { blockNumber: baseBlockNumber } : { blockTag: blockTag_ };
	const discovery = traceAssetChanges ? await simulateBlocks(client, {
		...block_,
		blocks: [{
			calls: calls.map((call) => ({
				...call,
				from: account.address
			})),
			stateOverrides
		}],
		traceTransfers,
		validation
	}) : void 0;
	const assetAddresses = discovery ? [.../* @__PURE__ */ new Set([...tokensFromLogs(discovery[0].calls.flatMap((call) => call.logs ?? []), account.address), ...parameters.calls.map((call) => call.to?.toLowerCase())])].filter((address) => Boolean(address) && address !== "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" && address !== "0x0000000000000000000000000000000000000000") : [];
	const staticCallAddress = getStaticCallAddress([
		...account ? [account.address] : [],
		...assetAddresses,
		...stateOverrides?.map(({ address }) => address) ?? []
	]);
	const staticCallStateOverrides = [{
		address: staticCallAddress,
		code: staticCallCode
	}];
	const [balanceCallsPre, blocks] = await Promise.all([traceAssetChanges ? Promise.all([readBalance(client, {
		account: account.address,
		...block_,
		data: getBalanceData,
		stateOverride: stateOverrides
	}), ...assetAddresses.map((address) => readBalance(client, {
		account: account.address,
		address,
		...block_,
		data: encodeData(balanceOfFunction, [account.address]),
		staticCallAddress,
		stateOverride: stateOverrides
	}))]) : [], simulateBlocks(client, {
		...block_,
		blocks: [{
			calls: [...calls, { to: zeroAddress }].map((call) => ({
				...call,
				from: account?.address
			})),
			stateOverrides
		}, ...traceAssetChanges ? [
			{ calls: [{ data: getBalanceData }] },
			{
				calls: assetAddresses.map((address) => ({
					to: staticCallAddress,
					data: encodeStaticCall(address, encodeData(balanceOfFunction, [account.address]))
				})),
				stateOverrides: staticCallStateOverrides
			},
			{
				calls: assetAddresses.map((address) => ({
					to: staticCallAddress,
					data: encodeStaticCall(address, encodeData(decimalsFunction))
				})),
				stateOverrides: staticCallStateOverrides
			},
			{
				calls: assetAddresses.map((address) => ({
					to: staticCallAddress,
					data: encodeStaticCall(address, encodeData(tokenUriFunction, [0n]))
				})),
				stateOverrides: staticCallStateOverrides
			},
			{
				calls: assetAddresses.map((address) => ({
					to: staticCallAddress,
					data: encodeStaticCall(address, encodeData(symbolFunction))
				})),
				stateOverrides: staticCallStateOverrides
			}
		] : []],
		traceTransfers,
		validation
	})]);
	const block_results = blocks[0];
	const [block_ethPost, block_assetsPost, block_decimals, block_tokenURI, block_symbols] = traceAssetChanges ? blocks.slice(1) : [];
	const { calls: block_calls, ...block } = block_results;
	const results = block_calls.slice(0, -1);
	const balancesPre = balanceCallsPre.map((call) => isBalance(call) ? hexToBigInt(call.data) : null);
	const ethPost = block_ethPost?.calls ?? [];
	const assetsPost = block_assetsPost?.calls ?? [];
	const balancesPost = [...ethPost, ...assetsPost].map((call) => isBalance(call) ? hexToBigInt(call.data) : null);
	const decimals = (block_decimals?.calls ?? []).map((call) => decodeAssetResult(call, decimalsFunction));
	const symbols = (block_symbols?.calls ?? []).map((call) => decodeAssetResult(call, symbolFunction));
	const tokenURI = (block_tokenURI?.calls ?? []).map((call) => decodeAssetResult(call, tokenUriFunction));
	const changes = [];
	for (const [i, balancePost] of balancesPost.entries()) {
		const balancePre_ = balancesPre[i];
		const preCall = balanceCallsPre[i];
		const balancePre = typeof balancePre_ === "bigint" ? balancePre_ : i > 0 && preCall?.status === "success" && preCall.data === "0x" ? 0n : null;
		if (typeof balancePost !== "bigint") continue;
		if (typeof balancePre !== "bigint") continue;
		const decimals_ = decimals[i - 1];
		const symbol_ = symbols[i - 1];
		const tokenURI_ = tokenURI[i - 1];
		const token = (() => {
			if (i === 0) return {
				address: ethAddress,
				decimals: 18,
				symbol: "ETH"
			};
			return {
				address: assetAddresses[i - 1],
				decimals: tokenURI_ || decimals_ ? Number(decimals_ ?? 1) : void 0,
				symbol: symbol_ ?? void 0
			};
		})();
		changes.push({
			token,
			value: {
				pre: balancePre,
				post: balancePost,
				diff: balancePost - balancePre
			}
		});
	}
	return {
		assetChanges: changes,
		block,
		results
	};
}
function encodeStaticCall(address, data) {
	return encodeData(staticCallFunction, [address, data]);
}
function tokensFromLogs(logs, account) {
	const account_ = pad(account.toLowerCase(), { size: 32 });
	return logs.filter((log) => {
		if (log.topics[0]?.toLowerCase() !== transferEventSelector) return false;
		if (log.address.toLowerCase() === "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee") return false;
		return log.topics[1]?.toLowerCase() === account_ || log.topics[2]?.toLowerCase() === account_;
	}).map((log) => log.address.toLowerCase());
}
function isBalance(call) {
	return call.status === "success" && /^0x[\da-f]{64}$/i.test(call.data);
}
function decodeAssetResult(call, abiFunction) {
	if (call.status === "failure" || call.data === "0x") return null;
	try {
		return decodeResult(abiFunction, call.data);
	} catch {
		return null;
	}
}
async function readBalance(client, parameters) {
	const { account, address, blockNumber, blockTag, data, staticCallAddress, stateOverride } = parameters;
	try {
		return {
			data: (await call({
				...client,
				ccipRead: false
			}, {
				account: address ? "0x0000000000000000000000000000000000000000" : account,
				data: address ? encodeStaticCall(address, data) : data,
				stateOverride: address && staticCallAddress ? [...stateOverride ?? [], {
					address: staticCallAddress,
					code: staticCallCode
				}] : stateOverride,
				...address ? { to: staticCallAddress } : {},
				...typeof blockNumber === "bigint" ? { blockNumber } : { blockTag }
			})).data ?? "0x",
			status: "success"
		};
	} catch (error) {
		if (!(error instanceof CallExecutionError) || !(error.cause instanceof ExecutionRevertedError)) throw error;
		return {
			data: "0x",
			status: "failure"
		};
	}
}
function getStaticCallAddress(addresses) {
	const occupied = new Set(addresses.map((address) => address.toLowerCase()));
	let value = staticCallAddressBase;
	while (occupied.has(`0x${value.toString(16).padStart(40, "0")}`)) value++;
	return `0x${value.toString(16).padStart(40, "0")}`;
}
//#endregion
//#region node_modules/viem/_esm/utils/signature/serializeSignature.js
/**
* @description Converts a signature into hex format.
*
* @param signature The signature to convert.
* @returns The signature in hex format.
*
* @example
* serializeSignature({
*   r: '0x6e100a352ec6ad1b70802290e18aeed190704973570f3b8ed42cb9808e2ea6bf',
*   s: '0x4a90a229a244495b41890987806fcbd2d5d23fc0dbe5f5256c2613c039d76db8',
*   yParity: 1
* })
* // "0x6e100a352ec6ad1b70802290e18aeed190704973570f3b8ed42cb9808e2ea6bf4a90a229a244495b41890987806fcbd2d5d23fc0dbe5f5256c2613c039d76db81c"
*/
function serializeSignature({ r, s, to = "hex", v, yParity }) {
	const yParity_ = (() => {
		if (yParity === 0 || yParity === 1) return yParity;
		if (v && (v === 27n || v === 28n || v >= 35n)) return v % 2n === 0n ? 1 : 0;
		throw new Error("Invalid `v` or `yParity` value");
	})();
	const signature = `0x${new secp256k1.Signature(hexToBigInt(r), hexToBigInt(s)).toCompactHex()}${yParity_ === 0 ? "1b" : "1c"}`;
	if (to === "hex") return signature;
	return hexToBytes(signature);
}
//#endregion
//#region node_modules/viem/_esm/actions/public/verifyHash.js
/**
* Verifies a message hash onchain using ERC-6492.
*
* @param client - Client to use.
* @param parameters - {@link VerifyHashParameters}
* @returns Whether or not the signature is valid. {@link VerifyHashReturnType}
*/
async function verifyHash(client, parameters) {
	const { address, chain = client.chain, hash, erc6492VerifierAddress: verifierAddress = parameters.universalSignatureVerifierAddress ?? chain?.contracts?.erc6492Verifier?.address, multicallAddress = parameters.multicallAddress ?? chain?.contracts?.multicall3?.address, mode = "auto" } = parameters;
	if (chain?.verifyHash) return await chain.verifyHash(client, parameters);
	const signature = (() => {
		const signature = parameters.signature;
		if (isHex(signature)) return signature;
		if (typeof signature === "object" && "r" in signature && "s" in signature) return serializeSignature(signature);
		return bytesToHex(signature);
	})();
	try {
		if (mode === "eoa") try {
			if (isAddressEqual(getAddress(address), await recoverAddress({
				hash,
				signature
			}))) return true;
		} catch {}
		if (validate(signature)) return await verifyErc8010(client, {
			...parameters,
			multicallAddress,
			signature
		});
		return await verifyErc6492(client, {
			...parameters,
			verifierAddress,
			signature
		});
	} catch (error) {
		if (mode !== "eoa") try {
			if (isAddressEqual(getAddress(address), await recoverAddress({
				hash,
				signature
			}))) return true;
		} catch {}
		if (error instanceof VerificationError) return false;
		throw error;
	}
}
/** @internal */
async function verifyErc8010(client, parameters) {
	const { address, blockHash, blockNumber, blockTag, hash, multicallAddress, requireCanonical } = parameters;
	const { authorization: authorization_ox, data: initData, signature, to } = unwrap(parameters.signature);
	if (await getCode(client, {
		address,
		blockHash,
		blockNumber,
		blockTag,
		requireCanonical
	}) === concatHex(["0xef0100", authorization_ox.address])) return await verifyErc1271(client, {
		...parameters,
		signature
	});
	const authorization = {
		address: authorization_ox.address,
		chainId: Number(authorization_ox.chainId),
		nonce: Number(authorization_ox.nonce),
		r: numberToHex(authorization_ox.r, { size: 32 }),
		s: numberToHex(authorization_ox.s, { size: 32 }),
		yParity: authorization_ox.yParity
	};
	if (!await verifyAuthorization({
		address,
		authorization
	})) throw new VerificationError();
	const results = await getAction(client, readContract, "readContract")({
		...multicallAddress ? { address: multicallAddress } : { code: multicall3Bytecode },
		authorizationList: [authorization],
		abi: multicall3Abi,
		blockHash,
		blockNumber,
		blockTag: "pending",
		functionName: "aggregate3",
		requireCanonical,
		args: [[...initData ? [{
			allowFailure: true,
			target: to ?? address,
			callData: initData
		}] : [], {
			allowFailure: true,
			target: address,
			callData: encodeFunctionData({
				abi: erc1271Abi,
				functionName: "isValidSignature",
				args: [hash, signature]
			})
		}]]
	});
	if ((results[results.length - 1]?.returnData)?.startsWith("0x1626ba7e")) return true;
	throw new VerificationError();
}
/** @internal */
async function verifyErc6492(client, parameters) {
	const { address, factory, factoryData, hash, signature, verifierAddress, ...rest } = parameters;
	const wrappedSignature = await (async () => {
		if (!factory && !factoryData) return signature;
		if (validate$1(signature)) return signature;
		return wrap({
			data: factoryData,
			signature,
			to: factory
		});
	})();
	const args = verifierAddress ? {
		to: verifierAddress,
		data: encodeFunctionData({
			abi: erc6492SignatureValidatorAbi,
			functionName: "isValidSig",
			args: [
				address,
				hash,
				wrappedSignature
			]
		}),
		...rest
	} : {
		data: encodeDeployData({
			abi: erc6492SignatureValidatorAbi,
			args: [
				address,
				hash,
				wrappedSignature
			],
			bytecode: erc6492SignatureValidatorByteCode
		}),
		...rest
	};
	const { data } = await getAction(client, call, "call")(args).catch((error) => {
		if (error instanceof CallExecutionError) throw new VerificationError();
		throw error;
	});
	if (hexToBool(data ?? "0x0")) return true;
	throw new VerificationError();
}
/** @internal */
async function verifyErc1271(client, parameters) {
	const { address, blockHash, blockNumber, blockTag, hash, requireCanonical, signature } = parameters;
	if ((await getAction(client, readContract, "readContract")({
		address,
		abi: erc1271Abi,
		args: [hash, signature],
		blockHash,
		blockNumber,
		blockTag,
		functionName: "isValidSignature",
		requireCanonical
	}).catch((error) => {
		if (error instanceof ContractFunctionExecutionError) throw new VerificationError();
		throw error;
	})).startsWith("0x1626ba7e")) return true;
	throw new VerificationError();
}
var VerificationError = class extends Error {};
//#endregion
//#region node_modules/viem/_esm/actions/public/verifyMessage.js
/**
* Verify that a message was signed by the provided address.
*
* Compatible with Smart Contract Accounts & Externally Owned Accounts via [ERC-6492](https://eips.ethereum.org/EIPS/eip-6492).
*
* - Docs {@link https://viem.sh/docs/actions/public/verifyMessage}
*
* @param client - Client to use.
* @param parameters - {@link VerifyMessageParameters}
* @returns Whether or not the signature is valid. {@link VerifyMessageReturnType}
*/
async function verifyMessage(client, { address, message, factory, factoryData, signature, ...callRequest }) {
	const hash = hashMessage(message);
	return getAction(client, verifyHash, "verifyHash")({
		address,
		factory,
		factoryData,
		hash,
		signature,
		...callRequest
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/public/verifyTypedData.js
/**
* Verify that typed data was signed by the provided address.
*
* - Docs {@link https://viem.sh/docs/actions/public/verifyTypedData}
*
* @param client - Client to use.
* @param parameters - {@link VerifyTypedDataParameters}
* @returns Whether or not the signature is valid. {@link VerifyTypedDataReturnType}
*/
async function verifyTypedData(client, parameters) {
	const { address, factory, factoryData, signature, message, primaryType, types, domain, ...callRequest } = parameters;
	const hash = hashTypedData({
		message,
		primaryType,
		types,
		domain
	});
	return getAction(client, verifyHash, "verifyHash")({
		address,
		factory,
		factoryData,
		hash,
		signature,
		...callRequest
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/public/watchBlockHeaders.js
var blockFields = [
	"size",
	"totalDifficulty",
	"transactions",
	"uncles",
	"withdrawals"
];
/**
* Watches and returns incoming block headers.
*
* - Docs: https://viem.sh/docs/actions/public/watchBlockHeaders
* - JSON-RPC Methods: Uses a WebSocket or IPC subscription via [`eth_subscribe`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_subscribe) and the `"newHeads"` event.
*
* @param client - Client to use
* @param parameters - {@link WatchBlockHeadersParameters}
* @returns A function that can be invoked to stop watching for new block headers. {@link WatchBlockHeadersReturnType}
*
* @example
* import { createPublicClient, webSocket } from 'viem'
* import { watchBlockHeaders } from 'viem/actions'
* import { mainnet } from 'viem/chains'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: webSocket(),
* })
* const unwatch = watchBlockHeaders(client, {
*   onBlockHeader: (blockHeader) => console.log(blockHeader),
* })
*/
function watchBlockHeaders(client, { onBlockHeader, onError }) {
	let prevBlockHeader;
	const observerId = stringify(["watchBlockHeaders", client.uid]);
	return observe(observerId, {
		onBlockHeader,
		onError
	}, (emit) => {
		let active = true;
		let subscribed = false;
		let unsubscribe = () => active = false;
		(async () => {
			try {
				const { unsubscribe: unsubscribe_ } = await (() => {
					if (client.transport.type === "fallback") {
						const transport = client.transport.transports.find((transport) => transport.config.type === "webSocket" || transport.config.type === "ipc");
						if (!transport) return client.transport;
						return transport.value;
					}
					return client.transport;
				})().subscribe({
					params: ["newHeads"],
					onData(data) {
						if (!active) return;
						const blockHeader = (client.chain?.formatters?.block?.format || formatBlock)(data.result, "watchBlockHeaders");
						for (const field of blockFields) delete blockHeader[field];
						emit.onBlockHeader(blockHeader, prevBlockHeader);
						prevBlockHeader = blockHeader;
					},
					onError(error) {
						if (subscribed) emit.onError?.(error);
					}
				});
				subscribed = true;
				unsubscribe = unsubscribe_;
				if (!active) unsubscribe();
			} catch (err) {
				emit.onError?.(err);
			}
		})();
		return () => unsubscribe();
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/public/watchBlocks.js
/**
* Watches and returns information for incoming blocks.
*
* - Docs: https://viem.sh/docs/actions/public/watchBlocks
* - Examples: https://stackblitz.com/github/wevm/viem/tree/main/examples/blocks_watching-blocks
* - JSON-RPC Methods:
*   - When `poll: true`, calls [`eth_getBlockByNumber`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getBlockByNumber) on a polling interval.
*   - When `poll: false` & WebSocket Transport, uses a WebSocket subscription via [`eth_subscribe`](https://docs.alchemy.com/reference/eth-subscribe-polygon) and the `"newHeads"` event.
*
* @param client - Client to use
* @param parameters - {@link WatchBlocksParameters}
* @returns A function that can be invoked to stop watching for new block numbers. {@link WatchBlocksReturnType}
*
* @example
* import { createPublicClient, watchBlocks, http } from 'viem'
* import { mainnet } from 'viem/chains'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const unwatch = watchBlocks(client, {
*   onBlock: (block) => console.log(block),
* })
*/
function watchBlocks(client, { blockTag = client.experimental_blockTag ?? "latest", emitMissed = false, emitOnBegin = false, onBlock, onError, includeTransactions: includeTransactions_, poll: poll_, pollingInterval = client.pollingInterval }) {
	const enablePolling = (() => {
		if (typeof poll_ !== "undefined") return poll_;
		if (client.transport.type === "webSocket" || client.transport.type === "ipc") return false;
		if (client.transport.type === "fallback" && (client.transport.transports[0].config.type === "webSocket" || client.transport.transports[0].config.type === "ipc")) return false;
		return true;
	})();
	const includeTransactions = includeTransactions_ ?? false;
	let prevBlock;
	const pollBlocks = () => {
		const observerId = stringify([
			"watchBlocks",
			client.uid,
			blockTag,
			emitMissed,
			emitOnBegin,
			includeTransactions,
			pollingInterval
		]);
		return observe(observerId, {
			onBlock,
			onError
		}, (emit) => poll(async () => {
			try {
				const block = await getAction(client, getBlock, "getBlock")({
					blockTag,
					includeTransactions
				});
				if (block.number !== null && prevBlock?.number != null) {
					if (block.number === prevBlock.number) return;
					if (block.number - prevBlock.number > 1 && emitMissed) for (let i = prevBlock?.number + 1n; i < block.number; i++) {
						const block = await getAction(client, getBlock, "getBlock")({
							blockNumber: i,
							includeTransactions
						});
						emit.onBlock(block, prevBlock);
						prevBlock = block;
					}
				}
				if (prevBlock?.number == null || blockTag === "pending" && block?.number == null || block.number !== null && block.number > prevBlock.number) {
					emit.onBlock(block, prevBlock);
					prevBlock = block;
				}
			} catch (err) {
				emit.onError?.(err);
			}
		}, {
			emitOnBegin,
			interval: pollingInterval
		}));
	};
	const subscribeBlocks = () => {
		let active = true;
		let emitFetched = true;
		let unsubscribe = () => active = false;
		(async () => {
			try {
				if (emitOnBegin) getAction(client, getBlock, "getBlock")({
					blockTag,
					includeTransactions
				}).then((block) => {
					if (!active) return;
					if (!emitFetched) return;
					onBlock(block, void 0);
					emitFetched = false;
				}).catch(onError);
				const { unsubscribe: unsubscribe_ } = await (() => {
					if (client.transport.type === "fallback") {
						const transport = client.transport.transports.find((transport) => transport.config.type === "webSocket" || transport.config.type === "ipc");
						if (!transport) return client.transport;
						return transport.value;
					}
					return client.transport;
				})().subscribe({
					params: ["newHeads"],
					async onData(data) {
						if (!active) return;
						const block = await getAction(client, getBlock, "getBlock")({
							blockNumber: data.result?.number,
							includeTransactions
						}).catch(() => {});
						if (!active) return;
						onBlock(block, prevBlock);
						emitFetched = false;
						prevBlock = block;
					},
					onError(error) {
						onError?.(error);
					}
				});
				unsubscribe = unsubscribe_;
				if (!active) unsubscribe();
			} catch (err) {
				onError?.(err);
			}
		})();
		return () => unsubscribe();
	};
	return enablePolling ? pollBlocks() : subscribeBlocks();
}
//#endregion
//#region node_modules/viem/_esm/actions/public/watchEvent.js
/**
* Watches and returns emitted [Event Logs](https://viem.sh/docs/glossary/terms#event-log).
*
* - Docs: https://viem.sh/docs/actions/public/watchEvent
* - JSON-RPC Methods:
*   - **RPC Provider supports `eth_newFilter`:**
*     - Calls [`eth_newFilter`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_newfilter) to create a filter (called on initialize).
*     - On a polling interval, it will call [`eth_getFilterChanges`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getfilterchanges).
*   - **RPC Provider does not support `eth_newFilter`:**
*     - Calls [`eth_getLogs`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getlogs) for each block between the polling interval.
*
* This Action will batch up all the Event Logs found within the [`pollingInterval`](https://viem.sh/docs/actions/public/watchEvent#pollinginterval-optional), and invoke them via [`onLogs`](https://viem.sh/docs/actions/public/watchEvent#onLogs).
*
* `watchEvent` will attempt to create an [Event Filter](https://viem.sh/docs/actions/public/createEventFilter) and listen to changes to the Filter per polling interval, however, if the RPC Provider does not support Filters (e.g. `eth_newFilter`), then `watchEvent` will fall back to using [`getLogs`](https://viem.sh/docs/actions/public/getLogs) instead.
*
* @param client - Client to use
* @param parameters - {@link WatchEventParameters}
* @returns A function that can be invoked to stop watching for new Event Logs. {@link WatchEventReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { watchEvent } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const unwatch = watchEvent(client, {
*   onLogs: (logs) => console.log(logs),
* })
*/
function watchEvent(client, { address, args, batch = true, event, events, fromBlock, onError, onLogs, poll: poll_, pollingInterval = client.pollingInterval, strict: strict_ }) {
	const enablePolling = (() => {
		if (typeof poll_ !== "undefined") return poll_;
		if (typeof fromBlock === "bigint") return true;
		if (client.transport.type === "webSocket" || client.transport.type === "ipc") return false;
		if (client.transport.type === "fallback" && (client.transport.transports[0].config.type === "webSocket" || client.transport.transports[0].config.type === "ipc")) return false;
		return true;
	})();
	const strict = strict_ ?? false;
	const pollEvent = () => {
		const observerId = stringify([
			"watchEvent",
			address,
			args,
			batch,
			client.uid,
			event,
			pollingInterval,
			fromBlock
		]);
		return observe(observerId, {
			onLogs,
			onError
		}, (emit) => {
			let previousBlockNumber;
			if (fromBlock !== void 0) previousBlockNumber = fromBlock - 1n;
			let filter;
			let initialized = false;
			const unwatch = poll(async () => {
				if (!initialized) {
					try {
						filter = await getAction(client, createEventFilter, "createEventFilter")({
							address,
							args,
							event,
							events,
							strict,
							fromBlock
						});
					} catch {}
					initialized = true;
					return;
				}
				try {
					let logs;
					if (filter) logs = await getAction(client, getFilterChanges, "getFilterChanges")({ filter });
					else {
						const blockNumber = await getAction(client, getBlockNumber, "getBlockNumber")({});
						if (previousBlockNumber && previousBlockNumber !== blockNumber) logs = await getAction(client, getLogs, "getLogs")({
							address,
							args,
							event,
							events,
							fromBlock: previousBlockNumber + 1n,
							toBlock: blockNumber
						});
						else logs = [];
						previousBlockNumber = blockNumber;
					}
					if (logs.length === 0) return;
					if (batch) emit.onLogs(logs);
					else for (const log of logs) emit.onLogs([log]);
				} catch (err) {
					if (filter && err instanceof InvalidInputRpcError) initialized = false;
					emit.onError?.(err);
				}
			}, {
				emitOnBegin: true,
				interval: pollingInterval
			});
			return async () => {
				if (filter) await getAction(client, uninstallFilter, "uninstallFilter")({ filter });
				unwatch();
			};
		});
	};
	const subscribeEvent = () => {
		let active = true;
		let unsubscribe = () => active = false;
		(async () => {
			try {
				const transport = (() => {
					if (client.transport.type === "fallback") {
						const transport = client.transport.transports.find((transport) => transport.config.type === "webSocket" || transport.config.type === "ipc");
						if (!transport) return client.transport;
						return transport.value;
					}
					return client.transport;
				})();
				const events_ = events ?? (event ? [event] : void 0);
				let topics = [];
				if (events_) {
					topics = [events_.flatMap((event) => encodeEventTopics({
						abi: [event],
						eventName: event.name,
						args
					}))];
					if (event) topics = topics[0];
				}
				const { unsubscribe: unsubscribe_ } = await transport.subscribe({
					params: ["logs", {
						address,
						topics
					}],
					onData(data) {
						if (!active) return;
						const log = data.result;
						try {
							const { eventName, args } = decodeEventLog({
								abi: events_ ?? [],
								data: log.data,
								topics: log.topics,
								strict
							});
							onLogs([formatLog(log, {
								args,
								eventName
							})]);
						} catch (err) {
							let eventName;
							let isUnnamed;
							if (err instanceof DecodeLogDataMismatch || err instanceof DecodeLogTopicsMismatch) {
								if (strict_) return;
								eventName = err.abiItem.name;
								isUnnamed = err.abiItem.inputs?.some((x) => !("name" in x && x.name));
							}
							onLogs([formatLog(log, {
								args: isUnnamed ? [] : {},
								eventName
							})]);
						}
					},
					onError(error) {
						onError?.(error);
					}
				});
				unsubscribe = unsubscribe_;
				if (!active) unsubscribe();
			} catch (err) {
				onError?.(err);
			}
		})();
		return () => unsubscribe();
	};
	return enablePolling ? pollEvent() : subscribeEvent();
}
//#endregion
//#region node_modules/viem/_esm/actions/public/watchPendingTransactions.js
/**
* Watches and returns pending transaction hashes.
*
* - Docs: https://viem.sh/docs/actions/public/watchPendingTransactions
* - JSON-RPC Methods:
*   - When `poll: true`
*     - Calls [`eth_newPendingTransactionFilter`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_newpendingtransactionfilter) to initialize the filter.
*     - Calls [`eth_getFilterChanges`](https://ethereum.org/en/developers/docs/apis/json-rpc/#eth_getFilterChanges) on a polling interval.
*   - When `poll: false` & WebSocket Transport, uses a WebSocket subscription via [`eth_subscribe`](https://docs.alchemy.com/reference/eth-subscribe-polygon) and the `"newPendingTransactions"` event.
*
* This Action will batch up all the pending transactions found within the [`pollingInterval`](https://viem.sh/docs/actions/public/watchPendingTransactions#pollinginterval-optional), and invoke them via [`onTransactions`](https://viem.sh/docs/actions/public/watchPendingTransactions#ontransactions).
*
* @param client - Client to use
* @param parameters - {@link WatchPendingTransactionsParameters}
* @returns A function that can be invoked to stop watching for new pending transaction hashes. {@link WatchPendingTransactionsReturnType}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { watchPendingTransactions } from 'viem/public'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
* const unwatch = await watchPendingTransactions(client, {
*   onTransactions: (hashes) => console.log(hashes),
* })
*/
function watchPendingTransactions(client, { batch = true, onError, onTransactions, poll: poll_, pollingInterval = client.pollingInterval }) {
	const enablePolling = typeof poll_ !== "undefined" ? poll_ : client.transport.type !== "webSocket" && client.transport.type !== "ipc";
	const pollPendingTransactions = () => {
		const observerId = stringify([
			"watchPendingTransactions",
			client.uid,
			batch,
			pollingInterval
		]);
		return observe(observerId, {
			onTransactions,
			onError
		}, (emit) => {
			let filter;
			const unwatch = poll(async () => {
				try {
					if (!filter) try {
						filter = await getAction(client, createPendingTransactionFilter, "createPendingTransactionFilter")({});
						return;
					} catch (err) {
						unwatch();
						throw err;
					}
					const hashes = await getAction(client, getFilterChanges, "getFilterChanges")({ filter });
					if (hashes.length === 0) return;
					if (batch) emit.onTransactions(hashes);
					else for (const hash of hashes) emit.onTransactions([hash]);
				} catch (err) {
					emit.onError?.(err);
				}
			}, {
				emitOnBegin: true,
				interval: pollingInterval
			});
			return async () => {
				if (filter) await getAction(client, uninstallFilter, "uninstallFilter")({ filter });
				unwatch();
			};
		});
	};
	const subscribePendingTransactions = () => {
		let active = true;
		let unsubscribe = () => active = false;
		(async () => {
			try {
				const { unsubscribe: unsubscribe_ } = await client.transport.subscribe({
					params: ["newPendingTransactions"],
					onData(data) {
						if (!active) return;
						const transaction = data.result;
						onTransactions([transaction]);
					},
					onError(error) {
						onError?.(error);
					}
				});
				unsubscribe = unsubscribe_;
				if (!active) unsubscribe();
			} catch (err) {
				onError?.(err);
			}
		})();
		return () => unsubscribe();
	};
	return enablePolling ? pollPendingTransactions() : subscribePendingTransactions();
}
//#endregion
//#region node_modules/viem/_esm/utils/siwe/parseSiweMessage.js
var siweDateTimeRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$/;
function isValidSiweDateTime(value) {
	if (!siweDateTimeRegex.test(value)) return false;
	return !Number.isNaN(new Date(value).getTime());
}
function parseSiweDateTime(value) {
	if (!isValidSiweDateTime(value)) return /* @__PURE__ */ new Date(NaN);
	return new Date(value);
}
/**
* @description Parses EIP-4361 formatted message into message fields object.
*
* @see https://eips.ethereum.org/EIPS/eip-4361
*
* @returns EIP-4361 fields object
*/
function parseSiweMessage(message) {
	const { scheme, statement, ...prefix } = message.match(prefixRegex)?.groups ?? {};
	const { chainId, expirationTime, issuedAt, notBefore, requestId, ...suffix } = message.match(suffixRegex)?.groups ?? {};
	const resources = message.split("Resources:")[1]?.split("\n- ").slice(1);
	return {
		...prefix,
		...suffix,
		...chainId ? { chainId: Number(chainId) } : {},
		...expirationTime ? { expirationTime: parseSiweDateTime(expirationTime) } : {},
		...issuedAt ? { issuedAt: parseSiweDateTime(issuedAt) } : {},
		...notBefore ? { notBefore: parseSiweDateTime(notBefore) } : {},
		...requestId ? { requestId } : {},
		...resources ? { resources } : {},
		...scheme ? { scheme } : {},
		...statement ? { statement } : {}
	};
}
var prefixRegex = /^(?:(?<scheme>[a-zA-Z][a-zA-Z0-9+-.]*):\/\/)?(?<domain>[a-zA-Z0-9+-.]*(?::[0-9]{1,5})?) (?:wants you to sign in with your Ethereum account:\n)(?<address>0x[a-fA-F0-9]{40})\n\n(?:(?<statement>.*)\n\n)?/;
var suffixRegex = /(?:URI: (?<uri>.+))\n(?:Version: (?<version>.+))\n(?:Chain ID: (?<chainId>\d+))\n(?:Nonce: (?<nonce>[a-zA-Z0-9]+))\n(?:Issued At: (?<issuedAt>.+))(?:\nExpiration Time: (?<expirationTime>.+))?(?:\nNot Before: (?<notBefore>.+))?(?:\nRequest ID: (?<requestId>.+))?/;
//#endregion
//#region node_modules/viem/_esm/utils/siwe/validateSiweMessage.js
/**
* @description Validates EIP-4361 message.
*
* @see https://eips.ethereum.org/EIPS/eip-4361
*/
function validateSiweMessage(parameters) {
	const { address, domain, message, nonce, scheme, time = /* @__PURE__ */ new Date() } = parameters;
	if (domain && message.domain !== domain) return false;
	if (nonce && message.nonce !== nonce) return false;
	if (scheme && message.scheme !== scheme) return false;
	if (Number.isNaN(time.getTime())) return false;
	if (message.expirationTime) {
		if (Number.isNaN(message.expirationTime.getTime())) return false;
		if (time >= message.expirationTime) return false;
	}
	if (message.notBefore) {
		if (Number.isNaN(message.notBefore.getTime())) return false;
		if (time < message.notBefore) return false;
	}
	try {
		if (!message.address) return false;
		if (!isAddress(message.address, { strict: false })) return false;
		if (address && !isAddressEqual(message.address, address)) return false;
	} catch {
		return false;
	}
	return true;
}
//#endregion
//#region node_modules/viem/_esm/actions/siwe/verifySiweMessage.js
/**
* Verifies [EIP-4361](https://eips.ethereum.org/EIPS/eip-4361) formatted message was signed.
*
* Compatible with Smart Contract Accounts & Externally Owned Accounts via [ERC-6492](https://eips.ethereum.org/EIPS/eip-6492).
*
* - Docs {@link https://viem.sh/docs/siwe/actions/verifySiweMessage}
*
* @param client - Client to use.
* @param parameters - {@link VerifySiweMessageParameters}
* @returns Whether or not the signature is valid. {@link VerifySiweMessageReturnType}
*/
async function verifySiweMessage(client, parameters) {
	const { address, domain, message, nonce, scheme, signature, time = /* @__PURE__ */ new Date(), ...callRequest } = parameters;
	const parsed = parseSiweMessage(message);
	if (!parsed.address) return false;
	if (!validateSiweMessage({
		address,
		domain,
		message: parsed,
		nonce,
		scheme,
		time
	})) return false;
	const hash = hashMessage(message);
	return verifyHash(client, {
		address: parsed.address,
		hash,
		signature,
		...callRequest
	});
}
//#endregion
//#region node_modules/viem/_esm/actions/token/getAllowance.js
/**
* Gets the ERC-20 allowance a spender has over an account's tokens.
*
* @example
* ```ts
* import { createClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { token } from 'viem/actions'
*
* const client = createClient({ chain: mainnet, transport: http() })
*
* const allowance = await token.getAllowance(client, {
*   account: '0x...',
*   spender: '0x...',
*   token: '0x...',
* })
* ```
*
* @param client - Client.
* @param parameters - Parameters.
* @returns The allowance, in base units and human-readable form.
*/
async function getAllowance(client, parameters) {
	const { account, decimals, spender, token, ...rest } = parameters;
	const [amount, { decimals: resolved }] = await Promise.all([readContract(client, {
		...rest,
		...getAllowance.call(client, {
			account,
			spender,
			token
		})
	}), resolveTokenWithDecimals(client, {
		decimals,
		token
	})]);
	return toAmount(amount, resolved);
}
(function(getAllowance) {
	/**
	* Defines a call to the `allowance` function.
	*
	* Can be passed as a parameter to `multicall`, `simulateContract`, or any
	* other action that accepts a contract call. The token is selected by `token`
	* symbol (resolved from the client's `tokens` array) or contract address.
	*
	* @param client - Client.
	* @param args - Arguments.
	* @returns The call.
	*/
	function call(client, args) {
		return defineCall({
			address: resolveToken(client, args).address,
			abi: erc20Abi,
			functionName: "allowance",
			args: [args.account, args.spender]
		});
	}
	getAllowance.call = call;
})(getAllowance || (getAllowance = {}));
//#endregion
//#region node_modules/viem/_esm/actions/token/getBalance.js
/**
* Gets the ERC-20 token balance of an account.
*
* @example
* ```ts
* import { createClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { token } from 'viem/actions'
*
* const client = createClient({ chain: mainnet, transport: http() })
*
* const balance = await token.getBalance(client, {
*   account: '0x...',
*   token: '0x...',
* })
* ```
*
* @param client - Client.
* @param parameters - Parameters.
* @returns The token balance, in base units and human-readable form.
*/
async function getBalance(client, parameters) {
	const { account: account_ = client.account, decimals, token, ...rest } = parameters;
	if (!account_) throw new AccountNotFoundError();
	const account = parseAccount(account_).address;
	const [amount, { decimals: resolved }] = await Promise.all([readContract(client, {
		...rest,
		...getBalance.call(client, {
			account,
			token
		})
	}), resolveTokenWithDecimals(client, {
		decimals,
		token
	})]);
	return toAmount(amount, resolved);
}
(function(getBalance) {
	/**
	* Defines a call to the `balanceOf` function.
	*
	* Can be passed as a parameter to `multicall`, `simulateContract`, or any
	* other action that accepts a contract call. The token is selected by `token`
	* symbol (resolved from the client's `tokens` array) or contract address.
	*
	* @param client - Client.
	* @param args - Arguments.
	* @returns The call.
	*/
	function call(client, args) {
		const account_ = args.account ?? client.account;
		if (!account_) throw new AccountNotFoundError();
		const account = parseAccount(account_).address;
		return defineCall({
			address: resolveToken(client, args).address,
			abi: erc20Abi,
			functionName: "balanceOf",
			args: [account]
		});
	}
	getBalance.call = call;
})(getBalance || (getBalance = {}));
//#endregion
//#region node_modules/viem/_esm/actions/token/getMetadata.js
/**
* Gets the metadata (`decimals`, `name`, `symbol`) of an ERC-20 token.
*
* Fields declared on the Client's `tokens` array are used as-is; any missing
* field is fetched from the token contract.
*
* @example
* ```ts
* import { createClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { token } from 'viem/actions'
*
* const client = createClient({ chain: mainnet, transport: http() })
*
* const metadata = await token.getMetadata(client, {
*   token: '0x...',
* })
* ```
*
* @param client - Client.
* @param parameters - Parameters.
* @returns The token metadata (`decimals`, `name`, `symbol`).
*/
async function getMetadata(client, parameters) {
	const { token, ...rest } = parameters;
	const { address } = resolveToken(client, { token });
	const declared = findDeclaredToken(client, token);
	const [decimals_, name, symbol] = await Promise.all([
		declared?.decimals ?? readContract(client, {
			...rest,
			abi: erc20Abi,
			address,
			functionName: "decimals"
		}),
		declared?.name ?? readContract(client, {
			...rest,
			abi: erc20Abi,
			address,
			functionName: "name"
		}),
		declared?.symbol ?? readContract(client, {
			...rest,
			abi: erc20Abi,
			address,
			functionName: "symbol"
		})
	]);
	return {
		decimals: decimals_,
		name,
		symbol
	};
}
//#endregion
//#region node_modules/viem/_esm/actions/token/getTotalSupply.js
/**
* Gets the total supply of an ERC-20 token.
*
* @example
* ```ts
* import { createClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
* import { token } from 'viem/actions'
*
* const client = createClient({ chain: mainnet, transport: http() })
*
* const totalSupply = await token.getTotalSupply(client, {
*   token: '0x...',
* })
* ```
*
* @param client - Client.
* @param parameters - Parameters.
* @returns The token total supply, in base units and human-readable form.
*/
async function getTotalSupply(client, parameters) {
	const { decimals, token, ...rest } = parameters;
	const [amount, { decimals: resolved }] = await Promise.all([readContract(client, {
		...rest,
		...getTotalSupply.call(client, { token })
	}), resolveTokenWithDecimals(client, {
		decimals,
		token
	})]);
	return toAmount(amount, resolved);
}
(function(getTotalSupply) {
	/**
	* Defines a call to the `totalSupply` function.
	*
	* Can be passed as a parameter to `multicall`, `simulateContract`, or any
	* other action that accepts a contract call. The token is selected by `token`
	* symbol (resolved from the client's `tokens` array) or contract address.
	*
	* @param client - Client.
	* @param args - Arguments.
	* @returns The call.
	*/
	function call(client, args) {
		return defineCall({
			address: resolveToken(client, args).address,
			abi: erc20Abi,
			args: [],
			functionName: "totalSupply"
		});
	}
	getTotalSupply.call = call;
})(getTotalSupply || (getTotalSupply = {}));
//#endregion
//#region node_modules/viem/_esm/clients/decorators/public.js
function publicActions(client) {
	return {
		call: (args) => call(client, args),
		createAccessList: (args) => createAccessList(client, args),
		createBlockFilter: () => createBlockFilter(client),
		createContractEventFilter: (args) => createContractEventFilter(client, args),
		createEventFilter: (args) => createEventFilter(client, args),
		createPendingTransactionFilter: () => createPendingTransactionFilter(client),
		estimateContractGas: (args) => estimateContractGas(client, args),
		estimateGas: (args) => estimateGas(client, args),
		getBalance: (args) => getBalance$1(client, args),
		getBlobBaseFee: () => getBlobBaseFee(client),
		getBlock: (args) => getBlock(client, args),
		getBlockNumber: (args) => getBlockNumber(client, args),
		getBlockReceipts: (args) => getBlockReceipts(client, args),
		getBlockTransactionCount: (args) => getBlockTransactionCount(client, args),
		getBytecode: (args) => getCode(client, args),
		getChainId: () => getChainId(client),
		getCode: (args) => getCode(client, args),
		getContractEvents: (args) => getContractEvents(client, args),
		getDelegation: (args) => getDelegation(client, args),
		getEip712Domain: (args) => getEip712Domain(client, args),
		getEnsAddress: (args) => getEnsAddress(client, args),
		getEnsAvatar: (args) => getEnsAvatar(client, args),
		getEnsName: (args) => getEnsName(client, args),
		getEnsResolver: (args) => getEnsResolver(client, args),
		getEnsText: (args) => getEnsText(client, args),
		getFeeHistory: (args) => getFeeHistory(client, args),
		estimateFeesPerGas: (args) => estimateFeesPerGas(client, args),
		getFilterChanges: (args) => getFilterChanges(client, args),
		getFilterLogs: (args) => getFilterLogs(client, args),
		getGasPrice: () => getGasPrice(client),
		getLogs: (args) => getLogs(client, args),
		getProof: (args) => getProof(client, args),
		estimateMaxPriorityFeePerGas: (args) => estimateMaxPriorityFeePerGas(client, args),
		fillTransaction: (args) => fillTransaction(client, args),
		getRawTransaction: (args) => getRawTransaction(client, args),
		getStorageAt: (args) => getStorageAt(client, args),
		getTransaction: (args) => getTransaction(client, args),
		getTransactionConfirmations: (args) => getTransactionConfirmations(client, args),
		getTransactionCount: (args) => getTransactionCount(client, args),
		getTransactionReceipt: (args) => getTransactionReceipt(client, args),
		multicall: (args) => multicall(client, args),
		prepareTransactionRequest: (args) => prepareTransactionRequest(client, args),
		readContract: (args) => readContract(client, args),
		sendRawTransaction: (args) => sendRawTransaction(client, args),
		sendRawTransactionSync: (args) => sendRawTransactionSync(client, args),
		simulate: (args) => simulateBlocks(client, args),
		simulateBlocks: (args) => simulateBlocks(client, args),
		simulateCalls: (args) => simulateCalls(client, args),
		simulateContract: (args) => simulateContract(client, args),
		verifyHash: (args) => verifyHash(client, args),
		verifyMessage: (args) => verifyMessage(client, args),
		verifySiweMessage: (args) => verifySiweMessage(client, args),
		verifyTypedData: (args) => verifyTypedData(client, args),
		uninstallFilter: (args) => uninstallFilter(client, args),
		waitForTransactionReceipt: (args) => waitForTransactionReceipt(client, args),
		watchBlockHeaders: (args) => watchBlockHeaders(client, args),
		watchBlocks: (args) => watchBlocks(client, args),
		watchBlockNumber: (args) => watchBlockNumber(client, args),
		watchContractEvent: (args) => watchContractEvent(client, args),
		watchEvent: (args) => watchEvent(client, args),
		watchPendingTransactions: (args) => watchPendingTransactions(client, args),
		token: bindPublicToken(client)
	};
}
/**
* Binds the read-only ERC-20 actions (and their `.call` helpers) to `client`.
* Merged with the write actions from {@link walletActions} (when present) by the
* Client's `extend`, which shallow-merges conflicting plain-object namespaces.
* @internal
*/
function bindPublicToken(client) {
	return {
		getAllowance: bindActionDecorators(client, getAllowance),
		getBalance: bindActionDecorators(client, getBalance),
		getMetadata: bindActionDecorators(client, getMetadata),
		getTotalSupply: bindActionDecorators(client, getTotalSupply)
	};
}
//#endregion
//#region node_modules/viem/_esm/clients/createPublicClient.js
/**
* Creates a Public Client with a given [Transport](https://viem.sh/docs/clients/intro) configured for a [Chain](https://viem.sh/docs/clients/chains).
*
* - Docs: https://viem.sh/docs/clients/public
*
* A Public Client is an interface to "public" [JSON-RPC API](https://ethereum.org/en/developers/docs/apis/json-rpc/) methods such as retrieving block numbers, transactions, reading from smart contracts, etc through [Public Actions](/docs/actions/public/introduction).
*
* @param config - {@link PublicClientConfig}
* @returns A Public Client. {@link PublicClient}
*
* @example
* import { createPublicClient, http } from 'viem'
* import { mainnet } from 'viem/chains'
*
* const client = createPublicClient({
*   chain: mainnet,
*   transport: http(),
* })
*/
function createPublicClient(parameters) {
	const { key = "public", name = "Public Client" } = parameters;
	return createClient({
		...parameters,
		key,
		name,
		type: "publicClient"
	}).extend(publicActions);
}
//#endregion
//#region node_modules/viem/_esm/errors/transport.js
var UrlRequiredError = class extends BaseError {
	constructor() {
		super("No URL was provided to the Transport. Please provide a valid RPC URL to the Transport.", {
			docsPath: "/docs/clients/intro",
			name: "UrlRequiredError"
		});
	}
};
//#endregion
//#region node_modules/viem/_esm/clients/transports/http.js
var signalId = 0;
var signalIds = /* @__PURE__ */ new WeakMap();
function getSignalId(signal) {
	if (!signal) return "default";
	const id = signalIds.get(signal);
	if (id !== void 0) return id;
	const nextId = signalId++;
	signalIds.set(signal, nextId);
	return nextId;
}
/**
* @description Creates a HTTP transport that connects to a JSON-RPC API.
*/
function http(url, config = {}) {
	const { batch, fetchFn, fetchOptions, key = "http", maxResponseBodySize, methods, name = "HTTP JSON-RPC", onFetchRequest, onFetchResponse, retryDelay, raw } = config;
	return ({ chain, retryCount: retryCount_, timeout: timeout_ }) => {
		const { batchSize = 1e3, wait = 0 } = typeof batch === "object" ? batch : {};
		const retryCount = config.retryCount ?? retryCount_;
		const timeout = timeout_ ?? config.timeout ?? 1e4;
		const url_ = url || chain?.rpcUrls.default.http[0];
		if (!url_) throw new UrlRequiredError();
		const rpcClient = getHttpRpcClient(url_, {
			fetchFn,
			fetchOptions,
			maxResponseBodySize,
			onRequest: onFetchRequest,
			onResponse: onFetchResponse,
			timeout
		});
		return createTransport({
			key,
			methods,
			name,
			async request({ method, params }, options) {
				const body = {
					method,
					params
				};
				const fetchOptions = options?.signal ? { signal: options.signal } : void 0;
				const { schedule } = createBatchScheduler({
					id: `${url_}.${getSignalId(options?.signal)}`,
					wait,
					shouldSplitBatch(requests) {
						return requests.length > batchSize;
					},
					fn: (body) => rpcClient.request({
						body,
						fetchOptions
					}),
					sort: (a, b) => a.id - b.id
				});
				const fn = async (body) => batch ? schedule(body) : [await rpcClient.request({
					body,
					fetchOptions
				})];
				const [{ error, result }] = await fn(body);
				if (raw) return {
					error,
					result
				};
				if (error) throw new RpcRequestError({
					body,
					error,
					url: url_
				});
				return result;
			},
			retryCount,
			retryDelay,
			timeout,
			type: "http"
		}, {
			fetchOptions,
			url: url_
		});
	};
}
//#endregion
//#region node_modules/viem/_esm/chains/definitions/arbitrumSepolia.js
var arbitrumSepolia = /*#__PURE__*/ defineChain({
	id: 421614,
	name: "Arbitrum Sepolia",
	blockTime: 250,
	nativeCurrency: {
		name: "Arbitrum Sepolia Ether",
		symbol: "ETH",
		decimals: 18
	},
	rpcUrls: { default: { http: ["https://sepolia-rollup.arbitrum.io/rpc"] } },
	blockExplorers: { default: {
		name: "Arbiscan",
		url: "https://sepolia.arbiscan.io",
		apiUrl: "https://api-sepolia.arbiscan.io/api"
	} },
	contracts: { multicall3: {
		address: "0xca11bde05977b3631167028862be2a173976ca11",
		blockCreated: 81930
	} },
	testnet: true
});
//#endregion
export { ccip_exports as a, parseEther as i, http as n, createPublicClient as r, arbitrumSepolia as t };
