import { i as __toESM } from "../_runtime.mjs";
import { i as useQueryClient, n as useQuery$1, o as require_react, t as useMutation } from "./react+tanstack__react-query.mjs";
import { _ as getChains, a as connectMutationOptions, b as BaseError$1, d as watchConnections, f as watchConnection, g as getConnection, h as getConnections, i as disconnectMutationOptions, m as getConnectors, n as switchChainMutationOptions, o as hashFn, p as watchChainId, r as getWalletClientQueryOptions, s as hydrate, t as watchChains, u as watchConnectors, v as deepEqual, y as getChainId } from "./@wagmi/core+[...].mjs";
import { t as require_with_selector } from "./use-sync-external-store.mjs";
//#region node_modules/wagmi/dist/esm/hydrate.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function Hydrate(parameters) {
	const { children, config, initialState, reconnectOnMount = true } = parameters;
	const { onMount } = hydrate(config, {
		initialState,
		reconnectOnMount
	});
	if (!config._internal.ssr) onMount();
	const active = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		if (!active.current) return;
		if (!config._internal.ssr) return;
		onMount();
		return () => {
			active.current = false;
		};
	}, []);
	return children;
}
//#endregion
//#region node_modules/wagmi/dist/esm/context.js
var WagmiContext = (0, import_react.createContext)(void 0);
function WagmiProvider(parameters) {
	const { children, config } = parameters;
	const props = { value: config };
	return (0, import_react.createElement)(Hydrate, parameters, (0, import_react.createElement)(WagmiContext.Provider, props, children));
}
//#endregion
//#region node_modules/wagmi/dist/esm/version.js
var version = "3.7.7";
//#endregion
//#region node_modules/wagmi/dist/esm/utils/getVersion.js
var getVersion = () => `wagmi@${version}`;
//#endregion
//#region node_modules/wagmi/dist/esm/errors/base.js
var BaseError = class extends BaseError$1 {
	constructor() {
		super(...arguments);
		Object.defineProperty(this, "name", {
			enumerable: true,
			configurable: true,
			writable: true,
			value: "WagmiError"
		});
	}
	get docsBaseUrl() {
		return "https://wagmi.sh/react";
	}
	get version() {
		return getVersion();
	}
};
//#endregion
//#region node_modules/wagmi/dist/esm/errors/context.js
var WagmiProviderNotFoundError = class extends BaseError {
	constructor() {
		super("`useConfig` must be used within `WagmiProvider`.", { docsPath: "/api/WagmiProvider" });
		Object.defineProperty(this, "name", {
			enumerable: true,
			configurable: true,
			writable: true,
			value: "WagmiProviderNotFoundError"
		});
	}
};
//#endregion
//#region node_modules/wagmi/dist/esm/utils/query.js
function useQuery(parameters) {
	const result = useQuery$1({
		...parameters,
		queryKeyHashFn: hashFn
	});
	result.queryKey = parameters.queryKey;
	return result;
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useConfig.js
/** https://wagmi.sh/react/api/hooks/useConfig */
function useConfig(parameters = {}) {
	const config = parameters.config ?? (0, import_react.useContext)(WagmiContext);
	if (!config) throw new WagmiProviderNotFoundError();
	return config;
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useChainId.js
/** https://wagmi.sh/react/api/hooks/useChainId */
function useChainId(parameters = {}) {
	const config = useConfig(parameters);
	return (0, import_react.useSyncExternalStore)((onChange) => watchChainId(config, { onChange }), () => getChainId(config), () => getChainId(config));
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useSyncExternalStoreWithTracked.js
var import_with_selector = require_with_selector();
var isPlainObject = (obj) => typeof obj === "object" && !Array.isArray(obj);
function useSyncExternalStoreWithTracked(subscribe, getSnapshot, getServerSnapshot = getSnapshot, isEqual = deepEqual) {
	const trackedKeys = (0, import_react.useRef)([]);
	const result = (0, import_with_selector.useSyncExternalStoreWithSelector)(subscribe, getSnapshot, getServerSnapshot, (x) => x, (a, b) => {
		if (isPlainObject(a) && isPlainObject(b) && trackedKeys.current.length) {
			for (const key of trackedKeys.current) if (!isEqual(a[key], b[key])) return false;
			return true;
		}
		return isEqual(a, b);
	});
	return (0, import_react.useMemo)(() => {
		if (isPlainObject(result)) {
			const trackedResult = { ...result };
			let properties = {};
			for (const [key, value] of Object.entries(trackedResult)) properties = {
				...properties,
				[key]: {
					configurable: false,
					enumerable: true,
					get: () => {
						if (!trackedKeys.current.includes(key)) trackedKeys.current.push(key);
						return value;
					}
				}
			};
			Object.defineProperties(trackedResult, properties);
			return trackedResult;
		}
		return result;
	}, [result]);
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useConnection.js
/** https://wagmi.sh/react/api/hooks/useConnection */
function useConnection(parameters = {}) {
	const config = useConfig(parameters);
	return useSyncExternalStoreWithTracked((onChange) => watchConnection(config, { onChange }), () => getConnection(config));
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useChains.js
/** https://wagmi.sh/react/api/hooks/useChains */
function useChains(parameters = {}) {
	const config = useConfig(parameters);
	return (0, import_react.useSyncExternalStore)((onChange) => watchChains(config, { onChange }), () => getChains(config), () => getChains(config));
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useConnectors.js
/** https://wagmi.sh/react/api/hooks/useConnectors */
function useConnectors(parameters = {}) {
	const config = useConfig(parameters);
	return (0, import_react.useSyncExternalStore)((onChange) => watchConnectors(config, { onChange }), () => getConnectors(config), () => getConnectors(config));
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useConnect.js
/** https://wagmi.sh/react/api/hooks/useConnect */
function useConnect(parameters = {}) {
	const config = useConfig(parameters);
	const options = connectMutationOptions(config, parameters);
	const mutation = useMutation(options);
	(0, import_react.useEffect)(() => {
		return config.subscribe(({ status }) => status, (status, previousStatus) => {
			if (previousStatus === "connected" && status === "disconnected") mutation.reset();
		});
	}, [config, mutation.reset]);
	return {
		...mutation,
		connect: mutation.mutate,
		connectAsync: mutation.mutateAsync,
		connectors: useConnectors({ config })
	};
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useConnections.js
/** https://wagmi.sh/react/api/hooks/useConnections */
function useConnections(parameters = {}) {
	const config = useConfig(parameters);
	return (0, import_react.useSyncExternalStore)((onChange) => watchConnections(config, { onChange }), () => getConnections(config), () => getConnections(config));
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useDisconnect.js
/** https://wagmi.sh/react/api/hooks/useDisconnect */
function useDisconnect(parameters = {}) {
	const config = useConfig(parameters);
	const options = disconnectMutationOptions(config, parameters);
	const mutation = useMutation(options);
	return {
		...mutation,
		connectors: useConnections({ config }).map((connection) => connection.connector),
		disconnect: mutation.mutate,
		disconnectAsync: mutation.mutateAsync
	};
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useSwitchChain.js
/** https://wagmi.sh/react/api/hooks/useSwitchChain */
function useSwitchChain(parameters = {}) {
	const config = useConfig(parameters);
	const options = switchChainMutationOptions(config, parameters);
	const mutation = useMutation(options);
	return {
		...mutation,
		chains: useChains({ config }),
		switchChain: mutation.mutate,
		switchChainAsync: mutation.mutateAsync
	};
}
//#endregion
//#region node_modules/wagmi/dist/esm/hooks/useWalletClient.js
/** https://wagmi.sh/react/api/hooks/useWalletClient */
function useWalletClient(parameters = {}) {
	const config = useConfig(parameters);
	const chainId = useChainId({ config });
	const { address, connector } = useConnection({ config });
	const options = getWalletClientQueryOptions(config, {
		...parameters,
		chainId: parameters.chainId ?? chainId,
		connector: parameters.connector ?? connector,
		query: parameters.query
	});
	const addressRef = (0, import_react.useRef)(address);
	const queryClient = useQueryClient();
	(0, import_react.useEffect)(() => {
		const previousAddress = addressRef.current;
		if (!address && previousAddress) {
			queryClient.removeQueries({ queryKey: options.queryKey });
			addressRef.current = void 0;
		} else if (address !== previousAddress) {
			queryClient.invalidateQueries({ queryKey: options.queryKey });
			addressRef.current = address;
		}
	}, [address, queryClient]);
	return useQuery(options);
}
//#endregion
export { useConnection as a, useConnect as i, useSwitchChain as n, WagmiProvider as o, useDisconnect as r, useWalletClient as t };
