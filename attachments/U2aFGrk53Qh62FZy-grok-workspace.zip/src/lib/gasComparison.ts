/**
 * Gas figures are displayed only when docs/gas-comparison.md is published
 * with real numbers. Until then this stays null so the UI never invents
 * a benchmark.
 */
export type GasComparisonDoc = {
  source: string;
  stylus: { label: string; note: string };
  solidity: { label: string; note: string };
};

export const GAS_COMPARISON: GasComparisonDoc | null = null;
