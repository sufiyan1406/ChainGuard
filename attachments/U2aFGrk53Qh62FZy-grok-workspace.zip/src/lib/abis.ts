/**
 * Frontend ABI copies matching docs/INTEGRATION_CONTRACT.md.
 *
 * Do not edit shared/contract-abis/ — that tree is owned by the backend.
 * When generated ABIs land, swap imports in contracts.ts to those files.
 */

export const insurancePoolAbi = [
  {
    type: "function",
    name: "buyPolicy",
    stateMutability: "payable",
    inputs: [
      { name: "locationId", type: "uint256" },
      { name: "coverageAmount", type: "uint256" },
    ],
    outputs: [{ name: "policyId", type: "uint256" }],
  },
  {
    type: "function",
    name: "quotePremium",
    stateMutability: "view",
    inputs: [
      { name: "locationId", type: "uint256" },
      { name: "coverageAmount", type: "uint256" },
    ],
    outputs: [{ name: "premium", type: "uint256" }],
  },
  {
    type: "function",
    name: "getPolicy",
    stateMutability: "view",
    inputs: [{ name: "policyId", type: "uint256" }],
    outputs: [
      {
        name: "policy",
        type: "tuple",
        components: [
          { name: "policyId", type: "uint256" },
          { name: "holder", type: "address" },
          { name: "locationId", type: "uint256" },
          { name: "coverageAmount", type: "uint256" },
          { name: "premiumPaid", type: "uint256" },
          { name: "purchasedAt", type: "uint256" },
          { name: "expiresAt", type: "uint256" },
          { name: "status", type: "uint8" },
          { name: "claimed", type: "bool" },
          { name: "payoutAmount", type: "uint256" },
        ],
      },
    ],
  },
  {
    type: "function",
    name: "getPoliciesByHolder",
    stateMutability: "view",
    inputs: [{ name: "holder", type: "address" }],
    outputs: [{ name: "policyIds", type: "uint256[]" }],
  },
  {
    type: "event",
    name: "PolicyPurchased",
    inputs: [
      { name: "policyId", type: "uint256", indexed: true },
      { name: "holder", type: "address", indexed: true },
      { name: "locationId", type: "uint256", indexed: false },
      { name: "coverageAmount", type: "uint256", indexed: false },
      { name: "premiumPaid", type: "uint256", indexed: false },
    ],
  },
  {
    type: "event",
    name: "PayoutTriggered",
    inputs: [
      { name: "policyId", type: "uint256", indexed: true },
      { name: "holder", type: "address", indexed: true },
      { name: "amount", type: "uint256", indexed: false },
      { name: "riskScore", type: "uint32", indexed: false },
    ],
  },
  { type: "error", name: "PolicyNotFound", inputs: [] },
  { type: "error", name: "AlreadyClaimed", inputs: [] },
  { type: "error", name: "InsufficientPremium", inputs: [] },
  { type: "error", name: "NotAuthorized", inputs: [] },
  { type: "error", name: "InvalidLocation", inputs: [] },
  { type: "error", name: "CoverageOutOfBounds", inputs: [] },
] as const;

export const riskEngineAbi = [
  {
    type: "function",
    name: "getRiskScore",
    stateMutability: "view",
    inputs: [{ name: "locationId", type: "uint256" }],
    outputs: [{ name: "score", type: "uint32" }],
  },
  {
    type: "function",
    name: "getLastUpdated",
    stateMutability: "view",
    inputs: [{ name: "locationId", type: "uint256" }],
    outputs: [{ name: "timestamp", type: "uint256" }],
  },
  {
    type: "function",
    name: "getSensorValue",
    stateMutability: "view",
    inputs: [{ name: "locationId", type: "uint256" }],
    outputs: [{ name: "value", type: "uint256" }],
  },
] as const;
