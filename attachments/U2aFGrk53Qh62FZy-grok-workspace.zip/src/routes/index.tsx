import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { BuyPolicyForm } from "@/components/BuyPolicyForm";
import { LiveRiskStrip } from "@/components/LiveRiskStrip";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main>
      <Hero />
      <section id="bind" className="border-t border-line">
        <div className="flex items-end justify-between border-b border-line px-5 py-5 md:px-6">
          <div>
            <p className="label">Bind cover</p>
            <h2 className="display mt-1 text-4xl md:text-5xl">Buy a policy</h2>
          </div>
          <p className="hidden max-w-xs text-right text-xs text-ink-muted md:block">
            Location → coverage → premium → purchase. One transaction.
          </p>
        </div>
        <BuyPolicyForm />
      </section>
      <LiveRiskStrip />
    </main>
  );
}

function Hero() {
  return (
    <section className="grid grid-cols-1 lg:grid-cols-2">
      <div className="flex min-h-[28rem] flex-col justify-between border-b border-line px-5 py-8 md:min-h-[32rem] md:px-8 md:py-10 lg:border-r lg:border-b-0">
        <p className="label">Parametric flood cover · Arbitrum</p>
        <div>
          <h1 className="display text-[clamp(4.5rem,16vw,9.5rem)]">Cover</h1>
          <p className="mt-5 max-w-md text-base text-ink-muted md:text-lg">
            Micro-insurance that pays when the water parameter crosses the line.
            No adjuster. No waiting on a claim file. The contract is the policy.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#bind"
              className="inline-flex h-12 items-center bg-ink px-5 text-sm text-paper transition-transform duration-150 active:scale-[0.96]"
            >
              Bind cover
              <ArrowRight className="ml-2 size-4" />
            </a>
            <Link
              to="/policies"
              className="inline-flex h-12 items-center px-5 text-sm text-ink shadow-[inset_0_0_0_1px_var(--color-ink)] transition-colors duration-150 hover:bg-ink hover:text-paper"
            >
              My policies
            </Link>
          </div>
        </div>
      </div>

      <div className="relative min-h-[22rem] overflow-hidden bg-dark lg:min-h-[32rem]">
        <img
          src="/editorial/delta.jpg"
          alt="Aerial river delta over a city grid"
          className="absolute inset-0 size-full object-cover opacity-80"
        />
        <div className="halftone-fine absolute inset-0 mix-blend-multiply" />
        <div className="absolute inset-0 bg-linear-to-t from-dark/70 to-transparent" />
        <p className="display pointer-events-none absolute -bottom-6 right-2 text-[clamp(8rem,28vw,16rem)] leading-none text-paper/15 select-none">
          G
        </p>
        <p className="absolute bottom-5 left-5 font-mono text-[11px] tracking-widest text-paper uppercase">
          Jakarta basin · site 01
        </p>
      </div>

      <div className="grid grid-cols-2 border-t border-line lg:col-span-2 lg:grid-cols-4">
        <div className="relative min-h-52 overflow-hidden border-b border-r border-line sm:min-h-64">
          <img
            src="/editorial/concrete.jpg"
            alt="Rain-stained brutalist concrete"
            className="absolute inset-0 size-full object-cover"
          />
        </div>
        <div className="relative min-h-52 overflow-hidden border-b border-line sm:min-h-64 lg:border-r">
          <img
            src="/editorial/water.jpg"
            alt="Rain on dark water"
            className="absolute inset-0 size-full object-cover"
          />
        </div>
        <div className="flex min-h-52 flex-col justify-between border-b border-line bg-dark p-5 text-dark-fg sm:min-h-64 lg:border-r lg:border-b-0">
          <p className="text-sm leading-relaxed">
            Placing flood cover for households and small books on a public chain
            since this afternoon. The risk engine is Stylus. The pool is the
            underwriter.
          </p>
          <p className="label text-dark-muted">Since 2026</p>
        </div>
        <div className="flex min-h-52 flex-col justify-between bg-mint p-5 text-mint-fg sm:min-h-64">
          <p className="text-sm leading-relaxed">
            We don’t wait on volume. We move capital when the parameter says so —
            and the firms that bind cover get paid in the same block.
          </p>
          <p className="label text-mint-fg/70">Payout on trigger</p>
        </div>
      </div>
    </section>
  );
}
